import { useRef, useState } from 'react';
import type { SupportRecord } from '../types';
import { detectKind, extractText, extractTextRemote } from '../lib/support';

type ImportState={key:string;name:string;status:'saving'|'extracting'|'done'|'warning'|'error';message:string};
const withTimeout=<T,>(promise:Promise<T>,ms:number,label:string)=>Promise.race<T>([promise,new Promise<T>((_,reject)=>setTimeout(()=>reject(new Error(label)),ms))]);

export function Library({ supports, activeSupportId, onImported, onUpdated, onActivate, onDelete }: {
  supports: SupportRecord[]; activeSupportId?: number; onImported: (support: SupportRecord) => Promise<number | void>; onUpdated:(support:SupportRecord)=>Promise<void>;
  onActivate: (id: number) => void; onDelete: (id: number) => Promise<void>;
}) {
  const inputRef=useRef<HTMLInputElement>(null); const [busy,setBusy]=useState(false); const [query,setQuery]=useState(''); const [error,setError]=useState('');
  const [pasteOpen,setPasteOpen]=useState(false); const [pasteTitle,setPasteTitle]=useState(''); const [pasteText,setPasteText]=useState(''); const [category,setCategory]=useState('Cours'); const [states,setStates]=useState<ImportState[]>([]);
  const update=(key:string,patch:Partial<ImportState>)=>setStates(prev=>prev.map(x=>x.key===key?{...x,...patch}:x));

  async function saveFile(file:File,index:number){
    const kind=detectKind(file); const now=new Date().toISOString(); const key=`${file.name}-${file.size}-${index}-${Date.now()}`;
    setStates(prev=>[...prev,{key,name:file.name,status:'saving',message:'Enregistrement de l’original…'}]);
    const base:SupportRecord={title:file.name.replace(/\.[^.]+$/,''),category,kind,mimeType:file.type||'application/octet-stream',size:file.size,blob:file,text:'',createdAt:now,updatedAt:now};
    let id:number|void;
    try{id=await withTimeout(onImported(base),12000,'Le stockage local ne répond pas. Réessayez.')}catch(e){update(key,{status:'error',message:e instanceof Error?e.message:'Import impossible'});return}
    if(typeof id!=='number'){update(key,{status:'warning',message:'Original enregistré, mais identifiant indisponible.'});return}
    update(key,{status:'extracting',message:kind==='pdf'||kind==='text'?'Original enregistré · extraction du texte…':'Original enregistré et prêt'});
    if(kind!=='pdf'&&kind!=='text'){update(key,{status:'done',message:'Support ajouté et immédiatement disponible'});return}
    try{
      let text='';
      try { text=await withTimeout(extractText(file,kind),18000,'Extraction locale trop longue'); } catch {}
      if(!text.trim() && (kind==='pdf' || kind==='text')) {
        update(key,{status:'extracting',message:'Extraction locale insuffisante · analyse Cloudflare…'});
        try { text=await withTimeout(extractTextRemote(file),30000,'Extraction Cloudflare trop longue'); } catch {}
      }
      const enriched={...base,id,text,updatedAt:new Date().toISOString()}; await onUpdated(enriched);
      update(key,{status:text.trim()?'done':'warning',message:text.trim()?'Support ajouté · texte extrait et prêt à réviser':'Original conservé · aucun texte exploitable détecté. Les exercices de contenu resteront désactivés.'});
    }catch(e){update(key,{status:'warning',message:`Original conservé · extraction non disponible (${e instanceof Error?e.message:'erreur'})`})}
  }
  async function importFiles(files:FileList|null){if(!files?.length)return;setBusy(true);setError('');setStates([]);try{for(const [i,file] of Array.from(files).entries())await saveFile(file,i)}finally{setBusy(false);if(inputRef.current)inputRef.current.value=''}}
  async function importPaste(){if(!pasteText.trim())return;setBusy(true);setError('');try{const now=new Date().toISOString();const blob=new Blob([pasteText],{type:'text/plain'});await onImported({title:pasteTitle.trim()||'Notes importées',category,kind:'text',mimeType:'text/plain',size:blob.size,blob,text:pasteText.trim(),createdAt:now,updatedAt:now});setPasteText('');setPasteTitle('');setPasteOpen(false)}catch(e){setError(e instanceof Error?e.message:'Impossible d’enregistrer ce texte.')}finally{setBusy(false)}}
  const filtered=supports.filter(s=>s.title.toLocaleLowerCase('fr').includes(query.toLocaleLowerCase('fr')));
  return <div className="screen library-screen library-v21"><header className="screen-head compact-head library-v19-head"><div><span className="eyebrow">Bibliothèque</span><h1>Ajouter une matière sans attendre.</h1><p>L’original est enregistré d’abord. L’extraction du texte vient ensuite : un PDF difficile ne bloque plus tout l’import.</p></div><div className="library-head-actions"><select className="category-select" value={category} onChange={e=>setCategory(e.target.value)}><option>Cours</option><option>Français</option><option>Arabe</option><option>Qour’ān</option><option>Religion</option><option>Autre</option></select><label className={`primary-action file-direct ${busy?'disabled':''}`}><input ref={inputRef} type="file" multiple accept=".pdf,.txt,.md,.csv,.json,image/*,audio/*" onChange={e=>importFiles(e.target.files)}/><span>{busy?'Traitement…':'Ajouter des supports'}</span><b>＋</b></label><button className="quiet-action" onClick={()=>setPasteOpen(v=>!v)}>Coller un texte</button></div></header>
  {states.length?<section className="import-queue glass-panel"><header><div><span className="eyebrow">État des imports</span><strong>{busy?'Traitement en cours':'Import terminé'}</strong></div><small>{states.filter(x=>x.status==='done'||x.status==='warning').length}/{states.length} conservés</small></header>{states.map(x=><div key={x.key} className={`import-row ${x.status}`}><span className="import-dot"/><div><strong>{x.name}</strong><small>{x.message}</small></div><em>{x.status==='saving'?'Sauvegarde':x.status==='extracting'?'Analyse':x.status==='done'?'Prêt':x.status==='warning'?'À vérifier':'Échec'}</em></div>)}</section>:null}
  {error?<div className="import-error">{error}</div>:null}{pasteOpen?<section className="paste-studio"><div><span className="eyebrow light">Texte direct</span><h2>Créer un support sans fichier.</h2><p>Collez vos notes ou votre cours. Ils seront immédiatement disponibles dans Mémoriser.</p></div><div><input placeholder="Titre" value={pasteTitle} onChange={e=>setPasteTitle(e.target.value)}/><textarea placeholder="Collez votre texte…" value={pasteText} onChange={e=>setPasteText(e.target.value)}/><button className="primary-action" onClick={importPaste} disabled={busy||!pasteText.trim()}>Enregistrer ce support</button></div></section>:null}
  <div className="library-toolbar-v21"><input type="search" placeholder="Rechercher…" value={query} onChange={e=>setQuery(e.target.value)}/><span>{filtered.length} support{filtered.length>1?'s':''}</span></div>
  {filtered.length?<div className="support-grid-v17">{filtered.map(s=><article key={s.id} className={s.id===activeSupportId?'active':''}><div className="support-cover"><span>{s.kind.toUpperCase()}</span><i>{s.category}</i></div><div className="support-copy"><h3>{s.title}</h3><p>{s.text?.trim()?`${s.text.slice(0,130)}${s.text.length>130?'…':''}`:'Original conservé · texte non extrait'}</p><small>{Math.round(s.size/1024)} Ko</small></div><div className="support-actions"><button className="primary-small" onClick={()=>s.id&&onActivate(s.id)}>Réviser</button><button className="danger-link" onClick={()=>s.id&&onDelete(s.id)}>Supprimer</button></div></article>)}</div>:<div className="library-empty-v17"><div><span className="eyebrow">Bibliothèque vide</span><h2>Votre première matière commence ici.</h2><p>Ajoutez un PDF, un texte, une image ou un audio. Sirāfiq conserve toujours l’original.</p></div><div className="empty-visual"><span>PDF</span><span>TXT</span><span>＋</span></div></div>}</div>;
}
