import * as pdfjsLib from 'pdfjs-dist';
import type { SupportRecord } from '../types';

pdfjsLib.GlobalWorkerOptions.workerSrc = new URL('pdfjs-dist/build/pdf.worker.min.mjs', import.meta.url).toString();

export function detectKind(file: File): SupportRecord['kind'] {
  if (file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')) return 'pdf';
  if (file.type.startsWith('text/') || /\.(txt|md|csv|json)$/i.test(file.name)) return 'text';
  if (file.type.startsWith('image/')) return 'image';
  if (file.type.startsWith('audio/')) return 'audio';
  return 'file';
}

export async function extractText(file: Blob, kind: SupportRecord['kind']): Promise<string> {
  if (kind === 'text') return (await file.text()).replace(/\u0000/g, '').trim();
  if (kind === 'pdf') {
    const buffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: buffer }).promise;
    let text = '';
    for (let p = 1; p <= pdf.numPages; p++) {
      const page = await pdf.getPage(p);
      const content = await page.getTextContent();
      text += content.items.map(item => 'str' in item ? item.str : '').join(' ') + '\n';
      if (text.length > 120000) break;
    }
    return text.replace(/\s+\n/g, '\n').replace(/[ \t]+/g, ' ').trim();
  }
  return '';
}

export function supportSummary(text: string): string[] {
  return text.split(/(?<=[.!?])\s+/).map(s => s.trim()).filter(s => s.length > 35).slice(0, 8);
}

export function makeQuestions(text: string): string[] {
  const sentences = supportSummary(text).slice(0, 6);
  return sentences.map((sentence, i) => {
    const excerpt = `« ${sentence.slice(0, 150)}${sentence.length > 150 ? '…' : ''} »`;
    if (i === 0) return `Expliquez avec vos propres mots l’idée principale de ${excerpt}`;
    if (i === 1) return `Quel lien cette idée entretient-elle avec l’idée précédente ? Appuyez-vous sur ${excerpt}`;
    if (i === 2) return `Donnez un exemple ou une conséquence qui illustre précisément ${excerpt}`;
    if (i === 3) return `Reformulez sans reprendre les mêmes mots : ${excerpt}`;
    return `Restituez puis expliquez ce point du support : ${excerpt}`;
  });
}


export async function extractTextRemote(file: File): Promise<string> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 25000);
  try {
    const form = new FormData();
    form.append('file', file, file.name);
    const response = await fetch('/api/extract', { method: 'POST', body: form, signal: controller.signal });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data?.error || `Extraction serveur impossible (${response.status})`);
    return String(data?.text || '').trim();
  } finally {
    clearTimeout(timer);
  }
}
