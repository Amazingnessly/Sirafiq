const json = (data, init = {}) => new Response(JSON.stringify(data), {
  ...init,
  headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...(init.headers || {}) }
});

async function voice(request, env) {
  if (!env.AI) return json({ error: "Binding Workers AI 'AI' non configuré" }, { status: 503 });
  const body = await request.json().catch(() => ({}));
  const text = String(body.text || '').trim();
  const lang = String(body.lang || 'fr').toLowerCase().startsWith('ar') ? 'ar' : 'fr';
  if (!text) return json({ error: 'Texte vide' }, { status: 400 });
  try {
    const response = await env.AI.run('@cf/myshell-ai/melotts', {
      prompt: text.slice(0, 1000),
      lang,
    }, { returnRawResponse: true });
    if (!(response instanceof Response)) return json({ error: 'Réponse audio inattendue' }, { status: 502 });
    if (!response.ok) return json({ error: `Synthèse vocale indisponible (${response.status})` }, { status: 502 });
    const headers = new Headers(response.headers);
    if (!headers.get('content-type')) headers.set('content-type', 'audio/mpeg');
    headers.set('cache-control', 'no-store');
    return new Response(response.body, { status: response.status, headers });
  } catch (error) {
    return json({ error: error instanceof Error ? error.message : 'Synthèse vocale indisponible' }, { status: 502 });
  }
}

async function extract(request, env) {
  if (!env.AI) return json({ error: "Binding Workers AI 'AI' non configuré" }, { status: 503 });
  try {
    const form = await request.formData();
    const file = form.get('file');
    if (!(file instanceof File)) return json({ error: 'Fichier manquant' }, { status: 400 });
    const result = await env.AI.toMarkdown(
      { name: file.name || 'document', blob: file },
      { conversionOptions: { output: { format: 'text' }, pdf: { metadata: false } } }
    );
    if (result?.format === 'error') return json({ error: result.error || 'Extraction impossible' }, { status: 422 });
    return json({ text: String(result?.data || '').trim(), format: result?.format || 'text' });
  } catch (error) {
    return json({ error: error instanceof Error ? error.message : 'Extraction impossible' }, { status: 502 });
  }
}

function parseJson(raw) {
  const cleaned = String(raw || '').replace(/^```json\s*|\s*```$/g, '').trim();
  try { return JSON.parse(cleaned); } catch {}
  const a = cleaned.indexOf('{'), b = cleaned.lastIndexOf('}');
  if (a >= 0 && b > a) { try { return JSON.parse(cleaned.slice(a,b+1)); } catch {} }
  return null;
}

async function study(request, env) {
  if (!env.AI) return json({ error: "Binding Workers AI 'AI' non configuré" }, { status: 503 });
  const data = await request.json().catch(() => ({}));
  const title = String(data.title || 'Support');
  const text = String(data.text || '').trim().slice(0, 16000);
  if (text.length < 80) return json({ error: 'Le support ne contient pas assez de texte pour générer des exercices fiables.' }, { status: 422 });
  const prompt = `Tu crées un petit paquet de révision à partir EXCLUSIVEMENT du support fourni. N'invente aucun fait. Langue de réponse: français. Aucun texte à trous. Réponds uniquement en JSON valide selon ce schéma:\n{"summary":["..."],"questions":[{"q":"...","answer":"..."}],"flashcards":[{"front":"...","back":"..."}]}\nContraintes: 4 à 6 idées principales, 5 questions ouvertes de compréhension/rappel, 5 à 8 flashcards courtes et précises. Si une information n'est pas dans le support, ne l'utilise pas.\nTitre: ${title}\nSUPPORT:\n${text}`;
  try {
    const out = await env.AI.run('@cf/zai-org/glm-4.7-flash', {
      messages: [{ role: 'user', content: prompt }], max_tokens: 1800, temperature: 0.1,
    });
    const parsed = parseJson(out?.response || out?.result?.response || '');
    if (!parsed) return json({ error: 'Le générateur n’a pas renvoyé un format exploitable.' }, { status: 502 });
    return json(parsed);
  } catch (error) {
    return json({ error: error instanceof Error ? error.message : 'Génération indisponible' }, { status: 502 });
  }
}

async function coach(request, env) {
  if (!env.AI) return json({ error: "Binding Workers AI 'AI' non configuré" }, { status: 503 });
  const data = await request.json().catch(() => ({}));
  const prompt = `Tu es Boussole, l'agent pédagogique de Sirāfiq. Tu proposes une séance concrète à partir des données fournies. N'invente jamais le niveau de l'utilisateur. Aucun texte à trous. Pour le français, sépare lecture/écriture/oral. Pour l'arabe, priorité à l'écriture et au geste. Si un support est fourni, travaille uniquement son contenu. Réponds en JSON strict: {"title":"...","reason":"...","steps":[{"title":"...","detail":"...","duration":"..."}]}. 3 à 5 étapes maximum. Données: ${JSON.stringify(data).slice(0,14000)}`;
  try {
    const out = await env.AI.run('@cf/zai-org/glm-4.7-flash', { messages:[{role:'user',content:prompt}], max_tokens:900, temperature:0.1 });
    const parsed = parseJson(out?.response || out?.result?.response || '');
    if (!parsed) return json({ error: 'Plan IA inexploitable' }, { status: 502 });
    return json(parsed);
  } catch (error) {
    return json({ error: error instanceof Error ? error.message : 'Boussole indisponible' }, { status: 502 });
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/api/health') return json({ ok:true, app:'sirafiq', version:'26', runtime:'cloudflare-workers', ai:Boolean(env.AI) });
    if (url.pathname === '/api/voice' && request.method === 'POST') return voice(request, env);
    if (url.pathname === '/api/extract' && request.method === 'POST') return extract(request, env);
    if (url.pathname === '/api/study' && request.method === 'POST') return study(request, env);
    if (url.pathname === '/api/coach' && request.method === 'POST') return coach(request, env);
    if (url.pathname.startsWith('/api/')) return json({ error:'Route API inconnue' }, { status:404 });
    return env.ASSETS.fetch(request);
  }
};
