# Sirāfiq V26 — stabilisation fonctionnelle

Cette version corrige les chaînes fonctionnelles prioritaires avant toute nouvelle fonctionnalité.

- voix: timeout explicite, erreur visible, bouton de secours direct « Voix iPad » ;
- PDF: extraction locale puis Cloudflare Workers AI `toMarkdown` ;
- révision: aucun exercice générique si le support n’a pas de texte exploitable ;
- exercices: consignes dérivées du contenu réel extrait ;
- bibliothèque: déduplication des imports identiques ;
- transmission: ouverture sur le support actif et synchronisation des ajouts ;
- espaces de cours/transcription agrandis sur iPad.

Cloudflare: `/api/health`, `/api/voice`, `/api/extract`, `/api/study`, `/api/coach`.
