export async function onRequestPost({ request, env }) {
  if (!env.AI) return Response.json({ error: "Binding Workers AI 'AI' non configuré" }, { status: 503 });
  const { text = '', lang = 'fr' } = await request.json().catch(() => ({}));
  if (!String(text).trim()) return Response.json({ error: 'Texte vide' }, { status: 400 });
  const language = String(lang).toLowerCase().startsWith('ar') ? 'ar' : 'fr';
  try {
    const result = await env.AI.run('@cf/myshell-ai/melotts', { prompt: String(text).slice(0,1200), lang: language });
    if (result instanceof Response) return result;
    if (result instanceof ArrayBuffer) return new Response(result, { headers: { 'content-type': 'audio/mpeg', 'cache-control': 'no-store' } });
    if (ArrayBuffer.isView(result)) return new Response(result.buffer, { headers: { 'content-type': 'audio/mpeg', 'cache-control': 'no-store' } });
    return new Response(result, { headers: { 'content-type': 'audio/mpeg', 'cache-control': 'no-store' } });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : 'Synthèse vocale indisponible' }, { status: 502 });
  }
}
