import { useRef, useState } from 'react';
import type { SupportRecord } from '../types';
import { detectKind, extractText } from '../lib/support';

type ImportState={name:string;status:'reading'|'saving'|'done'|'warning'|'error';message:string};
const withTimeout=<T,>(promise:Promise<T>,ms:number,label:string)=>Promise.race<T>([promise,new Promise<T>((_,reject)=>setTimeout(()=>reject(new Error(label)),ms))]);

export function Library({ supports, activeSupportId, onImported, onActivate, onDelete }: {
  supports: SupportRecord[]; activeSupportId?: number; onImported: (support: SupportRecord) => Promise<void>;
  onActivate: (id: number) => void; onDelete: (id: number) => Promise<void>;
}) {
  const inputRef=useRef<HTMLInputElement>(null);
  const [busy,setBusy]=useState(false); const [query,setQuery]=useState(''); const [error,setError]=useState('');
  const [pasteOpen,setPasteOpen]=useState(false); const [pasteTitle,setPasteTitle]=useState(''); const [pasteText,setPasteText]=useState('');
  const [category,setCategory]=useState('Cours'); const [states,setStates]=useState<ImportState[]>([]);
  const update=(name:string,patch:Partial<ImportState>)=>setStates(prev=>prev.map(x=>x.name===name?{...x,...patch}:x));

  async function saveFile(file:File){
    const kind=detectKind(file); const now=new Date().toISOString();
    setStates(prev=>[...prev.filter(x=>x.name!==file.name),{name:file.name,status:'reading',message:'Lecture du fichier…'}]);
    let text=''; let warning='';
    try{text=await withTimeout(extractText(file,kind),15000,'Extraction trop longue')}catch(e){warning=e instanceof Error?e.message:'Texte non extrait'}
    update(file.name,{status:'saving',message:warning?'Original prêt · extraction partielle':'Enregistrement…'});
    await withTimeout(onImported({title:file.name.replace(/\.[^.]+$/,''),category,kind,mimeType:file.type||'application/octet-stream',size:file.size,blob:file,text,createdAt:now,updatedAt:now}),15000,'Enregistrement local trop long');
    update(file.name,{status:warning?'warning':'done',message:warning?'Support ajouté · contenu à vérifier':'Support ajouté et prêt à travailler'});
  }
  async function importFiles(files:FileList|null){
    if(!files?.length)return; setBusy(true);setError('');setStates([]);
    try{for(const file of Array.from(files)){try{await saveFile(file)}catch(e){const m=e instanceof Error?e.message:'Import impossible';update(file.name,{status:'error',message:m});setError(`« ${file.name} » n’a pas pu être ajouté. ${m}`)}}}
    finally{setBusy(false);if(inputRef.current)inputRef.current.value=''}
  }
  async function importPaste(){if(!pasteText.trim())return;setBusy(true);setError('');try{const now=new Date().toISOString();const blob=new Blob([pasteText],{type:'text/plain'});await onImported({title:pasteTitle.trim()||'Notes importées',category,kind:'text',mimeType:'text/plain',size:blob.size,blob,text:pasteText.trim(),createdAt:now,updatedAt:now});setPasteText('');setPasteTitle('');setPasteOpen(false)}catch(e){setError(e instanceof Error?e.message:'Impossible d’enregistrer ce texte.')}finally{setBusy(false)}}

  const filtered=supports.filter(s=>s.title.toLocaleLowerCase('fr').includes(query.toLocaleLowerCase('fr')));
  return <div className="screen library-screen library-v19">
    <header className="screen-head compact-head library-v19-head"><div><span className="eyebrow">Bibliothèque</span><h1>Une matière fiable, disponible partout.</h1><p>Ajoutez un support une seule fois. Sirāfiq conserve l’original, extrait ce qu’il peut et indique clairement l’état de chaque import.</p></div><div className="library-head-actions"><select className="category-select" value={category} onChange={e=>setCategory(e.target.value)}><option>Cours</option><option>Français</option><option>Arabe</option><option>Qour’ān</option><option>Religion</option><option>Autre</option></select><label className={`primary-action file-direct ${busy?'disabled':''}`}><input ref={inputRef} type="file" multiple accept=".pdf,.txt,.md,.csv,.json,image/*,audio/*" onChange={e=>importFiles(e.target.files)}/><span>{busy?'Traitement en cours…':'Ajouter des supports'}</span><b>＋</b></label><button className="quiet-action" onClick={()=>setPasteOpen(v=>!v)}>Coller un texte</button></div></header>
    {states.length?<section className="import-queue glass-panel"><header><div><span className="eyebrow">Import</span><strong>{busy?'Traitement des fichiers':'Import terminé'}</strong></div><small>{states.filter(x=>x.status==='done'||x.status==='warning').length}/{states.length} ajoutés</small></header>{states.map(s=><div className={`import-row ${s.status}`} key={s.name}><span className="import-dot"/><div><strong>{s.name}</strong><small>{s.message}</small></div><em>{s.status==='reading'?'Lecture':s.status==='saving'?'Enregistrement':s.status==='done'?'Prêt':s.status==='warning'?'À vérifier':'Échec'}</em></div>)}</section>:null}
    {error?<div className="import-error"><strong>Un import nécessite votre attention</strong><span>{error}</span><button onClick={()=>inputRef.current?.click()}>Réessayer avec un fichier</button></div>:null}
    {pasteOpen?<section className="paste-studio"><div><span className="eyebrow">Import direct</span><h2>Coller un cours, une note ou un extrait.</h2><p>Le texte est immédiatement exploitable dans Réviser et Boussole.</p></div><div><input value={pasteTitle} onChange={e=>setPasteTitle(e.target.value)} placeholder="Titre du support"/><textarea value={pasteText} onChange={e=>setPasteText(e.target.value)} placeholder="Collez votre texte ici…"/><button className="primary-small" onClick={importPaste} disabled={!pasteText.trim()||busy}>Ajouter à la bibliothèque</button></div></section>:null}
    <div className="library-toolbar-v15"><input type="search" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Rechercher un support…"/><span>{supports.length} support{supports.length!==1?'s':''}</span></div>
    {filtered.length?<div className="support-grid-v17">{filtered.map(s=><article key={s.id} className={activeSupportId===s.id?'active':''}><div className="support-cover"><span>{s.kind==='pdf'?'PDF':s.kind==='text'?'TXT':s.kind==='audio'?'AUDIO':s.kind.toUpperCase()}</span><i>{s.category}</i></div><div className="support-copy"><h3>{s.title}</h3><p>{s.text?`${s.text.slice(0,175)}${s.text.length>175?'…':''}`:'Original conservé. Le contenu visuel/audio reste disponible même sans extraction textuelle.'}</p><small>{Math.max(1,Math.round(s.size/1024))} Ko · {activeSupportId===s.id?'support actif':'prêt à travailler'}</small></div><div className="support-actions"><button className="primary-small" onClick={()=>s.id&&onActivate(s.id)}>{activeSupportId===s.id?'Continuer':'Travailler'}</button><button className="danger-link" onClick={()=>s.id&&onDelete(s.id)}>Supprimer</button></div></article>)}</div>:<section className="library-empty-v17"><div className="empty-visual"><span>PDF</span><span>TXT</span><span>♫</span></div><div><span className="eyebrow">Premier support</span><h2>Ajoutez votre matière.</h2><p>PDF, document texte, image ou audio. Sirāfiq affiche désormais chaque étape de l’import au lieu de rester bloqué sur « en cours ».</p><label className="primary-action file-direct"><input type="file" multiple accept=".pdf,.txt,.md,.csv,.json,image/*,audio/*" onChange={e=>importFiles(e.target.files)}/><span>Ouvrir Fichiers</span><b>→</b></label></div></section>}
  </div>;
}
