# Sirāfiq V23 — Révisions d’abord

Passe ciblée sur l’utilisabilité réelle :
- suppression complète de l’exercice « texte à trous » ;
- Studio de transcription restructuré pour donner la priorité à la zone de transcription ;
- zone de transcription agrandie et notes rendues secondaires ;
- responsive iPad renforcé ;
- aucune nouvelle fonctionnalité ajoutée dans cette passe.

Le travail pédagogique français/arabe doit désormais être construit à partir de référentiels sourcés avant d’être élargi dans l’interface.
