import type { ReactNode } from 'react';

const glyphs: Record<string, ReactNode> = {
  home: '⌂', learn: '◒', whiteboard: '▱', library: '▤', media: '▶', studio: '⌁', courses: '✦', compass: '⌖', memory: '◐', pronunciation: '◉', writing: '✎', maps: '⌘'
};

export function Icon({ name }: { name: string }) {
  return <span className="icon-glyph" aria-hidden="true">{glyphs[name] ?? '•'}</span>;
}
