import type { ReactNode } from 'react';
import type { Section } from '../types';
import { Icon } from './Icon';

const nav: { id: Section; label: string; group?: string }[] = [
  { id: 'home', label: 'Aujourd’hui', group:'Votre journée' },
  { id: 'compass', label: 'Boussole IA' },
  { id: 'learn', label: 'Apprendre', group:'Apprendre' },
  { id: 'whiteboard', label: 'Tableau blanc' },
  { id: 'library', label: 'Bibliothèque' },
  { id: 'media', label: 'Médiathèque', group:'Créer & transmettre' },
  { id: 'studio', label: 'Transcription' },
  { id: 'courses', label: 'Cours & supports' }
];

export function AppShell({ section, setSection, children, activeSupportTitle }: {
  section: Section;
  setSection: (value: Section) => void;
  children: ReactNode;
  activeSupportTitle?: string;
}) {
  return (
    <div className="app-frame v16-frame">
      <aside className="app-rail v16-rail">
        <button className="brand-mark v16-brand" onClick={() => setSection('home')} aria-label="Sirāfiq — accueil">
          <img src="/assets/logo-sirafiq-verrouille.png" alt="Sirāfiq" />
        </button>
        <nav className="rail-nav v16-nav" aria-label="Navigation principale">
          {nav.map(item => <div className="nav-entry" key={item.id}>
            {item.group ? <span className="nav-group">{item.group}</span> : null}
            <button className={section === item.id ? 'active' : ''} onClick={() => setSection(item.id)}>
              <Icon name={item.id} /><span className="nav-label">{item.label}</span>
            </button>
          </div>)}
        </nav>
        <div className="rail-foot v16-rail-foot"><span className="privacy-dot" /><div><strong>Local d’abord</strong><small>Vos progrès restent sur cet appareil.</small></div></div>
      </aside>
      <div className="app-stage">
        <header className="stage-topbar v16-topbar">
          <div className="topbar-context"><span className="stage-kicker">Sirāfiq</span>{activeSupportTitle ? <strong className="active-support-pill">Support actif · {activeSupportTitle}</strong> : <span className="topbar-subtle">Apprendre · pratiquer · retenir</span>}</div>
          <button className="topbar-ai" onClick={()=>setSection('compass')}><span>✦</span><strong>Demander à Sirāfiq</strong></button>
        </header>
        <main className="stage-content v16-stage-content">{children}</main>
      </div>
      <nav className="mobile-nav" aria-label="Navigation mobile">
        {nav.slice(0,5).map(item => <button key={item.id} className={section === item.id ? 'active' : ''} onClick={() => setSection(item.id)}><Icon name={item.id}/><small>{item.label}</small></button>)}
      </nav>
    </div>
  );
}
