export type Section = 'home' | 'learn' | 'whiteboard' | 'library' | 'media' | 'studio' | 'courses' | 'compass';
export type LearnMode = 'academy' | 'memory' | 'pronunciation' | 'writing' | 'maps';
export type Mastery = 'again' | 'fragile' | 'acquired' | 'mastered';

export interface SupportAnnotation { id: string; anchor: string; text: string; visibility: 'private' | 'shared'; updatedAt: string; }

export interface SupportRecord {
  id?: number;
  title: string;
  category: string;
  kind: 'pdf' | 'text' | 'image' | 'audio' | 'file';
  mimeType: string;
  size: number;
  blob: Blob;
  text?: string;
  createdAt: string;
  updatedAt: string;
  annotations?: SupportAnnotation[];
}

export interface ReviewRecord {
  key: string;
  supportId?: number;
  title: string;
  domain: string;
  mastery: Mastery;
  nextReview: string;
  intervalDays: number;
  updatedAt: string;
}

export interface MapNode {
  id: string;
  label: string;
  children: MapNode[];
}

export interface MindMapRecord {
  id?: number;
  title: string;
  supportId?: number;
  root: MapNode;
  createdAt: string;
  updatedAt: string;
}

export interface PlaylistRecord {
  id?: number;
  title: string;
  category: 'Religion' | 'Arabe' | 'Qour’ān' | 'Autre';
  url: string;
  videoId?: string;
  playlistId?: string;
  note?: string;
  progress?: number;
  createdAt: string;
}

export interface CourseRecord {
  id?: number;
  title: string;
  body: string;
  supportId?: number;
  supportTitle?: string;
  additions: { id: string; anchor: string; text: string; visibility: 'private' | 'shared' }[];
  updatedAt: string;
}

export interface WhiteboardPage {
  id: string;
  title: string;
  imageData?: string;
  updatedAt: string;
}
