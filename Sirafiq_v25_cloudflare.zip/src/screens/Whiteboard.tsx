import { useEffect, useRef, useState } from 'react';

type Tool='pen'|'eraser';
type Page={id:string;title:string;image?:string};
const colors=['#172332','#4b2340','#2e716b','#315f9a','#c85c55','#d19b35'];
const makePage=(n:number):Page=>({id:crypto.randomUUID(),title:`Page ${n}`});

export function Whiteboard(){
  const canvas=useRef<HTMLCanvasElement>(null); const ctxRef=useRef<CanvasRenderingContext2D|null>(null);
  const [pages,setPages]=useState<Page[]>(()=>{try{return JSON.parse(localStorage.getItem('sirafiq-whiteboard-pages')||'null')||[makePage(1)]}catch{return [makePage(1)]}});
  const [pageId,setPageId]=useState(pages[0].id); const [tool,setTool]=useState<Tool>('pen'); const [color,setColor]=useState(colors[0]); const [width,setWidth]=useState(3); const [history,setHistory]=useState<string[]>([]); const [future,setFuture]=useState<string[]>([]);
  const current=pages.find(p=>p.id===pageId)??pages[0];
  function snapshot(){const c=canvas.current;return c?.toDataURL('image/png')||''}
  function persist(next=pages){localStorage.setItem('sirafiq-whiteboard-pages',JSON.stringify(next))}
  function saveCurrent(nextImage=snapshot()){setPages(prev=>{const next=prev.map(p=>p.id===pageId?{...p,image:nextImage}:p);persist(next);return next})}
  function paint(image?:string){const c=canvas.current,ctx=ctxRef.current;if(!c||!ctx)return;ctx.clearRect(0,0,c.width,c.height);if(image){const im=new Image();im.onload=()=>ctx.drawImage(im,0,0,c.clientWidth,c.clientHeight);im.src=image}}
  useEffect(()=>{const c=canvas.current;if(!c)return;const resize=()=>{const old=snapshot();const r=c.getBoundingClientRect(),d=devicePixelRatio||1;c.width=r.width*d;c.height=r.height*d;const ctx=c.getContext('2d')!;ctx.setTransform(d,0,0,d,0,0);ctx.lineCap='round';ctx.lineJoin='round';ctxRef.current=ctx;paint(old||current.image)};resize();let drawing=false;let before='';const pt=(e:PointerEvent)=>{const r=c.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top}};const down=(e:PointerEvent)=>{drawing=true;before=snapshot();c.setPointerCapture(e.pointerId);const p=pt(e);const ctx=ctxRef.current!;ctx.beginPath();ctx.moveTo(p.x,p.y)};const move=(e:PointerEvent)=>{if(!drawing)return;const p=pt(e),ctx=ctxRef.current!;ctx.globalCompositeOperation=tool==='eraser'?'destination-out':'source-over';ctx.strokeStyle=color;ctx.lineWidth=tool==='eraser'?Math.max(18,width*6):width;ctx.lineTo(p.x,p.y);ctx.stroke()};const up=()=>{if(!drawing)return;drawing=false;ctxRef.current!.globalCompositeOperation='source-over';setHistory(h=>[...h,before].slice(-30));setFuture([]);saveCurrent()};c.addEventListener('pointerdown',down);c.addEventListener('pointermove',move);c.addEventListener('pointerup',up);c.addEventListener('pointercancel',up);window.addEventListener('resize',resize);return()=>{c.removeEventListener('pointerdown',down);c.removeEventListener('pointermove',move);c.removeEventListener('pointerup',up);c.removeEventListener('pointercancel',up);window.removeEventListener('resize',resize)}},[pageId,tool,color,width]);
  useEffect(()=>{paint(current.image);setHistory([]);setFuture([])},[pageId]);
  function addPage(){saveCurrent();const p=makePage(pages.length+1);const next=[...pages,p];setPages(next);persist(next);setPageId(p.id)}
  function removePage(){if(pages.length===1){paint();saveCurrent('');return}const i=pages.findIndex(p=>p.id===pageId);const next=pages.filter(p=>p.id!==pageId);setPages(next);persist(next);setPageId(next[Math.max(0,i-1)].id)}
  function undo(){if(!history.length)return;const now=snapshot(),img=history[history.length-1];setHistory(h=>h.slice(0,-1));setFuture(f=>[...f,now]);paint(img);saveCurrent(img)}
  function redo(){if(!future.length)return;const now=snapshot(),img=future[future.length-1];setFuture(f=>f.slice(0,-1));setHistory(h=>[...h,now]);paint(img);saveCurrent(img)}
  function clearPage(){const before=snapshot();setHistory(h=>[...h,before]);paint();saveCurrent('')}
  return <div className="whiteboard-v18">
    <header className="whiteboard-head glass-panel"><div><span className="eyebrow">Tableau blanc</span><h1>Écrire sans manquer de place.</h1><p>Une page pour une idée, autant de pages que nécessaire. Le travail reste local sur l’iPad.</p></div><div className="board-head-actions"><button onClick={undo} disabled={!history.length}>↶ Annuler</button><button onClick={redo} disabled={!future.length}>↷ Rétablir</button><button className="primary-small" onClick={addPage}>＋ Page</button></div></header>
    <div className="whiteboard-workspace">
      <aside className="board-pages glass-panel"><header><strong>Pages</strong><button onClick={addPage}>＋</button></header>{pages.map((p,i)=><button className={p.id===pageId?'active':''} onClick={()=>{saveCurrent();setPageId(p.id)}} key={p.id}><span>{i+1}</span><div><strong>{p.title}</strong><small>{p.image?'écrite':'vierge'}</small></div></button>)}<button className="page-delete" onClick={removePage}>Supprimer cette page</button></aside>
      <section className="board-sheet-wrap"><div className="board-toolbar glass-panel"><div className="tool-toggle"><button className={tool==='pen'?'active':''} onClick={()=>setTool('pen')}>✎ Stylo</button><button className={tool==='eraser'?'active':''} onClick={()=>setTool('eraser')}>⌫ Gomme locale</button></div><div className="pen-colors">{colors.map(c=><button aria-label={`Couleur ${c}`} className={color===c?'active':''} style={{background:c}} onClick={()=>{setColor(c);setTool('pen')}} key={c}/>)}</div><label>Épaisseur <input type="range" min="1" max="10" value={width} onChange={e=>setWidth(Number(e.target.value))}/></label><button className="quiet-action" onClick={clearPage}>Effacer la page</button></div><div className="board-paper"><canvas ref={canvas}/><div className="paper-lines"/></div></section>
    </div>
  </div>
}
