import type { LearnMode, Mastery, MindMapRecord, SupportRecord } from '../types';
import type { TrackLanguage } from '../dataCurriculum';
import { LearnTabs } from '../components/LearnTabs';
import { Academy } from './Academy';
import { Memory } from './Memory';
import { Maps } from './Maps';
import { Pronunciation } from './Pronunciation';
import { Writing } from './Writing';

export function Learn({ mode, setMode, language, setLanguage, support, onPickSupport, onRate, onSaveMap }: {
  mode: LearnMode; setMode: (m: LearnMode) => void; language: TrackLanguage; setLanguage:(l:TrackLanguage)=>void;
  support?: SupportRecord; onPickSupport: () => void; onRate: (mastery: Mastery, technique: string) => Promise<void>; onSaveMap: (map: MindMapRecord) => Promise<void>;
}) {
  const title=mode==='academy'?'Deux cursus, deux progressions.':mode==='memory'?'Réviser progressivement.':mode==='pronunciation'?(language==='fr'?'Former l’oreille et la voix françaises.':'Former l’oreille et la lecture arabes.'):mode==='writing'?(language==='fr'?'Construire une écriture française lisible et fluide.':'Apprendre le tracé arabe avec rigueur.'):'Voir les relations, pas une liste.';
  return <div className="screen learn-screen v21-learn">
    <header className="learn-head v17-learn-head"><div><span className="eyebrow">Apprendre</span><h1>{title}</h1><p>{mode==='academy'?'Le français et l’arabe sont séparés. Choisissez d’abord le cursus, puis la compétence.':mode==='memory'?'Une séance suit une montée en difficulté : rappel, précision, flashcards, production et structure.':mode==='pronunciation'?(language==='fr'?'Le français suit un parcours son → syllabe → mot → phrase → lecture fluide.':'L’arabe reste distinct et centré ici sur l’écoute et la lecture; l’écriture se travaille dans son atelier dédié.'):mode==='writing'?(language==='fr'?'Repères Seyès simplifiés, familles de gestes, lettres, mots, copie, dictée puis autonomie.':'Ligne de base, zones de hauteur, formes contextuelles, connexions, mots puis calligraphies distinctes.'):'Créez une carte librement ou structurez un support.'}</p></div><LearnTabs mode={mode} setMode={setMode}/></header>
    <div className="learn-workspace">
      {mode === 'academy' && <Academy onOpen={(m,l)=>{setLanguage(l);setMode(m)}}/>}
      {mode === 'memory' && <Memory support={support} onPickSupport={onPickSupport} onRate={onRate} onOpenMap={() => setMode('maps')} />}
      {mode === 'pronunciation' && <Pronunciation language={language} onChangeLanguage={setLanguage}/>} 
      {mode === 'writing' && <Writing language={language} onChangeLanguage={setLanguage}/>} 
      {mode === 'maps' && <Maps support={support} onSave={onSaveMap}/>} 
    </div>
  </div>;
}
