# Sirāfiq V24 — Travail réel

- Studio de transcription : zone principale nettement agrandie, particulièrement sur iPad.
- Donner un cours : les ajouts sont ancrés à un repère textuel du support associé.
- À l’enregistrement, les ajouts sont également enregistrés dans le support et réapparaissent pendant la révision.
- Présentation : les notes privées/partagées restent distinctes.
- iPad : rail et colonnes secondaires réduits afin de rendre la surface au travail.
- Aucun exercice de texte à trous.
