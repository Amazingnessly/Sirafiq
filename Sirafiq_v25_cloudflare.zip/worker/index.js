const json = (data, init = {}) => new Response(JSON.stringify(data), {
  ...init,
  headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...(init.headers || {}) }
});

async function voice(request, env) {
  if (!env.AI) return json({ error: "Binding Workers AI 'AI' non configuré" }, { status: 503 });
  const body = await request.json().catch(() => ({}));
  const text = String(body.text || '').trim();
  const lang = String(body.lang || 'fr').toLowerCase().startsWith('ar') ? 'ar' : 'fr';
  if (!text) return json({ error: 'Texte vide' }, { status: 400 });
  try {
    const response = await env.AI.run('@cf/myshell-ai/melotts', {
      prompt: text.slice(0, 1200),
      lang,
    }, { returnRawResponse: true });
    if (response instanceof Response) {
      const headers = new Headers(response.headers);
      if (!headers.get('content-type')) headers.set('content-type', 'audio/mpeg');
      headers.set('cache-control', 'no-store');
      return new Response(response.body, { status: response.status, headers });
    }
    if (response instanceof ArrayBuffer) {
      return new Response(response, { headers: { 'content-type': 'audio/mpeg', 'cache-control': 'no-store' } });
    }
    if (ArrayBuffer.isView(response)) {
      return new Response(response.buffer, { headers: { 'content-type': 'audio/mpeg', 'cache-control': 'no-store' } });
    }
    return json({ error: 'Réponse audio inattendue' }, { status: 502 });
  } catch (error) {
    return json({ error: error instanceof Error ? error.message : 'Synthèse vocale indisponible' }, { status: 502 });
  }
}

async function coach(request, env) {
  if (!env.AI) return json({ error: "Binding Workers AI 'AI' non configuré" }, { status: 503 });
  const data = await request.json().catch(() => ({}));
  const prompt = `Tu es Boussole, l'agent pédagogique de Sirāfiq. Tu aides l'utilisateur à décider QUOI FAIRE MAINTENANT et à préparer une séance concrète.

Règles absolues:
- Utilise uniquement les données fournies pour parler de la maîtrise ou des faiblesses de l'utilisateur. N'invente jamais un niveau.
- Donne une action immédiatement praticable, pas des conseils vagues.
- Si les données sont insuffisantes, commence par une courte activité diagnostique.
- Priorise rappel actif avant relecture, espacement, variation des exercices et feedback après tentative.
- N'utilise jamais d'exercice de texte à trous.
- Privilégie rappel libre, questions ouvertes, reconstruction de plan, reformulation, enseignement à quelqu'un, dictée, lecture à voix haute, comparaison après tentative et transfert.
- Pour le français: progression distincte autour de phonologie, décodage, lecture, écriture, dictée, compréhension et expression.
- Pour l'arabe: priorité à l'écriture; direction droite-gauche, ligne de base, proportions, geste, familles de formes, connexions, formes contextuelles, puis mots et phrases. Ne mélange pas ce parcours avec le français.
- Si un support est fourni avec consentement, les exercices doivent porter sur SON CONTENU réel et non sur des consignes génériques.
- Le temps total des étapes doit rester proche du temps disponible demandé.

Réponds en JSON STRICT et uniquement JSON avec :
{"title":"...","reason":"...","steps":[{"title":"...","detail":"...","duration":"..."}]}
3 à 5 étapes maximum.

Données utilisateur: ${JSON.stringify(data).slice(0, 14000)}`;
  try {
    const out = await env.AI.run('@cf/meta/llama-3.2-3b-instruct', {
      messages: [{ role: 'user', content: prompt }], max_tokens: 900, temperature: 0.2,
    });
    const raw = out?.response || out?.result?.response || '';
    let parsed;
    try { parsed = JSON.parse(String(raw).replace(/^```json\s*|\s*```$/g, '')); }
    catch {
      parsed = { title: 'Séance proposée par Sirāfiq', reason: 'Plan préparé à partir des données disponibles.', steps: [] };
    }
    return json(parsed);
  } catch (error) {
    return json({ error: error instanceof Error ? error.message : 'Boussole indisponible' }, { status: 502 });
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/api/health') {
      return json({ ok: true, app: 'sirafiq', runtime: 'cloudflare-workers', ai: Boolean(env.AI) });
    }
    if (url.pathname === '/api/voice' && request.method === 'POST') return voice(request, env);
    if (url.pathname === '/api/coach' && request.method === 'POST') return coach(request, env);
    if (url.pathname.startsWith('/api/')) return json({ error: 'Route API inconnue' }, { status: 404 });
    return env.ASSETS.fetch(request);
  }
};
