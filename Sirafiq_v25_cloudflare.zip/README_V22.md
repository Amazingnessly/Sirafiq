# Sirāfiq V22 — consolidation pédagogique et fonctionnelle

Cette version part de V21 et traite en priorité les blocages signalés sur iPad.

## Changements principaux

- Import Bibliothèque conservant l'original avant toute extraction de texte.
- Transmission : même principe de sauvegarde de l'original avant analyse, puis association immédiate au cours.
- Cursus français et arabe séparés, avec davantage de leçons progressives.
- Français : geste graphique, réglure scolaire, familles de lettres, encodage, copie, dictée, décodage et fluidité.
- Arabe : écriture prioritaire, ligne de base, proportions, point comme repère de mesure, familles, connexions, formes contextuelles, mots et copie.
- Prononciation : passage de la langue au endpoint vocal, fallback système, nouvelle prise micro réinitialisée proprement.
- Mémorisation : progression étendue du repérage au rappel libre, flashcards multi-cartes, productions et carte mentale.
- Carte mentale : vocabulaire d'interface simplifié (idée / branche), création libre ou depuis un support.
- Studio de transcription : vidéo YouTube via IFrame API, timecodes, segments, vitesse et fallback vers YouTube si l'intégration est refusée.
- Médiathèque : boutons Transformer réellement câblés vers Révision et Transcription.
- Mise en page iPad élargie : colonnes moins étroites et panneaux de travail plus grands.

## Repères pédagogiques utilisés

Pour le français, la réglure s'inspire des usages scolaires de la réglure Seyès et des variantes pédagogiques de cursive (corps de lettre, ascendantes et descendantes). Les repères visuels restent simplifiés pour l'écran tactile.

Pour l'arabe, le guide n'affirme pas remplacer l'enseignement d'un maître calligraphe : il met en avant la ligne de base et le système de proportions par points utilisé historiquement en calligraphie arabe, notamment pour comprendre l'Alif et les rapports entre formes.

## Validation attendue dans Codespaces

1. `npm install`
2. `npm run build`
3. Tester sur iPad : import PDF, Transmission + document, voix, Refaire une prise, écriture FR/AR, flashcards, carte mentale, Studio YouTube.
4. Ne déployer qu'après ces tests.
