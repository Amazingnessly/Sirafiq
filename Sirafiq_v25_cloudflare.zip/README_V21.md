# Sirāfiq V21 — consolidation ciblée

Priorités de cette passe : import non bloquant (original enregistré avant extraction), Transmission avec ajout de document et envoi du cours vers les révisions, cursus français/arabe visuellement séparés, repères d’écriture distincts français/arabe, espaces iPad élargis, voix locale plus robuste et bouton Refaire une prise réinitialisé, mémorisation progressive avec Flashcards et Carte mentale visibles.
