# Sirāfiq V25 — socle Cloudflare Workers

Cette version migre Sirāfiq de GitHub Pages / Pages Functions vers un Worker unique avec assets statiques.

## Architecture
- React/Vite dans `dist/`
- Worker: `worker/index.js`
- `/api/voice`: Workers AI MeloTTS
- `/api/coach`: Workers AI
- `/api/health`: diagnostic simple
- autres routes: assets React via `env.ASSETS`

## Déploiement
`npm install && npm run deploy`

Après déploiement, vérifier `/api/health` avant de tester les voix.
