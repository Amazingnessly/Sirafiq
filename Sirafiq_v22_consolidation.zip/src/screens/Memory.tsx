import { useMemo, useState } from 'react';
import type { Mastery, SupportRecord } from '../types';
import { makeQuestions, supportSummary } from '../lib/support';

const exercises=[
  {id:'recognition',label:'Repérage',kind:'Échauffement',hint:'Identifier les idées avant de les produire'},
  {id:'cue',label:'Rappel avec indices',kind:'Récupération guidée',hint:'Retrouver avec une aide minimale'},
  {id:'cloze',label:'Texte à trous',kind:'Précision',hint:'Retrouver les mots structurants'},
  {id:'flashcards',label:'Flashcards',kind:'Rappel espacé',hint:'Plusieurs cartes, retournement puis décision'},
  {id:'questions',label:'Questions ciblées',kind:'Compréhension',hint:'Répondre sans relire le support'},
  {id:'recall',label:'Rappel libre',kind:'Récupération',hint:'Restituer sans aucun indice'},
  {id:'written',label:'Restitution écrite',kind:'Production',hint:'Reconstruire le plan de mémoire'},
  {id:'oral',label:'Restitution orale',kind:'Expression',hint:'Dire sans lire puis vérifier'},
  {id:'teach',label:'Expliquer à quelqu’un',kind:'Transfert',hint:'Reformuler et donner un exemple'},
  {id:'map',label:'Carte mentale',kind:'Structure',hint:'Reconstruire les relations entre les idées'}
] as const;
type Technique=typeof exercises[number]['id'];

export function Memory({support,onPickSupport,onRate,onOpenMap}:{support?:SupportRecord;onPickSupport:()=>void;onRate:(mastery:Mastery,technique:string)=>Promise<void>;onOpenMap:()=>void}){
  const[technique,setTechnique]=useState<Technique>('recognition');
  const[phase,setPhase]=useState<'plan'|'attempt'|'verify'|'done'>('plan');
  const[answer,setAnswer]=useState('');
  const[step,setStep]=useState(0);
  const[cardIndex,setCardIndex]=useState(0);
  const[cardBack,setCardBack]=useState(false);

  const prompts=useMemo(()=>support?.text?makeQuestions(support.text):[],[support]);
  const summary=useMemo(()=>support?.text?supportSummary(support.text):[],[support]);
  const first=summary[0]??'';
  const words=first.split(/\s+/).filter(w=>w.length>4);
  const blank=words[Math.min(2,Math.max(0,words.length-1))]??'notion';
  const cards=useMemo(()=>{
    const base=(summary.length?summary:[support?.title||'Support']).slice(0,6);
    return base.map((text,i)=>({question:prompts[i]||`Restituez l’idée ${i+1} sans regarder.`,answer:text}));
  },[summary,prompts,support?.title]);
  const currentCard=cards[Math.min(cardIndex,cards.length-1)];

  const plan=useMemo<Technique[]>(()=>support?.text
    ? ['recognition','cue','cloze','flashcards','questions','recall','written','oral','teach','map']
    : ['recognition','cue','flashcards','recall','written','oral','teach','map'],[support]);

  if(!support)return <div className="workspace-empty v22-memory-empty"><span className="eyebrow">Révision guidée</span><h2>Choisissez une matière à réviser.</h2><p>Sirāfiq construit une montée progressive : reconnaître, récupérer avec indices, utiliser des flashcards, restituer sans aide puis structurer en carte mentale.</p><button className="primary-action" onClick={onPickSupport}>Choisir un support</button></div>;

  const selected=exercises.find(x=>x.id===technique)!;
  const prompt=technique==='recognition'?`Avant de relire, notez 3 mots ou idées que vous associez à « ${support.title} ».`
    :technique==='cue'?`Indice : ${first?first.split(' ').slice(0,5).join(' ')+'…':'pensez au titre et au plan'}. Que pouvez-vous reconstruire ?`
    :technique==='flashcards'?currentCard.question
    :technique==='questions'?(prompts[0]||'Quelle est l’idée principale ?')
    :technique==='cloze'?(first?first.replace(blank,'________'):'Complétez l’idée principale.')
    :technique==='teach'?'Expliquez cette notion simplement, puis donnez un exemple concret.'
    :technique==='written'?'Écrivez le plan du support sans le consulter.'
    :technique==='oral'?'Restituez à voix haute, puis notez vos hésitations.'
    :technique==='map'?'Reconstituez les relations entre les idées principales.'
    :'Qu’avez-vous réellement retenu ?';

  function selectStep(i:number,id:Technique){setStep(i);setTechnique(id);setPhase('plan');setAnswer('');setCardIndex(0);setCardBack(false)}
  function nextCard(){setCardIndex(i=>(i+1)%cards.length);setCardBack(false)}

  return <div className="memory-v22">
    <aside className="revision-plan glass-panel">
      <span className="eyebrow">Séance progressive</span><h2>{support.title}</h2><p>Les aides diminuent au fil de la séance. Vous n’avez pas besoin de faire les dix étapes à chaque fois : Sirāfiq garde la progression visible.</p>
      <ol>{plan.map((id,i)=>{const x=exercises.find(e=>e.id===id)!;return <li className={i===step?'active':i<step?'done':''} key={id}><b>{i<step?'✓':i+1}</b><button onClick={()=>selectStep(i,id)}><strong>{x.label}</strong><small>{x.hint}</small></button><em>{i<3?'3 min':i<7?'5 min':'6 min'}</em></li>})}</ol>
      <div className="memory-tools-v22"><button className="quiet-action" onClick={()=>selectStep(plan.indexOf('flashcards'),'flashcards')}>▣ Flashcards</button><button className="quiet-action" onClick={onOpenMap}>⌘ Carte mentale</button></div>
      <button className="quiet-action" onClick={onPickSupport}>Changer de support</button>
    </aside>
    <section className="revision-stage">
      {phase==='plan'?<div className="exercise-launch"><span className="exercise-kind">Étape {step+1}/{plan.length} · {selected.kind}</span><h2>{selected.label}</h2><p>{selected.hint}. Le support reste caché pendant la tentative.</p><div className="exercise-preview"><span>Consigne</span><strong>{prompt}</strong></div>{technique==='map'?<button className="primary-action" onClick={onOpenMap}>Ouvrir la carte mentale <span>→</span></button>:<button className="primary-action" onClick={()=>setPhase('attempt')}>Commencer cette étape <span>→</span></button>}</div>:null}
      {phase==='attempt'?<div className="attempt-panel v22-attempt"><div className="step-line"><span className="active">1 Tenter</span><span>2 Comparer</span><span>3 Programmer</span></div><h2>{prompt}</h2>
        {technique==='flashcards'?<div className="flashcard-deck"><div className="flashcard-counter">Carte {cardIndex+1}/{cards.length}</div><button className={`flashcard ${cardBack?'back':''}`} onClick={()=>setCardBack(v=>!v)}>{cardBack?<span><small>Réponse / repère</small><strong>{currentCard.answer||'Aucun extrait disponible.'}</strong></span>:<span><small>Question</small><strong>{currentCard.question}</strong></span>}</button><div className="flashcard-controls"><button className="quiet-action" onClick={()=>setCardBack(v=>!v)}>{cardBack?'Voir la question':'Retourner'}</button><button className="primary-small" onClick={nextCard}>Carte suivante →</button></div></div>:<textarea autoFocus value={answer} onChange={e=>setAnswer(e.target.value)} placeholder={technique==='oral'?'Après avoir parlé, notez ici vos oublis ou hésitations.':'Répondez sans regarder le support.'}/>}<button className="primary-action" onClick={()=>setPhase('verify')}>Comparer avec le support</button></div>:null}
      {phase==='verify'?<div className="verify-panel"><div className="compare-columns"><article><span className="eyebrow">Votre tentative</span><p>{technique==='flashcards'?`Vous avez parcouru ${cards.length} carte(s).`:answer||'Tentative orale effectuée.'}</p></article><article><span className="eyebrow">Support</span><p>{support.text?.slice(0,1800)||'Ouvrez l’original pour vérifier précisément.'}</p></article></div><div className="mastery-bar"><div><span className="eyebrow">Décision</span><h3>À quel point cette information était-elle accessible sans aide ?</h3></div><div className="mastery-buttons">{([['again','À revoir'],['fragile','Fragile'],['acquired','Acquis'],['mastered','Maîtrisé']] as [Mastery,string][]).map(([m,l])=><button key={m} onClick={async()=>{await onRate(m,technique);if(step<plan.length-1){const n=step+1;selectStep(n,plan[n])}else setPhase('done')}}>{l}</button>)}</div></div></div>:null}
      {phase==='done'?<div className="complete-panel"><div className="complete-mark">✓</div><span className="eyebrow">Séance terminée</span><h2>La prochaine révision est programmée.</h2><p>Sirāfiq pourra repartir d’une activité plus ou moins guidée selon votre dernière récupération.</p><button className="primary-action" onClick={()=>selectStep(0,plan[0])}>Refaire une séance</button></div>:null}
    </section>
  </div>;
}
