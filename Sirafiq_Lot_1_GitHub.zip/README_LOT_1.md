# Sirāfiq — Lot 1

Ce lot ajoute un véritable parcours d’import local :

- sélection depuis Fichiers ;
- sélection depuis Photos ;
- PDF, images, textes, documents et audios ;
- aperçu avant validation ;
- titre et catégorie ;
- conservation du fichier original dans IndexedDB ;
- bibliothèque persistante ;
- recherche et filtres ;
- ouverture/export ;
- suppression volontaire avec confirmation.

## Ce lot ne contient pas encore

- l’enregistrement du microphone ;
- les passages de mémorisation ;
- les révisions quotidiennes ;
- les mindmaps ;
- les exercices de prononciation.

Ces fonctions restent séparées afin qu’aucun faux bouton ne soit présenté comme fonctionnel.
