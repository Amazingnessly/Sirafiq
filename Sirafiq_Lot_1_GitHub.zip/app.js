
import {
  addDiagnostic,
  addSupport,
  clearDiagnostics,
  countSupports,
  deleteSupport,
  getSupport,
  listDiagnostics,
  listSupports,
  testIndexedDbAvailability,
  totalSupportBytes,
  writeLocalProbe
} from './db.js';

const views = [...document.querySelectorAll('[data-view]')];
const navItems = [...document.querySelectorAll('[data-nav]')];
const diagnosticDialog = document.getElementById('diagnosticDialog');
const importDialog = document.getElementById('importDialog');
const supportDialog = document.getElementById('supportDialog');
const diagnosticList = document.getElementById('diagnosticList');
const diagnosticNote = document.getElementById('diagnosticNote');
const networkBadge = document.getElementById('networkBadge');
const toast = document.getElementById('toast');

const filePicker = document.getElementById('filePicker');
const photoPicker = document.getElementById('photoPicker');
const importSourceStep = document.getElementById('importSourceStep');
const importReviewStep = document.getElementById('importReviewStep');
const selectedFilesEl = document.getElementById('selectedFiles');
const previewStage = document.getElementById('previewStage');
const importTitle = document.getElementById('importTitle');
const importCategory = document.getElementById('importCategory');
const fileMetadata = document.getElementById('fileMetadata');
const importFeedback = document.getElementById('importFeedback');

const supportGrid = document.getElementById('supportGrid');
const libraryEmpty = document.getElementById('libraryEmpty');
const supportSearch = document.getElementById('supportSearch');
const supportCategoryFilter = document.getElementById('supportCategoryFilter');

let stagedFiles = [];
let selectedStagedIndex = 0;
let activePreviewUrl = null;
let activeSupportUrl = null;
let currentSupportId = null;
let toastTimer;

const diagnosticDefinitions = [
  { key: 'secure', label: 'Contexte sécurisé', detail: 'Requis pour les fonctions sensibles' },
  { key: 'serviceWorker', label: 'Service worker', detail: 'Permet le mode hors ligne' },
  { key: 'indexedDb', label: 'Stockage IndexedDB', detail: 'Conserve les supports localement' },
  { key: 'mediaDevices', label: 'Fonctions audio', detail: 'Prépare le futur enregistreur' },
  { key: 'pointerEvents', label: 'Tactile et stylet', detail: 'Prépare le module d’écriture' },
  { key: 'fileInput', label: 'Sélection de fichiers', detail: 'Utilisée par le Lot 1' },
  { key: 'installed', label: 'Mode application', detail: 'Indique si Sirāfiq est installé' }
];

function showToast(message) {
  clearTimeout(toastTimer);
  toast.textContent = message;
  toast.classList.add('visible');
  toastTimer = setTimeout(() => toast.classList.remove('visible'), 3000);
}

function openModal(dialog) {
  if (typeof dialog.showModal === 'function') dialog.showModal();
  else dialog.setAttribute('open', '');
}

function closeModal(dialog) {
  if (typeof dialog.close === 'function') dialog.close();
  else dialog.removeAttribute('open');
}

function revokePreviewUrls() {
  if (activePreviewUrl) URL.revokeObjectURL(activePreviewUrl);
  if (activeSupportUrl) URL.revokeObjectURL(activeSupportUrl);
  activePreviewUrl = null;
  activeSupportUrl = null;
}

function currentRoute() {
  const route = location.hash.replace('#', '').toLowerCase();
  return views.some(view => view.dataset.view === route) ? route : 'accueil';
}

function renderRoute() {
  const route = currentRoute();

  views.forEach(view => {
    const active = view.dataset.view === route;
    view.hidden = !active;
    view.classList.toggle('active', active);
  });

  navItems.forEach(item =>
    item.classList.toggle('active', item.dataset.nav === route)
  );

  document.getElementById('mainContent').focus({ preventScroll: true });
  window.scrollTo({
    top: 0,
    behavior: matchMedia('(prefers-reduced-motion: reduce)').matches
      ? 'auto'
      : 'smooth'
  });

  if (route === 'memoriser') refreshLibrary();
  if (route === 'progres') refreshMetrics();
}

function updateNetworkStatus() {
  const online = navigator.onLine;
  networkBadge.textContent = online ? 'En ligne' : 'Hors ligne';
  networkBadge.className = `offline-badge ${online ? 'online' : 'offline'}`;
}

function formatBytes(bytes) {
  const value = Number(bytes) || 0;
  if (value < 1024) return `${value} o`;

  const units = ['Ko', 'Mo', 'Go', 'To'];
  let current = value / 1024;
  let index = 0;

  while (current >= 1024 && index < units.length - 1) {
    current /= 1024;
    index += 1;
  }

  const decimals = current >= 10 ? 0 : 1;
  return `${current.toFixed(decimals).replace('.', ',')} ${units[index]}`;
}

function formatDate(iso) {
  return new Date(iso).toLocaleDateString('fr-FR', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
}

function inferKind(file) {
  const type = (file.type || '').toLowerCase();
  const name = file.name.toLowerCase();

  if (type.startsWith('image/')) return 'image';
  if (type.startsWith('audio/')) return 'audio';
  if (type === 'application/pdf' || name.endsWith('.pdf')) return 'pdf';
  if (
    type.startsWith('text/') ||
    /\.(txt|md|markdown|csv|json)$/i.test(name)
  ) return 'text';
  if (/\.(doc|docx|odt|rtf)$/i.test(name)) return 'document';
  return 'file';
}

function kindLabel(kind) {
  return {
    image: 'Image',
    audio: 'Audio',
    pdf: 'PDF',
    text: 'Texte',
    document: 'Document',
    file: 'Fichier'
  }[kind] || 'Fichier';
}

function kindIcon(kind) {
  return {
    image: '▧',
    audio: '◖',
    pdf: 'PDF',
    text: 'T',
    document: 'DOC',
    file: '▤'
  }[kind] || '▤';
}

function titleFromFile(file) {
  return file.name.replace(/\.[^.]+$/, '').trim() || file.name;
}

function openImportDialog() {
  resetImportDialog();
  openModal(importDialog);
}

function resetImportDialog() {
  revokePreviewUrls();
  stagedFiles = [];
  selectedStagedIndex = 0;
  importSourceStep.hidden = false;
  importReviewStep.hidden = true;
  selectedFilesEl.innerHTML = '';
  previewStage.innerHTML = '<p>Sélectionnez un fichier pour afficher son aperçu.</p>';
  importTitle.value = '';
  importCategory.value = 'Français';
  fileMetadata.innerHTML = '';
  importFeedback.textContent = '';
  filePicker.value = '';
  photoPicker.value = '';
}

function stageFiles(fileList) {
  const files = [...fileList];

  if (!files.length) return;

  const accepted = files.filter(file => file.size > 0);
  if (!accepted.length) {
    importFeedback.textContent = 'Aucun fichier exploitable n’a été sélectionné.';
    return;
  }

  stagedFiles.push(...accepted);
  selectedStagedIndex = Math.max(0, stagedFiles.length - accepted.length);
  importSourceStep.hidden = true;
  importReviewStep.hidden = false;
  renderStagedFiles();
  selectStagedFile(selectedStagedIndex);
}

function renderStagedFiles() {
  selectedFilesEl.innerHTML = stagedFiles.map((file, index) => `
    <button class="selected-file-chip ${index === selectedStagedIndex ? 'active' : ''}"
      type="button" data-staged-index="${index}">
      <span>${kindIcon(inferKind(file))}</span>
      <span>
        <strong>${escapeHtml(file.name)}</strong>
        <small>${formatBytes(file.size)}</small>
      </span>
    </button>
  `).join('');
}

async function selectStagedFile(index) {
  if (!stagedFiles[index]) return;

  selectedStagedIndex = index;
  renderStagedFiles();

  const file = stagedFiles[index];
  const kind = inferKind(file);

  importTitle.value = titleFromFile(file);
  fileMetadata.innerHTML = `
    <div><dt>Type</dt><dd>${kindLabel(kind)}</dd></div>
    <div><dt>Format</dt><dd>${escapeHtml(file.type || 'Non déclaré')}</dd></div>
    <div><dt>Taille</dt><dd>${formatBytes(file.size)}</dd></div>
    <div><dt>Nom original</dt><dd>${escapeHtml(file.name)}</dd></div>
  `;

  await renderFilePreview(file, previewStage);
}

async function renderFilePreview(file, container) {
  if (activePreviewUrl) URL.revokeObjectURL(activePreviewUrl);
  activePreviewUrl = URL.createObjectURL(file);

  const kind = inferKind(file);
  container.className = `preview-stage preview-${kind}`;

  if (kind === 'image') {
    container.innerHTML = `<img src="${activePreviewUrl}" alt="Aperçu de ${escapeHtml(file.name)}">`;
    return;
  }

  if (kind === 'audio') {
    container.innerHTML = `
      <div class="generic-preview">
        <span class="large-kind-icon">◖</span>
        <strong>${escapeHtml(file.name)}</strong>
        <audio controls preload="metadata" src="${activePreviewUrl}"></audio>
      </div>
    `;
    return;
  }

  if (kind === 'pdf') {
    container.innerHTML = `
      <object data="${activePreviewUrl}" type="application/pdf">
        <div class="generic-preview">
          <span class="large-kind-icon">PDF</span>
          <p>L’aperçu PDF n’est pas disponible dans cette vue. Le fichier pourra néanmoins être conservé et ouvert.</p>
        </div>
      </object>
    `;
    return;
  }

  if (kind === 'text' && file.size <= 2_000_000) {
    try {
      const text = await file.text();
      container.innerHTML = `<pre>${escapeHtml(text.slice(0, 12000))}</pre>`;
    } catch {
      container.innerHTML = genericFilePreview(file, kind);
    }
    return;
  }

  container.innerHTML = genericFilePreview(file, kind);
}

function genericFilePreview(file, kind) {
  return `
    <div class="generic-preview">
      <span class="large-kind-icon">${kindIcon(kind)}</span>
      <strong>${escapeHtml(file.name)}</strong>
      <p>${kind === 'document'
        ? 'Ce document sera conservé dans sa forme originale. Son texte ne sera pas modifié.'
        : 'Aucun aperçu intégré n’est disponible pour ce format.'}</p>
    </div>
  `;
}

async function ensureStoragePersistence() {
  if (!navigator.storage || typeof navigator.storage.persist !== 'function') {
    return false;
  }

  try {
    return await navigator.storage.persist();
  } catch {
    return false;
  }
}

async function saveStagedFiles() {
  if (!stagedFiles.length) return;

  const button = document.getElementById('saveSelectedFiles');
  button.disabled = true;
  importFeedback.textContent = 'Enregistrement local en cours…';

  try {
    await ensureStoragePersistence();

    for (let index = 0; index < stagedFiles.length; index += 1) {
      const file = stagedFiles[index];
      const customTitle = index === selectedStagedIndex
        ? importTitle.value.trim()
        : titleFromFile(file);

      if (!customTitle) {
        throw new Error(`Le titre de « ${file.name} » est vide`);
      }

      await addSupport({
        title: customTitle,
        category: importCategory.value,
        kind: inferKind(file),
        originalName: file.name,
        mimeType: file.type || 'application/octet-stream',
        size: file.size,
        lastModified: file.lastModified || null,
        blob: file,
        source: 'user-import',
        lockedOriginal: true
      });
    }

    const count = stagedFiles.length;
    closeModal(importDialog);
    resetImportDialog();
    showToast(`${count} support${count > 1 ? 's' : ''} enregistré${count > 1 ? 's' : ''} localement.`);
    location.hash = 'memoriser';
    await refreshLibrary();
    await refreshMetrics();
  } catch (error) {
    importFeedback.textContent = `Échec de l’enregistrement : ${error.message}`;
  } finally {
    button.disabled = false;
  }
}

function supportCard(support) {
  return `
    <article class="support-card" data-support-id="${support.id}">
      <button class="support-open-area" type="button" data-open-support="${support.id}">
        <span class="support-kind">${kindIcon(support.kind)}</span>
        <span class="support-card-content">
          <span class="support-card-topline">
            <span class="category-badge">${escapeHtml(support.category)}</span>
            <small>${formatBytes(support.size)}</small>
          </span>
          <strong>${escapeHtml(support.title)}</strong>
          <small>${kindLabel(support.kind)} · ${formatDate(support.createdAt)}</small>
        </span>
        <span class="support-arrow" aria-hidden="true">›</span>
      </button>
    </article>
  `;
}

async function refreshLibrary() {
  try {
    const supports = await listSupports();
    const query = supportSearch.value.trim().toLocaleLowerCase('fr');
    const category = supportCategoryFilter.value;

    const filtered = supports
      .filter(item => !query || item.titleSearch.includes(query))
      .filter(item => !category || item.category === category)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    supportGrid.innerHTML = filtered.map(supportCard).join('');
    libraryEmpty.hidden = supports.length > 0;
    supportGrid.hidden = filtered.length === 0;
    document.getElementById('libraryCount').textContent =
      `${supports.length} support${supports.length > 1 ? 's' : ''}`;
    document.getElementById('libraryBytes').textContent =
      formatBytes(supports.reduce((sum, item) => sum + (item.size || 0), 0));

    if (supports.length && !filtered.length) {
      supportGrid.hidden = false;
      supportGrid.innerHTML = `
        <div class="empty-filter-result">
          Aucun support ne correspond à ces critères.
        </div>
      `;
    }
  } catch (error) {
    supportGrid.innerHTML = `
      <div class="empty-filter-result">
        La bibliothèque locale n’a pas pu être lue : ${escapeHtml(error.message)}
      </div>
    `;
  }
}

async function openSupport(id) {
  const support = await getSupport(id);
  if (!support) return;

  currentSupportId = support.id;
  if (activeSupportUrl) URL.revokeObjectURL(activeSupportUrl);
  activeSupportUrl = URL.createObjectURL(support.blob);

  document.getElementById('supportDialogTitle').textContent = support.title;
  document.getElementById('supportDialogCategory').textContent = support.category;
  document.getElementById('supportDetailMeta').innerHTML = `
    <span>${kindLabel(support.kind)}</span>
    <span>${formatBytes(support.size)}</span>
    <span>Ajouté le ${formatDate(support.createdAt)}</span>
    <span>Original verrouillé</span>
  `;

  const viewer = document.getElementById('supportViewer');
  viewer.className = `support-viewer support-viewer-${support.kind}`;

  if (support.kind === 'image') {
    viewer.innerHTML = `<img src="${activeSupportUrl}" alt="${escapeHtml(support.title)}">`;
  } else if (support.kind === 'audio') {
    viewer.innerHTML = `
      <div class="generic-preview">
        <span class="large-kind-icon">◖</span>
        <audio controls preload="metadata" src="${activeSupportUrl}"></audio>
      </div>
    `;
  } else if (support.kind === 'pdf') {
    viewer.innerHTML = `
      <object data="${activeSupportUrl}" type="application/pdf">
        <div class="generic-preview">
          <span class="large-kind-icon">PDF</span>
          <p>Utilisez « Ouvrir le fichier » si Safari n’affiche pas le PDF ici.</p>
        </div>
      </object>
    `;
  } else if (support.kind === 'text') {
    try {
      const text = await support.blob.text();
      viewer.innerHTML = `<pre>${escapeHtml(text.slice(0, 50000))}</pre>`;
    } catch {
      viewer.innerHTML = genericStoredPreview(support);
    }
  } else {
    viewer.innerHTML = genericStoredPreview(support);
  }

  openModal(supportDialog);
}

function genericStoredPreview(support) {
  return `
    <div class="generic-preview">
      <span class="large-kind-icon">${kindIcon(support.kind)}</span>
      <strong>${escapeHtml(support.originalName)}</strong>
      <p>Le fichier original est conservé localement. Utilisez le bouton ci-dessous pour l’ouvrir.</p>
    </div>
  `;
}

async function removeCurrentSupport() {
  if (!currentSupportId) return;

  const support = await getSupport(currentSupportId);
  if (!support) return;

  if (!confirm(`Supprimer définitivement « ${support.title} » de cet appareil ?`)) {
    return;
  }

  await deleteSupport(currentSupportId);
  currentSupportId = null;
  closeModal(supportDialog);
  revokePreviewUrls();
  showToast('Support supprimé.');
  await refreshLibrary();
  await refreshMetrics();
}

async function downloadCurrentSupport() {
  if (!currentSupportId) return;

  const support = await getSupport(currentSupportId);
  if (!support) return;

  const url = URL.createObjectURL(support.blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = support.originalName || support.title;
  anchor.rel = 'noopener';
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();

  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

async function refreshMetrics() {
  try {
    const [supportsCount, supportsBytes, diagnostics] = await Promise.all([
      countSupports(),
      totalSupportBytes(),
      listDiagnostics()
    ]);

    const plural = supportsCount > 1 ? 's' : '';
    document.getElementById('homeSupportCount').textContent = supportsCount;
    document.getElementById('homeStorageUsed').textContent =
      `${formatBytes(supportsBytes)} utilisé${plural}`;
    document.getElementById('progressSupportCount').textContent = supportsCount;
    document.getElementById('progressSupportBytes').textContent =
      formatBytes(supportsBytes);
    document.getElementById('diagnosticCount').textContent = diagnostics.length;
  } catch {
    document.getElementById('homeSupportCount').textContent = '—';
  }
}

function initialDiagnosticRows() {
  diagnosticList.innerHTML = diagnosticDefinitions.map(item => `
    <div class="diagnostic-item" data-test="${item.key}">
      <span class="result-dot" aria-hidden="true"></span>
      <div><strong>${item.label}</strong><div>${item.detail}</div></div>
      <small>Non testé</small>
    </div>
  `).join('');
}

function updateDiagnosticRow(key, result, value) {
  const row = diagnosticList.querySelector(`[data-test="${key}"]`);
  if (!row) return;
  row.className = `diagnostic-item ${result}`;
  row.querySelector('small').textContent = value;
}

function standaloneMode() {
  return window.matchMedia('(display-mode: standalone)').matches ||
    window.navigator.standalone === true;
}

async function runDiagnostics() {
  diagnosticNote.textContent = 'Tests en cours…';

  const results = {
    secure: {
      status: window.isSecureContext ? 'pass' : 'fail',
      value: window.isSecureContext ? 'Oui' : 'Non'
    },
    serviceWorker: {
      status: 'serviceWorker' in navigator ? 'pass' : 'fail',
      value: 'serviceWorker' in navigator ? 'Disponible' : 'Absent'
    },
    indexedDb: { status: 'warn', value: 'Test…' },
    mediaDevices: {
      status: navigator.mediaDevices &&
        typeof navigator.mediaDevices.getUserMedia === 'function'
        ? 'pass' : 'warn',
      value: navigator.mediaDevices &&
        typeof navigator.mediaDevices.getUserMedia === 'function'
        ? 'Disponible' : 'Non exposé'
    },
    pointerEvents: {
      status: 'PointerEvent' in window ? 'pass' : 'warn',
      value: 'PointerEvent' in window ? 'Disponible' : 'Limité'
    },
    fileInput: {
      status: typeof HTMLInputElement !== 'undefined' ? 'pass' : 'fail',
      value: typeof HTMLInputElement !== 'undefined' ? 'Disponible' : 'Absent'
    },
    installed: {
      status: standaloneMode() ? 'pass' : 'warn',
      value: standaloneMode() ? 'Installée' : 'Dans Safari'
    }
  };

  Object.entries(results).forEach(([key, item]) =>
    updateDiagnosticRow(key, item.status, item.value)
  );

  const dbOk = await testIndexedDbAvailability();
  results.indexedDb = {
    status: dbOk ? 'pass' : 'fail',
    value: dbOk ? 'Lecture/écriture OK' : 'Échec'
  };
  updateDiagnosticRow(
    'indexedDb',
    results.indexedDb.status,
    results.indexedDb.value
  );

  const passed = Object.values(results).filter(item => item.status === 'pass').length;
  const warnings = Object.values(results).filter(item => item.status === 'warn').length;
  const failed = Object.values(results).filter(item => item.status === 'fail').length;

  await addDiagnostic({
    createdAt: new Date().toISOString(),
    passed,
    warnings,
    failed,
    results
  });

  diagnosticNote.textContent = failed
    ? `${failed} fonction essentielle est indisponible.`
    : warnings
      ? `Socle utilisable avec ${warnings} point${warnings > 1 ? 's' : ''} à confirmer.`
      : 'Toutes les vérifications ont réussi.';

  await refreshMetrics();
}

async function testLocalStorage() {
  diagnosticNote.textContent = 'Écriture puis relecture d’une donnée locale…';

  try {
    const result = await writeLocalProbe();
    updateDiagnosticRow('indexedDb', 'pass', 'Lecture/écriture OK');
    diagnosticNote.textContent =
      `Test réussi à ${new Date(result.updatedAt).toLocaleTimeString('fr-FR', {
        hour: '2-digit',
        minute: '2-digit'
      })}.`;
    showToast('Le stockage local fonctionne.');
  } catch (error) {
    updateDiagnosticRow('indexedDb', 'fail', 'Échec');
    diagnosticNote.textContent = `Échec : ${error.message}`;
  }
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  })[character]);
}

async function registerServiceWorker() {
  if (!('serviceWorker' in navigator)) return;

  try {
    await navigator.serviceWorker.register('./sw.js', { scope: './' });
  } catch (error) {
    console.warn('Service worker non enregistré', error);
  }
}

window.addEventListener('hashchange', renderRoute);
window.addEventListener('online', updateNetworkStatus);
window.addEventListener('offline', updateNetworkStatus);

document.getElementById('homeImportButton').addEventListener('click', openImportDialog);
document.getElementById('libraryImportButton').addEventListener('click', openImportDialog);
document.getElementById('emptyImportButton').addEventListener('click', openImportDialog);
document.getElementById('chooseFilesButton').addEventListener('click', () => filePicker.click());
document.getElementById('choosePhotosButton').addEventListener('click', () => photoPicker.click());
document.getElementById('addMoreFiles').addEventListener('click', () => filePicker.click());
document.getElementById('closeImportDialog').addEventListener('click', () => closeModal(importDialog));
document.getElementById('saveSelectedFiles').addEventListener('click', saveStagedFiles);

filePicker.addEventListener('change', event => stageFiles(event.target.files));
photoPicker.addEventListener('change', event => stageFiles(event.target.files));

selectedFilesEl.addEventListener('click', event => {
  const button = event.target.closest('[data-staged-index]');
  if (button) selectStagedFile(Number(button.dataset.stagedIndex));
});

supportGrid.addEventListener('click', event => {
  const button = event.target.closest('[data-open-support]');
  if (button) openSupport(Number(button.dataset.openSupport));
});

supportSearch.addEventListener('input', refreshLibrary);
supportCategoryFilter.addEventListener('change', refreshLibrary);

document.getElementById('closeSupportDialog').addEventListener('click', () => closeModal(supportDialog));
document.getElementById('deleteCurrentSupport').addEventListener('click', removeCurrentSupport);
document.getElementById('downloadCurrentSupport').addEventListener('click', downloadCurrentSupport);

document.getElementById('openDiagnostics').addEventListener('click', () => {
  initialDiagnosticRows();
  openModal(diagnosticDialog);
});
document.querySelectorAll('[data-open-diagnostic]').forEach(button =>
  button.addEventListener('click', () => {
    initialDiagnosticRows();
    openModal(diagnosticDialog);
  })
);
document.getElementById('closeDiagnostics').addEventListener('click', () => closeModal(diagnosticDialog));
document.getElementById('runDiagnostic').addEventListener('click', runDiagnostics);
document.getElementById('saveLocalTest').addEventListener('click', testLocalStorage);
document.getElementById('clearHistory').addEventListener('click', async () => {
  if (!confirm('Effacer uniquement l’historique local des diagnostics ?')) return;
  await clearDiagnostics();
  await refreshMetrics();
  showToast('Historique de diagnostic effacé.');
});

document.querySelectorAll('[data-go]').forEach(button =>
  button.addEventListener('click', () => {
    location.hash = button.dataset.go;
  })
);

[importDialog, supportDialog, diagnosticDialog].forEach(dialog => {
  dialog.addEventListener('click', event => {
    const rect = dialog.getBoundingClientRect();
    const outside = event.clientX < rect.left ||
      event.clientX > rect.right ||
      event.clientY < rect.top ||
      event.clientY > rect.bottom;
    if (outside) closeModal(dialog);
  });
});

renderRoute();
updateNetworkStatus();
initialDiagnosticRows();
refreshMetrics();
refreshLibrary();
registerServiceWorker();
