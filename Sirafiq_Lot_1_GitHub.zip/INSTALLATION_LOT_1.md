# Installation du Lot 1 dans GitHub

1. Ajouter `Sirafiq_Lot_1_GitHub.zip` au dépôt GitHub.
2. Dans Codespaces :

```bash
git pull origin main
unzip -o Sirafiq_Lot_1_GitHub.zip
rm Sirafiq_Lot_1_GitHub.zip
git add .
git commit -m "Ajout du Lot 1 import de supports"
git push origin main
```

3. Cloudflare Pages republiera automatiquement la branche `main`.
4. Ouvrir `https://sirafiq.pages.dev` dans Safari.
5. Tester :
   - image depuis Photos ;
   - PDF depuis Fichiers ;
   - audio de référence ;
   - fermeture et réouverture ;
   - recherche ;
   - suppression confirmée.

Ne pas supprimer l’ancienne PWA installée avant d’avoir vérifié que la nouvelle version est active. Si Safari conserve l’ancien cache, fermer complètement l’app web puis la rouvrir.
