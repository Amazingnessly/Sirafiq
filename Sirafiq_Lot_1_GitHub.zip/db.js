const DB_NAME = 'sirafiq-local';
const DB_VERSION = 2;
const STORE_META = 'meta';
const STORE_DIAGNOSTICS = 'diagnostics';
const STORE_SUPPORTS = 'supports';

function openDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = () => {
      const db = request.result;

      if (!db.objectStoreNames.contains(STORE_META)) {
        db.createObjectStore(STORE_META, { keyPath: 'key' });
      }

      if (!db.objectStoreNames.contains(STORE_DIAGNOSTICS)) {
        const store = db.createObjectStore(STORE_DIAGNOSTICS, {
          keyPath: 'id',
          autoIncrement: true
        });
        store.createIndex('createdAt', 'createdAt');
      }

      if (!db.objectStoreNames.contains(STORE_SUPPORTS)) {
        const store = db.createObjectStore(STORE_SUPPORTS, {
          keyPath: 'id',
          autoIncrement: true
        });
        store.createIndex('createdAt', 'createdAt');
        store.createIndex('category', 'category');
        store.createIndex('kind', 'kind');
        store.createIndex('titleSearch', 'titleSearch');
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () =>
      reject(request.error || new Error('IndexedDB indisponible'));
  });
}

function transactionPromise(storeName, mode, operation) {
  return openDb().then(db => new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, mode);
    const store = tx.objectStore(storeName);
    let request;

    try {
      request = operation(store);
    } catch (error) {
      db.close();
      reject(error);
      return;
    }

    request.onsuccess = () => resolve(request.result);
    request.onerror = () =>
      reject(request.error || new Error('Erreur de stockage local'));

    tx.oncomplete = () => db.close();
    tx.onabort = () => {
      db.close();
      reject(tx.error || new Error('Transaction annulée'));
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error || new Error('Transaction IndexedDB échouée'));
    };
  }));
}

export async function writeLocalProbe() {
  const value = `sirafiq-${Date.now()}-${Math.random().toString(36).slice(2)}`;

  await transactionPromise(STORE_META, 'readwrite', store =>
    store.put({
      key: 'localProbe',
      value,
      updatedAt: new Date().toISOString()
    })
  );

  const result = await transactionPromise(
    STORE_META,
    'readonly',
    store => store.get('localProbe')
  );

  if (!result || result.value !== value) {
    throw new Error('La donnée écrite n’a pas pu être relue');
  }

  return result;
}

export function addDiagnostic(record) {
  return transactionPromise(
    STORE_DIAGNOSTICS,
    'readwrite',
    store => store.add(record)
  );
}

export function listDiagnostics() {
  return transactionPromise(
    STORE_DIAGNOSTICS,
    'readonly',
    store => store.getAll()
  );
}

export function clearDiagnostics() {
  return transactionPromise(
    STORE_DIAGNOSTICS,
    'readwrite',
    store => store.clear()
  );
}

export async function addSupport(record) {
  if (!(record.blob instanceof Blob)) {
    throw new Error('Le fichier source est absent');
  }

  const payload = {
    ...record,
    titleSearch: record.title.toLocaleLowerCase('fr'),
    createdAt: record.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  return transactionPromise(
    STORE_SUPPORTS,
    'readwrite',
    store => store.add(payload)
  );
}

export function listSupports() {
  return transactionPromise(
    STORE_SUPPORTS,
    'readonly',
    store => store.getAll()
  );
}

export function getSupport(id) {
  return transactionPromise(
    STORE_SUPPORTS,
    'readonly',
    store => store.get(Number(id))
  );
}

export function deleteSupport(id) {
  return transactionPromise(
    STORE_SUPPORTS,
    'readwrite',
    store => store.delete(Number(id))
  );
}

export async function countSupports() {
  return transactionPromise(
    STORE_SUPPORTS,
    'readonly',
    store => store.count()
  );
}

export async function totalSupportBytes() {
  const supports = await listSupports();
  return supports.reduce((sum, support) => sum + (support.size || 0), 0);
}

export async function testIndexedDbAvailability() {
  if (!('indexedDB' in window)) return false;

  try {
    await writeLocalProbe();
    return true;
  } catch {
    return false;
  }
}