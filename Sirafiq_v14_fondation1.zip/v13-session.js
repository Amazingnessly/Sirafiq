import {
  getSupport,
  addLearningEvent,
  upsertReviewItem
} from './db.js?v=120';

const $ = id => document.getElementById(id);

const masteryPlan = {
  again:   { days: 1,  label: 'à revoir' },
  fragile: { days: 2,  label: 'fragile' },
  acquis:  { days: 7,  label: 'acquis' },
  solide:  { days: 21, label: 'maîtrisé' }
};

const techniqueCopy = {
  recall: {
    label: 'Rappel libre',
    instruction: 'Sans regarder le support, restituez tout ce dont vous vous souvenez. Ne cherchez pas encore à être parfait : faites apparaître ce qui est réellement disponible en mémoire.'
  },
  mask: {
    label: 'Masquage progressif',
    instruction: 'Restituez l’unité choisie avec le moins d’indices possible. Écrivez ce que vous êtes capable de reconstruire avant de rouvrir le support.'
  },
  questions: {
    label: 'Questions → rappel',
    instruction: 'Formulez une ou plusieurs questions importantes à partir de ce que vous avez étudié, puis répondez-y de mémoire.'
  },
  oral: {
    label: 'Restitution orale',
    instruction: 'Récitez ou expliquez d’abord à voix haute sans regarder. Notez ensuite ici les éléments que vous pensez avoir oubliés ou hésités.'
  },
  written: {
    label: 'Restitution écrite',
    instruction: 'Réécrivez de mémoire ce que vous voulez restituer. Le support restera masqué jusqu’à l’étape de vérification.'
  },
  map: {
    label: 'Carte de mémoire',
    instruction: 'Listez de mémoire le thème central, les idées principales et leurs relations. Vous pourrez ensuite vérifier la structure avec le support.'
  }
};

let activeSession = null;
let activeObjectUrl = null;

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, c => ({
    '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#039;'
  }[c]));
}

function isoDay(days) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  d.setHours(8, 0, 0, 0);
  return d.toISOString();
}

function cleanupObjectUrl() {
  if (activeObjectUrl) URL.revokeObjectURL(activeObjectUrl);
  activeObjectUrl = null;
}

function ensureWorkspace() {
  let host = $('v13MemorySession');
  if (host) return host;

  host = document.createElement('section');
  host.id = 'v13MemorySession';
  host.className = 'v13-session-workspace';
  host.hidden = true;
  host.setAttribute('aria-labelledby', 'v13SessionTitle');

  const memoryLab = document.querySelector('.memory-lab');
  if (memoryLab) memoryLab.insertAdjacentElement('afterend', host);

  return host;
}

function sourceMime(support) {
  return String(
    support?.mimeType ||
    support?.blob?.type ||
    support?.type ||
    ''
  ).toLowerCase();
}

async function sourceMarkup(support) {
  if (!support?.blob) {
    return '<div class="v13-source-unavailable">Le fichier original n’est pas disponible.</div>';
  }

  const mime = sourceMime(support);

  if (
    mime.startsWith('text/') ||
    /json|xml|csv|markdown/.test(mime)
  ) {
    try {
      const text = await support.blob.text();
      return `<pre class="v13-source-text">${esc(text.slice(0, 50000))}</pre>`;
    } catch {}
  }

  cleanupObjectUrl();
  activeObjectUrl = URL.createObjectURL(support.blob);

  if (mime.startsWith('image/')) {
    return `<img class="v13-source-image" src="${activeObjectUrl}" alt="Support original">`;
  }

  if (mime.startsWith('audio/')) {
    return `
      <div class="v13-source-media">
        <audio controls preload="metadata" src="${activeObjectUrl}"></audio>
        <p>Réécoutez maintenant le support et comparez avec votre restitution.</p>
      </div>`;
  }

  if (mime.includes('pdf')) {
    return `<iframe class="v13-source-pdf" src="${activeObjectUrl}" title="Support PDF original"></iframe>`;
  }

  return `
    <div class="v13-source-unavailable">
      <strong>Support original : ${esc(support.title || support.originalName || 'Support')}</strong>
      <p>Ce type de fichier ne peut pas être affiché directement dans cette séance. Vous pouvez néanmoins comparer avec le fichier original dans votre bibliothèque.</p>
    </div>`;
}

function renderAttempt() {
  const host = ensureWorkspace();
  const t = techniqueCopy[activeSession.technique] || techniqueCopy.recall;

  host.hidden = false;
  host.innerHTML = `
    <div class="v13-session-shell">
      <header class="v13-session-header">
        <div>
          <p class="section-kicker">Séance active · étape 1 sur 3</p>
          <h2 id="v13SessionTitle">${esc(activeSession.support.title || 'Support')}</h2>
          <p>${esc(t.label)} · le support reste volontairement masqué.</p>
        </div>
        <button type="button" class="v13-session-close" data-v13-close-session aria-label="Quitter la séance">×</button>
      </header>

      <div class="v13-stepper" aria-label="Progression">
        <span class="active"><b>1</b> Restituer</span>
        <span><b>2</b> Vérifier</span>
        <span><b>3</b> Décider de la suite</span>
      </div>

      <article class="v13-practice-card">
        <div class="v13-practice-instruction">
          <small>Votre consigne</small>
          <h3>${esc(t.label)}</h3>
          <p>${esc(t.instruction)}</p>
        </div>

        <label class="v13-recall-field">
          <span>Votre restitution</span>
          <textarea id="v13RecallAnswer" rows="10"
            placeholder="Écrivez ici ce dont vous vous souvenez. Le support n’apparaîtra qu’après votre tentative."></textarea>
        </label>

        <div class="v13-session-actions">
          <button type="button" class="primary-button" data-v13-verify>
            J’ai terminé — vérifier avec le support →
          </button>
          <button type="button" class="secondary-button" data-v13-close-session>
            Quitter
          </button>
        </div>
      </article>
    </div>`;

  host.scrollIntoView({
    behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth',
    block: 'start'
  });

  setTimeout(() => $('v13RecallAnswer')?.focus(), 250);
}

async function renderVerification() {
  if (!activeSession) return;

  const answer = ($('v13RecallAnswer')?.value || '').trim();

  if (!answer && activeSession.technique !== 'oral') {
    const field = $('v13RecallAnswer');
    field?.classList.add('v13-field-warning');
    field?.focus();
    return;
  }

  activeSession.answer = answer;

  await addLearningEvent({
    domain: 'memorisation',
    kind: 'attempt',
    supportId: activeSession.support.id,
    title: activeSession.support.title,
    technique: activeSession.technique,
    answerLength: answer.length
  }).catch(() => {});

  const original = await sourceMarkup(activeSession.support);
  const host = ensureWorkspace();

  host.innerHTML = `
    <div class="v13-session-shell">
      <header class="v13-session-header">
        <div>
          <p class="section-kicker">Séance active · étape 2 sur 3</p>
          <h2 id="v13SessionTitle">Comparer, sans se juger</h2>
          <p>Repérez précisément ce qui était présent, absent, approximatif ou ajouté.</p>
        </div>
        <button type="button" class="v13-session-close" data-v13-close-session aria-label="Quitter la séance">×</button>
      </header>

      <div class="v13-stepper">
        <span class="done"><b>✓</b> Restituer</span>
        <span class="active"><b>2</b> Vérifier</span>
        <span><b>3</b> Décider de la suite</span>
      </div>

      <div class="v13-compare-layout">
        <article class="v13-compare-panel">
          <small>Votre tentative</small>
          <h3>Ce que vous aviez en mémoire</h3>
          <div class="v13-user-answer">${
            answer
              ? esc(answer).replace(/\n/g, '<br>')
              : '<em>Restitution effectuée oralement.</em>'
          }</div>
        </article>

        <article class="v13-compare-panel v13-original-panel">
          <small>Support original</small>
          <h3>Vérifiez maintenant</h3>
          <div class="v13-source-view">${original}</div>
        </article>
      </div>

      <article class="v13-evaluation-card">
        <small>Après comparaison</small>
        <h3>Quelle quantité de travail faut-il encore ?</h3>
        <p>Choisissez l’état qui décrit cette tentative. Cela déterminera la prochaine révision.</p>
        <div class="v13-mastery-actions">
          <button type="button" data-v13-mastery="again"><strong>À revoir</strong><small>Beaucoup manquait</small></button>
          <button type="button" data-v13-mastery="fragile"><strong>Fragile</strong><small>Encore hésitant</small></button>
          <button type="button" data-v13-mastery="acquis"><strong>Acquis</strong><small>Globalement correct</small></button>
          <button type="button" data-v13-mastery="solide"><strong>Maîtrisé</strong><small>Restitution sûre</small></button>
        </div>
      </article>
    </div>`;

  host.scrollIntoView({
    behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth',
    block: 'start'
  });
}

async function finishSession(result) {
  if (!activeSession) return;

  const plan = masteryPlan[result];
  if (!plan) return;

  const support = activeSession.support;
  const technique = activeSession.technique;

  await upsertReviewItem({
    key: `support:${support.id}:${technique}`,
    title: support.title || 'Support',
    domain: 'memorisation',
    area: technique,
    mastery: plan.label,
    nextReview: isoDay(plan.days),
    intervalDays: plan.days,
    lastResult: result,
    supportId: support.id
  });

  await addLearningEvent({
    domain: 'memorisation',
    kind: 'self-evaluation',
    supportId: support.id,
    title: support.title,
    technique,
    result
  }).catch(() => {});

  const host = ensureWorkspace();

  host.innerHTML = `
    <div class="v13-session-shell v13-session-complete">
      <div class="v13-complete-mark" aria-hidden="true">✓</div>
      <p class="section-kicker">Séance terminée</p>
      <h2 id="v13SessionTitle">Une révision réellement enregistrée.</h2>
      <p>
        État : <strong>${esc(plan.label)}</strong>.<br>
        Cette notion reviendra dans
        <strong>${plan.days} jour${plan.days > 1 ? 's' : ''}</strong>.
      </p>

      <div class="v13-stepper">
        <span class="done"><b>✓</b> Restituer</span>
        <span class="done"><b>✓</b> Vérifier</span>
        <span class="done"><b>✓</b> Programmer la suite</span>
      </div>

      <div class="v13-session-actions">
        <button type="button" class="primary-button" data-v13-retry>
          Refaire une tentative
        </button>
        <button type="button" class="secondary-button" data-v13-finish>
          Terminer et revenir à mes supports
        </button>
      </div>
    </div>`;

  window.dispatchEvent(new CustomEvent('sirafiq:data-changed'));

  $('memoryStatus') && (
    $('memoryStatus').textContent =
      `Séance terminée · ${plan.label} · prochaine révision dans ${plan.days} jour${plan.days > 1 ? 's' : ''}.`
  );

  host.scrollIntoView({
    behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth',
    block: 'start'
  });
}

async function beginSession() {
  const supportSelect = $('memorySupportSelect');
  const supportId = Number(supportSelect?.value || 0);

  if (!supportId) {
    if ($('memoryStatus')) {
      $('memoryStatus').textContent =
        'Choisissez d’abord un support. Ensuite Sirāfiq ouvrira une vraie séance de restitution.';
    }
    supportSelect?.focus();
    return;
  }

  const activeTechnique =
    document.querySelector('[data-memory-technique].active')?.dataset.memoryTechnique ||
    'recall';

  const support = await getSupport(supportId).catch(() => null);

  if (!support) {
    if ($('memoryStatus')) {
      $('memoryStatus').textContent =
        'Le support sélectionné n’a pas pu être chargé.';
    }
    return;
  }

  cleanupObjectUrl();

  activeSession = {
    support,
    technique: activeTechnique,
    startedAt: new Date().toISOString(),
    answer: ''
  };

  if ($('memoryEvaluation')) $('memoryEvaluation').hidden = true;

  await addLearningEvent({
    domain: 'memorisation',
    kind: 'technique-start',
    supportId: support.id,
    title: support.title,
    technique: activeTechnique,
    engine: 'v13'
  }).catch(() => {});

  renderAttempt();
}

function closeSession() {
  cleanupObjectUrl();
  const host = ensureWorkspace();
  host.hidden = true;
  host.innerHTML = '';
  activeSession = null;
  document.querySelector('.memory-lab')?.scrollIntoView({
    behavior: 'smooth',
    block: 'start'
  });
}

document.addEventListener('click', async event => {
  const start = event.target.closest('#memoryStartTechnique');

  if (start) {
    /*
      Capture de l’action V13 :
      le listener historique V12 reste présent pendant cette étape
      de migration, mais son effet visuel est remplacé par cette
      véritable session.
    */
    event.preventDefault();
    await beginSession();
    return;
  }

  if (event.target.closest('[data-v13-verify]')) {
    await renderVerification();
    return;
  }

  const mastery = event.target.closest('[data-v13-mastery]');
  if (mastery) {
    await finishSession(mastery.dataset.v13Mastery);
    return;
  }

  if (event.target.closest('[data-v13-retry]')) {
    cleanupObjectUrl();
    renderAttempt();
    return;
  }

  if (event.target.closest('[data-v13-finish]')) {
    closeSession();
    return;
  }

  if (event.target.closest('[data-v13-close-session]')) {
    closeSession();
  }
});

/*
  Si l'utilisateur arrive depuis une carte "Réviser" de la bibliothèque,
  l'espace reste focalisé sur le support choisi.
*/
window.addEventListener('sirafiq:review-support', () => {
  const host = $('v13MemorySession');
  if (host) {
    host.hidden = true;
    host.innerHTML = '';
  }
  cleanupObjectUrl();
  activeSession = null;
});
