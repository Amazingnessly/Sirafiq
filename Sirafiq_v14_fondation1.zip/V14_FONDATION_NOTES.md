# Sirāfiq v14 — Fondation 1

Objectif de cette étape : réparer la chaîne support → séance → carte, et poser un shell applicatif iPad/desktop plus proche d'une vraie application.

## Changements fonctionnels
- Un support nouvellement importé devient automatiquement le support actif.
- Le support actif persiste entre les vues.
- Les PDF et textes passent par un moteur commun d'extraction (`support-engine.js`).
- Les idées de mémorisation peuvent désormais s'appuyer sur du texte extrait d'un PDF, pas uniquement sur les fichiers texte.
- « Ouvrir dans Cartes » transfère aussi le contenu extrait d'un PDF.
- À l'arrivée dans Cartes depuis un support, une première structure est générée automatiquement et reste entièrement modifiable.
- La création d'une carte vierge reste disponible et indépendante.
- Le service worker passe à un nouveau cache afin d'éviter qu'une ancienne interface reste servie sur iPad.

## Direction visuelle
- Rail latéral sur iPad/desktop ; barre inférieure conservée sur téléphone.
- Écrans plus compacts et plus applicatifs.
- Hiérarchie éditoriale ivoire/bordeaux propre à Sirāfiq.
- Réduction des grands panneaux de type landing page.
- Mémorisation traitée comme atelier, pas comme simple bibliothèque.

## Hors périmètre de cette première fondation
Cette étape ne prétend pas terminer Prononcer, Écrire, Transcription, Médiathèque, Cours ni Boussole IA. Ils seront reconstruits sur le même socle après validation du moteur de support.
