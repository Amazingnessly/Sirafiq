const normalizeText = value => String(value || '').replace(/\u00a0/g, ' ').replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();

export function supportMime(support = {}) {
  return String(support.mimeType || support.type || support.blob?.type || '').toLowerCase();
}

export async function extractSupportText(support, { maxChars = 32000, maxPdfPages = 20 } = {}) {
  if (!support?.blob) return { text: '', mode: 'unavailable', pages: 0, truncated: false };
  const mime = supportMime(support);
  let text = '';
  let pages = 0;

  if (mime.startsWith('text/') || /json|xml|csv|markdown/.test(mime) || support.kind === 'text') {
    text = await support.blob.text();
    return { text: normalizeText(text).slice(0, maxChars), mode: 'text', pages: 1, truncated: text.length > maxChars };
  }

  if (mime.includes('pdf') || support.kind === 'pdf') {
    const pdfjs = globalThis.pdfjsLib;
    if (!pdfjs?.getDocument) return { text: '', mode: 'pdf-no-engine', pages: 0, truncated: false };
    const data = await support.blob.arrayBuffer();
    const pdf = await pdfjs.getDocument({ data }).promise;
    const limit = Math.min(pdf.numPages, maxPdfPages);
    const chunks = [];
    for (let pageNo = 1; pageNo <= limit; pageNo++) {
      const page = await pdf.getPage(pageNo);
      const content = await page.getTextContent();
      const line = content.items.map(item => item.str || '').join(' ');
      chunks.push(`[Page ${pageNo}] ${line}`);
      if (chunks.join('\n').length >= maxChars) break;
    }
    text = normalizeText(chunks.join('\n'));
    pages = pdf.numPages;
    return { text: text.slice(0, maxChars), mode: 'pdf', pages, truncated: text.length > maxChars || pdf.numPages > limit };
  }

  return { text: '', mode: mime.startsWith('audio/') ? 'audio' : mime.startsWith('image/') ? 'image' : 'binary', pages: 0, truncated: false };
}

export function textToStudyUnits(text, limit = 8) {
  const clean = normalizeText(text).replace(/\[Page \d+\]/g, ' ');
  if (!clean) return [];
  return clean
    .split(/(?<=[.!?؟])\s+|\n+/)
    .map(s => normalizeText(s))
    .filter(s => s.length >= 24)
    .slice(0, limit);
}

const ACTIVE_KEY = 'sirafiq-active-support-id';

export function setActiveSupportId(id) {
  const value = Number(id || 0);
  if (value > 0) localStorage.setItem(ACTIVE_KEY, String(value));
  else localStorage.removeItem(ACTIVE_KEY);
  return value;
}

export function getActiveSupportId() {
  return Number(localStorage.getItem(ACTIVE_KEY) || 0);
}
