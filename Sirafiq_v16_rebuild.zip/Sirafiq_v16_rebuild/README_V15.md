# Sirāfiq V15 — reconstruction applicative

Cette version est une reconstruction du frontend sur React + TypeScript + Vite.
Elle ne repose plus sur l'ancien `index.html` monolithique ni sur l'empilement `styles.css + v13 + v14`.

## Principes
- iPad prioritaire : rail latéral, zone de travail pleine hauteur, aucun contenu essentiel derrière une barre flottante.
- un écran = une intention principale ; textes explicatifs courts.
- support actif partagé entre Bibliothèque, Mémoriser, Cartes et Boussole.
- PDF et texte extraits réellement via `pdfjs-dist`.
- Cartes : création manuelle toujours possible + création assistée depuis le support.
- Boussole : moteur local en premier, Workers AI optionnel via `/api/coach`.
- stockage local via IndexedDB.
- Médiathèque, translittération et supports de cours intégrés comme espaces de travail.

## Parcours déjà câblés
1. Import PDF/texte -> extraction -> support actif.
2. Mémoriser -> tentative masquée -> vérification -> auto-évaluation -> prochaine révision.
3. Cartes -> carte vierge ou structure depuis le support -> ajout/édition/suppression -> sauvegarde locale.
4. Prononcer -> synthèse système -> enregistrement micro -> réécoute.
5. Écrire -> exercice progressif -> modèle masquable -> canvas tactile/stylet.
6. Boussole -> priorité locale -> appel Workers AI optionnel.
7. Médiathèque -> ajout de liens YouTube et lecture intégrée.
8. Studio translittération -> média local + segments horodatés.
9. Cours -> support + ajouts privés/partagés + vue présentateur.

## À valider dans Codespaces
`npm install` puis `npm run build`.
Cette archive a été préparée dans un environnement sans accès npm, donc les dépendances n'ont pas pu être téléchargées ici. La syntaxe TypeScript/JSX a été vérifiée autant que possible avec le compilateur global ; les erreurs restantes sont uniquement liées aux modules React/pdfjs non installés dans cet environnement.
