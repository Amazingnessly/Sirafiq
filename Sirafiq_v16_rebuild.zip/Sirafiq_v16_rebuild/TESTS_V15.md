# Tests d'acceptation V15

## iPad
- 1024x1366 portrait : rail visible, aucun élément tronqué, zone centrale scrollable.
- 1180x820 paysage : rail visible, ateliers en deux panneaux.
- <=680px : barre mobile en bas et rail supprimé.

## Fonctionnel
- Importer un PDF : il apparaît et devient immédiatement support actif.
- Mémoriser : le support actif est visible ; tentative puis vérification ; évaluation sauvegardée.
- Cartes : `Carte vierge` fonctionne sans support ; `Créer depuis le support` fonctionne si texte extrait.
- Écrire : stylet/doigt dessine ; effacer fonctionne ; modèle peut être masqué.
- Prononcer : lecture modèle ; microphone ; réécoute.
- Boussole : recommandation locale sans IA ; appel IA avec `/api/coach` ; fallback en cas d'échec.
- Médiathèque : ajout YouTube ; lecteur intégré.
- Translittération : ajout média local ; nouveau segment au timecode courant.
- Cours : ajout note privée/partagée ; bascule Présenter.
