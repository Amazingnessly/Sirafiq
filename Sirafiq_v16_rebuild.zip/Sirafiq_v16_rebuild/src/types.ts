export type Section = 'home' | 'learn' | 'library' | 'media' | 'studio' | 'courses' | 'compass';
export type LearnMode = 'memory' | 'pronunciation' | 'writing' | 'maps';
export type Mastery = 'again' | 'fragile' | 'acquired' | 'mastered';

export interface SupportRecord {
  id?: number;
  title: string;
  category: string;
  kind: 'pdf' | 'text' | 'image' | 'audio' | 'file';
  mimeType: string;
  size: number;
  blob: Blob;
  text?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ReviewRecord {
  key: string;
  supportId?: number;
  title: string;
  domain: string;
  mastery: Mastery;
  nextReview: string;
  intervalDays: number;
  updatedAt: string;
}

export interface MapNode {
  id: string;
  label: string;
  children: MapNode[];
}

export interface MindMapRecord {
  id?: number;
  title: string;
  supportId?: number;
  root: MapNode;
  createdAt: string;
  updatedAt: string;
}

export interface PlaylistRecord {
  id?: number;
  title: string;
  category: 'Religion' | 'Arabe' | 'Qour’ān' | 'Autre';
  url: string;
  videoId?: string;
  createdAt: string;
}

export interface CourseRecord {
  id?: number;
  title: string;
  body: string;
  additions: { id: string; anchor: string; text: string; visibility: 'private' | 'shared' }[];
  updatedAt: string;
}
