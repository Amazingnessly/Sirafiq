import { useEffect, useMemo, useState } from 'react';
import { AppShell } from './components/AppShell';
import { db } from './lib/db';
import type { CourseRecord, LearnMode, Mastery, MindMapRecord, PlaylistRecord, ReviewRecord, Section, SupportRecord } from './types';
import { Compass } from './screens/Compass';
import { Courses } from './screens/Courses';
import { Home } from './screens/Home';
import { Learn } from './screens/Learn';
import { Library } from './screens/Library';
import { Media } from './screens/Media';
import { Studio } from './screens/Studio';

const interval: Record<Mastery, number> = { again: 1, fragile: 2, acquired: 7, mastered: 21 };

export default function App() {
  const [section,setSection]=useState<Section>('home');
  const [learnMode,setLearnMode]=useState<LearnMode>('memory');
  const [supports,setSupports]=useState<SupportRecord[]>([]);
  const [reviews,setReviews]=useState<ReviewRecord[]>([]);
  const [playlists,setPlaylists]=useState<PlaylistRecord[]>([]);
  const [courses,setCourses]=useState<CourseRecord[]>([]);
  const [activeSupportId,setActiveSupportId]=useState<number|undefined>(()=>Number(localStorage.getItem('sirafiq-active-support'))||undefined);

  async function refresh(){
    const [s,r,p,c]=await Promise.all([db.listSupports(),db.listReviews(),db.listPlaylists(),db.listCourses()]);
    setSupports(s.sort((a,b)=>new Date(b.createdAt).getTime()-new Date(a.createdAt).getTime()));
    setReviews(r); setPlaylists(p); setCourses(c);
  }
  useEffect(()=>{refresh().catch(console.error)},[]);
  const activeSupport=useMemo(()=>supports.find(s=>s.id===activeSupportId),[supports,activeSupportId]);

  function activate(id:number){setActiveSupportId(id);localStorage.setItem('sirafiq-active-support',String(id));setSection('learn');setLearnMode('memory')}
  async function importSupport(support:SupportRecord){const id=await db.addSupport(support);setActiveSupportId(id);localStorage.setItem('sirafiq-active-support',String(id));await refresh()}
  async function deleteSupport(id:number){await db.deleteSupport(id);if(activeSupportId===id){setActiveSupportId(undefined);localStorage.removeItem('sirafiq-active-support')}await refresh()}
  async function rate(mastery:Mastery,technique:string){if(!activeSupport?.id)return;const days=interval[mastery];const d=new Date();d.setDate(d.getDate()+days);await db.putReview({key:`support:${activeSupport.id}:${technique}`,supportId:activeSupport.id,title:activeSupport.title,domain:'memorisation',mastery,nextReview:d.toISOString(),intervalDays:days,updatedAt:new Date().toISOString()});await refresh()}
  async function saveMap(map:MindMapRecord){await db.addMap(map)}
  async function addPlaylist(p:PlaylistRecord){await db.addPlaylist(p);await refresh()}
  async function saveCourse(c:CourseRecord){await db.putCourse(c);await refresh()}

  function startLearning(){if(!supports.length){setSection('library');return}if(!activeSupportId&&supports[0].id){activate(supports[0].id);return}setSection('learn');setLearnMode('memory')}

  let content;
  if(section==='home') content=<Home supports={supports} reviews={reviews} onStart={startLearning} onLibrary={()=>setSection('library')} onCompass={()=>setSection('compass')} onLearn={()=>setSection('learn')}/>;
  else if(section==='learn') content=<Learn mode={learnMode} setMode={setLearnMode} support={activeSupport} onPickSupport={()=>setSection('library')} onRate={rate} onSaveMap={saveMap}/>;
  else if(section==='library') content=<Library supports={supports} activeSupportId={activeSupportId} onImported={importSupport} onActivate={activate} onDelete={deleteSupport}/>;
  else if(section==='media') content=<Media items={playlists} onAdd={addPlaylist}/>;
  else if(section==='studio') content=<Studio/>;
  else if(section==='courses') content=<Courses courses={courses} onSave={saveCourse}/>;
  else content=<Compass supports={supports} reviews={reviews} activeSupport={activeSupport} onStart={startLearning}/>;

  return <AppShell section={section} setSection={setSection} activeSupportTitle={activeSupport?.title}>{content}</AppShell>;
}
