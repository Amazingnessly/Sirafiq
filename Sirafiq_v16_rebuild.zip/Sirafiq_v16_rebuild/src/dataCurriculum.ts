export type TrackLanguage = 'fr' | 'ar';
export type TrackLevel = 'Fondations' | 'Débutant' | 'Intermédiaire' | 'Maîtrise';

export interface PronunciationLesson {
  id: string;
  language: TrackLanguage;
  level: TrackLevel;
  title: string;
  text: string;
  hint: string;
  focus: string;
}

export interface WritingLesson {
  id: string;
  language: TrackLanguage;
  level: TrackLevel;
  title: string;
  model: string;
  hint: string;
  focus: string;
  direction?: 'ltr' | 'rtl';
  style?: string;
}

export const pronunciationLessons: PronunciationLesson[] = [
  {id:'fr-vowels',language:'fr',level:'Fondations',title:'Voyelles nettes',text:'i é è a o ou u',hint:'Posez chaque son sans accélérer. Cherchez une différence franche entre /u/ et /y/.',focus:'Placement et précision'},
  {id:'fr-nasal',language:'fr',level:'Débutant',title:'Voyelles nasales',text:'un bon pain blanc, un parfum léger',hint:'Laissez résonner sans ajouter de consonne finale.',focus:'on · an · in · un'},
  {id:'fr-liaison',language:'fr',level:'Intermédiaire',title:'Liaisons utiles',text:'Vous avez un exemple important. Nous allons en parler.',hint:'Faites entendre la liaison seulement là où elle est naturelle.',focus:'enchaînement et fluidité'},
  {id:'fr-rhythm',language:'fr',level:'Intermédiaire',title:'Groupes de sens',text:'Aujourd’hui / je vais vous présenter / une idée importante.',hint:'Les pauses suivent le sens, pas chaque mot.',focus:'rythme et respiration'},
  {id:'fr-express',language:'fr',level:'Maîtrise',title:'Parole pédagogique',text:'Retenez d’abord le principe. Ensuite, nous verrons un exemple. Enfin, reformulez avec vos propres mots.',hint:'Hiérarchisez : annonce, respiration, exemple, conclusion.',focus:'clarté et expression'},
  {id:'ar-throat',language:'ar',level:'Fondations',title:'Sons de gorge',text:'ح خ ع غ ه ء',hint:'Travaillez lentement chaque point d’articulation avant de les placer dans des mots.',focus:'makhārij de base'},
  {id:'ar-emphatic',language:'ar',level:'Débutant',title:'Lettres emphatiques',text:'ص ض ط ظ',hint:'Comparez avec س د ت ذ sans exagérer la tension.',focus:'tafkhīm / contraste'},
  {id:'ar-length',language:'ar',level:'Intermédiaire',title:'Voyelles longues',text:'قَالَ — قِيلَ — يَقُولُ',hint:'Gardez une durée régulière et différenciez clairement court et long.',focus:'madd et durée'},
  {id:'ar-phrase',language:'ar',level:'Maîtrise',title:'Lecture liée',text:'العِلْمُ نُورٌ وَالفَهْمُ طَرِيقٌ إِلَى العَمَلِ',hint:'Préservez articulation, durée et continuité sans précipiter la phrase.',focus:'fluidité et articulation'}
];

export const writingLessons: WritingLesson[] = [
  {id:'fr-gestures',language:'fr',level:'Fondations',title:'Gestes fondateurs',model:'llll   eeee   mmmm',hint:'Régularité avant vitesse.',focus:'boucles · étrécies · ponts'},
  {id:'fr-lowercase',language:'fr',level:'Débutant',title:'Familles de minuscules',model:'a c d g   i u t   n m p',hint:'Travaillez par familles de gestes plutôt que lettre par lettre.',focus:'proportions et liaisons'},
  {id:'fr-words',language:'fr',level:'Intermédiaire',title:'Mots liés',model:'mémoire   chemin   savoir',hint:'Conservez hauteurs, espaces et rythme du mot.',focus:'liaisons et régularité'},
  {id:'fr-sentence',language:'fr',level:'Maîtrise',title:'Phrase autonome',model:'Je restitue avant de vérifier.',hint:'Copiez une fois, puis écrivez sans modèle.',focus:'fluidité et lisibilité'},
  {id:'ar-baseline',language:'ar',level:'Fondations',title:'Ligne et direction',model:'ا  ل  د  ر  و',hint:'Posez la ligne de base et le sens droite → gauche avant les détails.',focus:'direction · ligne de base',direction:'rtl',style:'Naskh'},
  {id:'ar-families',language:'ar',level:'Débutant',title:'Familles de formes',model:'ب ت ث   ج ح خ   س ش',hint:'Comparez le squelette commun puis ajoutez les points.',focus:'formes et points',direction:'rtl',style:'Naskh'},
  {id:'ar-connections',language:'ar',level:'Intermédiaire',title:'Connexions',model:'كتب   علم   مدرسة',hint:'Repérez où la lettre change de forme : isolée, initiale, médiane, finale.',focus:'liaisons',direction:'rtl',style:'Naskh'},
  {id:'ar-ruqah',language:'ar',level:'Intermédiaire',title:'Ruqʿah — geste compact',model:'العلم نور',hint:'Cherchez un geste rapide et compact. Utilisez ce module comme initiation au style.',focus:'initiation calligraphique',direction:'rtl',style:'Ruqʿah'},
  {id:'ar-thuluth',language:'ar',level:'Maîtrise',title:'Thuluth — proportions',model:'بسم الله',hint:'Travaillez lentement les proportions et la composition. Ce module est une initiation guidée.',focus:'composition',direction:'rtl',style:'Thuluth'}
];

export const levelOrder: TrackLevel[] = ['Fondations','Débutant','Intermédiaire','Maîtrise'];
