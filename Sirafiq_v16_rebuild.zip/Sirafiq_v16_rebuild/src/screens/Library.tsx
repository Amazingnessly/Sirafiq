import { useRef, useState } from 'react';
import type { SupportRecord } from '../types';
import { detectKind, extractText } from '../lib/support';

export function Library({ supports, activeSupportId, onImported, onActivate, onDelete }: {
  supports: SupportRecord[];
  activeSupportId?: number;
  onImported: (support: SupportRecord) => Promise<void>;
  onActivate: (id: number) => void;
  onDelete: (id: number) => Promise<void>;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [query, setQuery] = useState('');

  async function importFiles(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true);
    try {
      for (const file of Array.from(files)) {
        const kind = detectKind(file);
        let text = '';
        try { text = await extractText(file, kind); } catch { text = ''; }
        const now = new Date().toISOString();
        await onImported({ title: file.name.replace(/\.[^.]+$/, ''), category: 'Cours', kind, mimeType: file.type || 'application/octet-stream', size: file.size, blob: file, text, createdAt: now, updatedAt: now });
      }
    } finally { setBusy(false); if (inputRef.current) inputRef.current.value = ''; }
  }

  const filtered = supports.filter(s => s.title.toLocaleLowerCase('fr').includes(query.toLocaleLowerCase('fr')));
  return <div className="screen library-screen">
    <header className="screen-head compact-head"><div><span className="eyebrow">Bibliothèque</span><h1>Vos supports, prêts à travailler.</h1><p>Un support importé devient immédiatement actif et disponible dans Mémoriser, Cartes et Boussole.</p></div><button className="primary-action" onClick={() => inputRef.current?.click()} disabled={busy}>{busy ? 'Analyse…' : 'Importer'} <span>＋</span></button></header>
    <input ref={inputRef} type="file" hidden multiple accept=".pdf,.txt,.md,.csv,.json,image/*,audio/*" onChange={e => importFiles(e.target.files)} />
    <div className="library-toolbar-v15"><input type="search" value={query} onChange={e => setQuery(e.target.value)} placeholder="Rechercher un support…"/><span>{supports.length} support{supports.length !== 1 ? 's' : ''}</span></div>
    <div className="support-list-v15">
      {filtered.length ? filtered.map(s => <article key={s.id} className={activeSupportId === s.id ? 'active' : ''}>
        <div className="support-type">{s.kind === 'pdf' ? 'PDF' : s.kind.toUpperCase()}</div>
        <div className="support-copy"><span>{s.category}</span><h3>{s.title}</h3><p>{s.text ? `${s.text.slice(0, 150)}${s.text.length > 150 ? '…' : ''}` : 'Support original conservé localement.'}</p></div>
        <div className="support-actions"><button className="primary-small" onClick={() => s.id && onActivate(s.id)}>{activeSupportId === s.id ? 'Support actif' : 'Travailler'}</button><button className="danger-link" onClick={() => s.id && onDelete(s.id)}>Supprimer</button></div>
      </article>) : <div className="empty-panel"><span>＋</span><h2>Aucun support ici.</h2><p>Importez un PDF ou un texte pour commencer.</p><button className="primary-action" onClick={() => inputRef.current?.click()}>Importer un support</button></div>}
    </div>
  </div>;
}
