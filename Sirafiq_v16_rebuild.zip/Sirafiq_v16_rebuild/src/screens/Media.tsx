import { useMemo, useState } from 'react';
import type { PlaylistRecord } from '../types';

function youtubeId(url: string): string | undefined {
  try {
    const u = new URL(url);
    if (u.hostname.includes('youtu.be')) return u.pathname.slice(1).split('/')[0] || undefined;
    if (u.hostname.includes('youtube.com')) return u.searchParams.get('v') || undefined;
  } catch {}
  return undefined;
}

export function Media({ items, onAdd }: { items: PlaylistRecord[]; onAdd: (record: PlaylistRecord)=>Promise<void> }) {
  const [url,setUrl]=useState(''); const [title,setTitle]=useState(''); const [category,setCategory]=useState<PlaylistRecord['category']>('Religion');
  const [active,setActive]=useState<PlaylistRecord|undefined>(items[0]);
  const previewId=useMemo(()=>youtubeId(url),[url]);
  async function add(){if(!url.trim())return;const rec={title:title.trim()||'Vidéo à étudier',category,url:url.trim(),videoId:previewId,createdAt:new Date().toISOString()};await onAdd(rec);setActive(rec);setUrl('');setTitle('')}
  return <div className="screen media-screen"><header className="screen-head compact-head"><div><span className="eyebrow">Médiathèque</span><h1>Regarder ce que vous avez choisi d’étudier.</h1><p>Religion, arabe et Qour’ān — vos vidéos restent liées à vos notes et à vos révisions.</p></div></header><div className="media-layout"><aside className="media-library"><div className="media-add"><input value={url} onChange={e=>setUrl(e.target.value)} placeholder="Lien YouTube…"/><input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Titre personnel…"/><select value={category} onChange={e=>setCategory(e.target.value as PlaylistRecord['category'])}><option>Religion</option><option>Arabe</option><option>Qour’ān</option><option>Autre</option></select><button className="primary-small" onClick={add}>Ajouter</button></div><div className="media-list">{items.map((item,i)=><button key={item.id??i} className={active===item?'active':''} onClick={()=>setActive(item)}><span>{item.category.slice(0,2)}</span><div><strong>{item.title}</strong><small>{item.category}</small></div></button>)}</div></aside><section className="media-player-stage">{active?.videoId?<><div className="video-shell"><iframe src={`https://www.youtube-nocookie.com/embed/${active.videoId}`} title={active.title} allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen/></div><div className="media-meta"><span className="eyebrow">{active.category}</span><h2>{active.title}</h2><div className="media-actions"><button className="quiet-action">＋ Note à cet instant</button><button className="quiet-action">Ajouter aux révisions</button><button className="quiet-action">Translittérer ce passage</button></div></div></>:<div className="workspace-empty"><span className="eyebrow">Médiathèque</span><h2>Ajoutez une vidéo pour commencer.</h2><p>Les vidéos deviennent des supports de travail, pas une liste à oublier.</p></div>}</section></div></div>
}
