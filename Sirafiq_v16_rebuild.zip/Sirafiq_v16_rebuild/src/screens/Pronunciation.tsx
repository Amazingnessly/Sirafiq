import { useEffect, useMemo, useRef, useState } from 'react';
import { levelOrder, pronunciationLessons, type TrackLanguage, type TrackLevel } from '../dataCurriculum';

export function Pronunciation() {
  const [language,setLanguage]=useState<TrackLanguage>('fr');
  const [level,setLevel]=useState<TrackLevel>('Fondations');
  const lessons=useMemo(()=>pronunciationLessons.filter(x=>x.language===language&&x.level===level),[language,level]);
  const [selectedId,setSelectedId]=useState(pronunciationLessons[0].id);
  const ex=lessons.find(x=>x.id===selectedId) ?? lessons[0] ?? pronunciationLessons.find(x=>x.language===language)!;
  const [recording,setRecording]=useState(false); const [audioUrl,setAudioUrl]=useState('');
  const [voices,setVoices]=useState<SpeechSynthesisVoice[]>([]); const [voiceName,setVoiceName]=useState('');
  const recorder=useRef<MediaRecorder|null>(null); const chunks=useRef<Blob[]>([]);

  useEffect(()=>{const load=()=>{const all=speechSynthesis.getVoices();setVoices(all);const prefix=language==='fr'?'fr':'ar';const preferred=all.find(v=>v.lang.toLowerCase().startsWith(prefix));if(preferred)setVoiceName(preferred.name)};load();speechSynthesis.addEventListener('voiceschanged',load);return()=>speechSynthesis.removeEventListener('voiceschanged',load)},[language]);
  useEffect(()=>()=>{if(audioUrl)URL.revokeObjectURL(audioUrl)},[audioUrl]);
  useEffect(()=>{if(!lessons.some(x=>x.id===selectedId)&&lessons[0])setSelectedId(lessons[0].id)},[lessons,selectedId]);

  function speak(rate=.82){speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(ex.text.replaceAll('/',''));u.lang=language==='fr'?'fr-FR':'ar-SA';u.rate=rate;const v=voices.find(x=>x.name===voiceName);if(v)u.voice=v;speechSynthesis.speak(u)}
  async function start(){const stream=await navigator.mediaDevices.getUserMedia({audio:true});chunks.current=[];const r=new MediaRecorder(stream);recorder.current=r;r.ondataavailable=e=>chunks.current.push(e.data);r.onstop=()=>{const blob=new Blob(chunks.current,{type:r.mimeType});if(audioUrl)URL.revokeObjectURL(audioUrl);setAudioUrl(URL.createObjectURL(blob));stream.getTracks().forEach(t=>t.stop())};r.start();setRecording(true)}
  function stop(){recorder.current?.stop();setRecording(false)}

  return <div className="skill-lab pronunciation-lab">
    <aside className="skill-path-panel">
      <div className="language-switch"><button className={language==='fr'?'active':''} onClick={()=>setLanguage('fr')}>Français</button><button className={language==='ar'?'active':''} onClick={()=>setLanguage('ar')}>العربية</button></div>
      <div><span className="eyebrow">Parcours de prononciation</span><h3>{language==='fr'?'De la netteté à l’expression.':'من المخارج إلى الطلاقة'}</h3><p>{language==='fr'?'Une progression complète : sons, rythme, lecture et parole naturelle.':'Articulation, contrastes, durée puis lecture liée.'}</p></div>
      <div className="level-track">{levelOrder.map((l,i)=><button key={l} className={level===l?'active':''} onClick={()=>setLevel(l)}><span>{i+1}</span><div><strong>{l}</strong><small>{pronunciationLessons.filter(x=>x.language===language&&x.level===l).length} leçon(s)</small></div></button>)}</div>
    </aside>
    <section className="skill-stage pronunciation-stage">
      <header className="skill-stage-head"><div><span className="eyebrow">{level}</span><h2>{ex.title}</h2><p>{ex.focus}</p></div><div className="voice-card"><span>{language==='fr'?'Voix française':'Voix arabe'}</span><select value={voiceName} onChange={e=>setVoiceName(e.target.value)}>{voices.filter(v=>v.lang.toLowerCase().startsWith(language==='fr'?'fr':'ar')).map(v=><option key={v.name} value={v.name}>{v.name}</option>)}</select></div></header>
      <div className="pronunciation-focus"><div className={`model-sentence ${language==='ar'?'rtl':''}`}>{ex.text}</div><div className="focus-note"><span>Repère</span><p>{ex.hint}</p></div></div>
      <div className="listen-grid"><button onClick={()=>speak(.78)}><span>▶</span><div><strong>Écouter lentement</strong><small>entendre chaque repère</small></div></button><button onClick={()=>speak(.95)}><span>▶</span><div><strong>Écouter naturel</strong><small>rythme de phrase</small></div></button>{!recording?<button onClick={start}><span>●</span><div><strong>M’enregistrer</strong><small>une prise sans interruption</small></div></button>:<button className="recording" onClick={stop}><span>■</span><div><strong>Terminer</strong><small>enregistrement en cours</small></div></button>}</div>
      {audioUrl?<div className="compare-take"><div><span className="eyebrow">Comparer</span><h3>Modèle ↔ votre prise</h3><p>Écoutez alternativement. Repérez une seule différence, puis refaites une prise.</p></div><audio controls src={audioUrl}/><button className="quiet-action" onClick={start}>Refaire une prise</button></div>:<div className="micro-course"><span className="eyebrow">Mini-cours</span><h3>{language==='fr'?'Comment progresser sans faux score ?':'كيف تتدرّب؟'}</h3><p>{language==='fr'?'1. Écoutez. 2. Imitez une seule fois. 3. Réécoutez votre prise. 4. Corrigez un seul point à la fois.':'استمع، ثم قل الجملة، ثم قارن تسجيلك بالنموذج وركّز على فرق واحد في كل محاولة.'}</p></div>}
      <div className="lesson-strip">{lessons.map((x,i)=><button key={x.id} className={x.id===ex.id?'active':''} onClick={()=>setSelectedId(x.id)}><span>{String(i+1).padStart(2,'0')}</span><strong>{x.title}</strong><small>{x.focus}</small></button>)}</div>
    </section>
  </div>;
}
