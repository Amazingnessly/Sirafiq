#!/usr/bin/env bash
set -euo pipefail
cd /workspaces/Sirafiq
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/workspaces/Sirafiq_backup_avant_V15_${STAMP}.tar.gz"

echo "=== SAUVEGARDE DE L'ETAT ACTUEL ==="
tar --exclude='./node_modules' --exclude='./dist' --exclude='./.git' -czf "$BACKUP" .
echo "Sauvegarde : $BACKUP"

echo "=== INSTALLATION DES DEPENDANCES ==="
npm install

echo "=== BUILD ==="
npm run build

echo "=== VERIFICATION PAGES FUNCTIONS ==="
npx wrangler pages functions build functions --outdir=/tmp/sirafiq-v15-worker
rm -rf /tmp/sirafiq-v15-worker

echo "=== TERMINE ==="
echo "Ne pas committer avant validation locale."
