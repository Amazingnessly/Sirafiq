# Sirāfiq V17 — studio d’apprentissage

V17 traite les défauts bloquants relevés pendant les tests iPad de V16.

## Changements structurants

- **IA au premier plan** : l’accueil reste organisé autour de la Boussole et de la séance proposée.
- **Académie intégrée** : l’application est utile même sans support personnel, avec parcours français et arabe visibles dès `Apprendre > Parcours`.
- **Matière française** : voyelles, consonnes, R, nasales, e instable, liaisons, rythme, dictée, lecture expressive ; écriture gestuelle, ovales, familles de lettres, majuscules, mots, accents, dictée manuscrite et phrase autonome.
- **Matière arabe** : makhārij, voyelles, emphatiques, longueurs, sukūn, shadda, lecture liée ; ligne de base, familles, connexions, mots et initiations Naskh/Ruqʿah/Thuluth.
- **Chaque leçon contient maintenant un mini-cours et des exercices**, pas seulement un modèle.
- **Bibliothèque refaite pour l’iPad** : sélecteur de fichiers visible (label natif), import de plusieurs fichiers, collage direct de texte, erreurs visibles, cartes de supports plus compactes.
- **Médiathèque refaite comme studio média moderne** : palette bleu nuit/teal/prune, miniatures YouTube, filtres, vidéos et playlists, lecteur intégré, lien externe de secours et zone de notes.
- **Liens YouTube plus robustes** : watch, youtu.be, Shorts, live, embed et playlists.
- **Studio de translittération refait** : lecteur prioritaire, vitesses 0.5/0.75/1/1.25, ±5 s, boucle A/B, segments sous forme de cartes et retour au timecode.
- **Design moins dépendant du bordeaux/blanc** : univers colorés différents pour accueil, français, arabe, média et translittération.

## Validation attendue dans Codespaces

1. `npm install`
2. si nécessaire, vérifier `noEmit: true` dans `tsconfig.node.json`
3. `npm run build`
4. `npm run dev -- --host 0.0.0.0 --port 8794`

## Limites assumées

- Les modules Ruqʿah et Thuluth sont des **initiations pédagogiques**. Pour un enseignement calligraphique expert, il faudra intégrer des modèles vectoriels validés par un calligraphe.
- Le lecteur YouTube dépend des règles d’intégration de YouTube. Un bouton `Ouvrir sur YouTube` reste disponible comme solution de secours.
- L’analyse automatique des images/audio importés n’est pas simulée : le fichier est conservé localement mais seules les sources textuelles/PDF alimentent immédiatement les exercices textuels.
