# Tests prioritaires V17 sur iPad

1. **Bibliothèque**
   - toucher `Choisir des fichiers` ouvre bien Fichiers ;
   - importer un PDF et vérifier qu'il apparaît comme carte ;
   - importer/coller un texte et vérifier qu'il devient support actif ;
   - toucher `Travailler` ouvre une séance de mémorisation.

2. **Académie**
   - ouvrir `Apprendre > Parcours` sans support importé ;
   - vérifier que Français et Arabe proposent chacun voix + écriture ;
   - changer les 4 niveaux et vérifier que des leçons différentes apparaissent ;
   - vérifier la présence d'un mini-cours et d'exercices dans chaque leçon.

3. **Prononciation française**
   - sélectionner une voix française ;
   - écouter lentement/naturel ;
   - s'enregistrer et réécouter la prise.

4. **Écriture**
   - tracer au doigt ou Apple Pencil ;
   - tester Tracer / Copier / Sans modèle ;
   - en arabe, tester Naskh puis Ruqʿah/Thuluth.

5. **Médiathèque**
   - ajouter un lien `youtube.com/watch`, `youtu.be`, Short et playlist ;
   - vérifier vignette + lecteur intégré ;
   - si YouTube bloque l'intégration, vérifier le lien externe.

6. **Studio de translittération**
   - charger audio ou vidéo ;
   - vitesses 0.5/0.75/1/1.25 ;
   - ±5 s ;
   - définir boucle A/B ;
   - créer un segment au timecode courant et y revenir.

7. **Affichage iPad**
   - paysage et portrait ;
   - aucun bouton hors écran ;
   - scroll possible dans chaque atelier ;
   - aucune zone recouverte par la navigation.
