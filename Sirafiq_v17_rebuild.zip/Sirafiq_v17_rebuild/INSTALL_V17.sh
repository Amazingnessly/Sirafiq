#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "Sirāfiq V17 — validation"
npm install
python3 - <<'PY'
import json
from pathlib import Path
p=Path('tsconfig.node.json')
if p.exists():
    data=json.loads(p.read_text())
    opts=data.setdefault('compilerOptions',{})
    if opts.get('allowImportingTsExtensions'):
        opts['noEmit']=True
        p.write_text(json.dumps(data,indent=2)+'\n')
PY
npm run build
echo "✅ BUILD V17 RÉUSSI"
echo "Lancer ensuite : npm run dev -- --host 0.0.0.0 --port 8794"
