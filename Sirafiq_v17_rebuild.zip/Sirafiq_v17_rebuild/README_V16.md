# Sirāfiq V16 — reconstruction produit

V16 conserve la base React + TypeScript validée en V15 mais revoit la conception du produit autour des demandes prioritaires :

- IA/Boussole au premier plan dès l'accueil, avec une séance proposée et un accès direct à l'agent.
- Navigation iPad explicite : les espaces ne sont plus représentés par des icônes seules.
- Révision enrichie : rappel libre, questions ciblées, texte à trous, explication, détection d'erreur, restitution écrite/orale et carte de mémoire.
- Parcours de prononciation français et arabe, organisés de Fondations à Maîtrise.
- Voix française réintroduite via les voix `speechSynthesis` disponibles sur l'appareil, avec sélection de la voix et écoute lente/naturelle.
- Atelier d'écriture français et arabe : progression par niveaux, modes Tracer / Copier / Sans modèle, guidage tactile.
- Parcours arabe : ligne de base, familles de lettres, connexions et initiations Naskh / Ruqʿah / Thuluth.
- Accueil plus vivant et orienté retour quotidien : séance proposée, mémoire, reprise et parcours guidés.

## Important sur les calligraphies arabes

Les modules Naskh, Ruqʿah et Thuluth sont des parcours pédagogiques distincts dans V16. Le rendu exact dépend des polices disponibles sur l'appareil ; V16 ne prétend donc pas fournir un modèle calligraphique expert si une police/style adéquat n'est pas chargé. La prochaine étape peut intégrer des modèles vectoriels dédiés pour chaque style.

## Validation

Dans Codespaces :

```bash
npm install
npm run build
npm run dev -- --host 0.0.0.0 --port 8791
```

Le `tsconfig.node.json` contient déjà `noEmit: true`, nécessaire avec `allowImportingTsExtensions`.
