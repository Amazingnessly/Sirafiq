import { useMemo, useState } from 'react';
import type { MapNode, MindMapRecord, SupportRecord } from '../types';

const id = () => Math.random().toString(36).slice(2,10);

function clone(node: MapNode): MapNode { return { ...node, children: node.children.map(clone) }; }
function findNode(node: MapNode, target: string): MapNode | null { if (node.id === target) return node; for (const child of node.children) { const f = findNode(child, target); if (f) return f; } return null; }
function removeNode(node: MapNode, target: string): boolean { const idx = node.children.findIndex(c => c.id === target); if (idx >= 0) { node.children.splice(idx,1); return true; } return node.children.some(c => removeNode(c,target)); }

function NodeView({ node, selectedId, onSelect }: { node: MapNode; selectedId: string; onSelect: (id:string)=>void }) {
  return <div className="map-tree-node">
    <button className={node.id === selectedId ? 'map-node active' : 'map-node'} onClick={() => onSelect(node.id)}>{node.label}</button>
    {node.children.length ? <div className="map-children">{node.children.map(child => <NodeView key={child.id} node={child} selectedId={selectedId} onSelect={onSelect}/>)}</div> : null}
  </div>;
}

export function Maps({ support, onSave }: { support?: SupportRecord; onSave: (map: MindMapRecord) => Promise<void> }) {
  const initial = useMemo<MapNode>(() => ({ id: id(), label: support?.title || 'Idée centrale', children: [] }), [support?.id]);
  const [root, setRoot] = useState<MapNode>(initial);
  const [selected, setSelected] = useState(initial.id);
  const [label, setLabel] = useState(initial.label);
  const [saved, setSaved] = useState('');

  function mutate(mutator: (draft: MapNode)=>void) { const draft = clone(root); mutator(draft); setRoot(draft); }
  function selectNode(nodeId: string) { setSelected(nodeId); const n = findNode(root,nodeId); setLabel(n?.label || ''); }
  function newBlank() { const fresh={id:id(),label:'Nouvelle carte',children:[]};setRoot(fresh);setSelected(fresh.id);setLabel(fresh.label);setSaved(''); }
  function fromSupport() {
    if (!support?.text) return;
    const ideas = support.text.split(/(?<=[.!?])\s+/).map(s=>s.trim()).filter(s=>s.length>30).slice(0,5);
    const fresh: MapNode = { id:id(), label:support.title, children:ideas.map(x=>({id:id(),label:x.slice(0,72),children:[]})) };
    setRoot(fresh);setSelected(fresh.id);setLabel(fresh.label);setSaved('');
  }
  function addChild() { mutate(d => { const n=findNode(d,selected); if (n) n.children.push({id:id(),label:'Nouvelle idée',children:[]}); }); }
  function rename() { mutate(d => { const n=findNode(d,selected); if(n) n.label=label.trim()||'Idée'; }); }
  function remove() { if(selected===root.id)return; mutate(d=>removeNode(d,selected)); setSelected(root.id);setLabel(root.label); }
  async function save() { await onSave({title:root.label,supportId:support?.id,root,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()});setSaved('Carte enregistrée localement.'); }

  return <div className="maps-workspace">
    <aside className="workspace-sidebar map-tools">
      <div><span className="eyebrow">Atelier Cartes</span><h3>Créer librement ou partir d’un support.</h3><p>La génération est une aide. La carte reste entièrement la vôtre.</p></div>
      <button className="primary-small" onClick={newBlank}>＋ Carte vierge</button>
      <button className="quiet-action full" onClick={fromSupport} disabled={!support?.text}>Créer depuis le support</button>
      <div className="tool-divider"/>
      <label><span>Nœud sélectionné</span><input value={label} onChange={e=>setLabel(e.target.value)} /></label>
      <button className="quiet-action full" onClick={rename}>Renommer</button>
      <button className="quiet-action full" onClick={addChild}>＋ Ajouter une sous-idée</button>
      <button className="danger-link full" onClick={remove} disabled={selected===root.id}>Supprimer ce nœud</button>
      <div className="tool-divider"/>
      <button className="primary-action full" onClick={save}>Enregistrer la carte</button>
      {saved ? <small className="success-note">{saved}</small> : null}
    </aside>
    <section className="map-stage-v15"><div className="map-stage-toolbar"><span>Carte active</span><small>Cliquer un nœud pour le modifier</small></div><div className="map-canvas-v15"><NodeView node={root} selectedId={selected} onSelect={selectNode}/></div></section>
  </div>;
}
