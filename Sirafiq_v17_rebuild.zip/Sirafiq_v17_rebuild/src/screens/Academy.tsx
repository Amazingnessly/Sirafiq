import { pronunciationLessons, writingLessons } from '../dataCurriculum';
import type { LearnMode } from '../types';

export function Academy({ onOpen }: { onOpen:(mode:LearnMode)=>void }) {
  const frPron=pronunciationLessons.filter(x=>x.language==='fr').length;
  const arPron=pronunciationLessons.filter(x=>x.language==='ar').length;
  const frWrite=writingLessons.filter(x=>x.language==='fr').length;
  const arWrite=writingLessons.filter(x=>x.language==='ar').length;
  return <div className="academy-v17">
    <section className="academy-hero">
      <div><span className="eyebrow light">Académie Sirāfiq</span><h2>De la première trace à une maîtrise utilisable.</h2><p>Commencez sans importer quoi que ce soit. Français et arabe ont désormais leurs propres parcours, cours courts et exercices gradués.</p></div>
      <div className="academy-orbit"><span>FR</span><span>ع</span><strong>↗</strong></div>
    </section>
    <div className="academy-languages">
      <article className="language-world french-world">
        <header><div><span className="eyebrow">Français</span><h3>Écrire, prononcer, transmettre.</h3></div><span className="world-badge">Fondations → Maîtrise</span></header>
        <p>Travail du geste manuscrit, sons, rythme, dictée, lecture et parole pédagogique.</p>
        <div className="world-stats"><span><strong>{frPron}</strong> leçons de voix</span><span><strong>{frWrite}</strong> leçons d’écriture</span><span><strong>4</strong> niveaux</span></div>
        <div className="world-actions"><button onClick={()=>onOpen('pronunciation')}>Entrer dans le studio vocal <b>→</b></button><button onClick={()=>onOpen('writing')}>Ouvrir l’atelier d’écriture <b>→</b></button></div>
      </article>
      <article className="language-world arabic-world">
        <header><div><span className="eyebrow light">العربية</span><h3>من الصوت إلى الخطّ</h3></div><span className="world-badge dark">Naskh · Ruqʿah · Thuluth</span></header>
        <p>Articulation, durée, lecture liée, formes de lettres, connexions et initiation calligraphique.</p>
        <div className="world-stats"><span><strong>{arPron}</strong> leçons de voix</span><span><strong>{arWrite}</strong> leçons d’écriture</span><span><strong>4</strong> niveaux</span></div>
        <div className="world-actions"><button onClick={()=>onOpen('pronunciation')}>تدريب النطق <b>←</b></button><button onClick={()=>onOpen('writing')}>تدريب الكتابة <b>←</b></button></div>
      </article>
    </div>
    <section className="academy-method">
      <span className="eyebrow">Méthode</span><h3>Chaque leçon vous fait agir.</h3>
      <div><article><b>01</b><strong>Comprendre</strong><p>Un mini-cours très court avant la pratique.</p></article><article><b>02</b><strong>Observer</strong><p>Un modèle clair : son, tracé ou geste.</p></article><article><b>03</b><strong>Faire</strong><p>Exercices guidés, puis sans aide.</p></article><article><b>04</b><strong>Revenir</strong><p>La Boussole programme la prochaine pratique.</p></article></div>
    </section>
  </div>
}
