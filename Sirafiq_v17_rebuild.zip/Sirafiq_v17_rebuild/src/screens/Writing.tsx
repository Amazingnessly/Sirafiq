import { useEffect, useMemo, useRef, useState } from 'react';
import { levelOrder, writingLessons, type TrackLanguage, type TrackLevel } from '../dataCurriculum';

type GuideMode='trace'|'copy'|'memory';

export function Writing(){
  const canvas=useRef<HTMLCanvasElement>(null);
  const [language,setLanguage]=useState<TrackLanguage>('fr'); const [level,setLevel]=useState<TrackLevel>('Fondations');
  const lessons=useMemo(()=>writingLessons.filter(x=>x.language===language&&x.level===level),[language,level]);
  const [selectedId,setSelectedId]=useState(writingLessons[0].id); const lesson=lessons.find(x=>x.id===selectedId)??lessons[0]??writingLessons.find(x=>x.language===language)!;
  const [mode,setMode]=useState<GuideMode>('trace'); const [done,setDone]=useState(false);
  useEffect(()=>{if(!lessons.some(x=>x.id===selectedId)&&lessons[0])setSelectedId(lessons[0].id)},[lessons,selectedId]);
  useEffect(()=>{const c=canvas.current;if(!c)return;const ctx=c.getContext('2d');if(!ctx)return;const resize=()=>{const r=c.getBoundingClientRect();const d=devicePixelRatio||1;c.width=r.width*d;c.height=r.height*d;ctx.setTransform(d,0,0,d,0,0);ctx.lineWidth=3;ctx.lineCap='round';ctx.lineJoin='round';ctx.strokeStyle='#6f1732'};resize();let active=false;const point=(e:PointerEvent)=>{const r=c.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top}};const down=(e:PointerEvent)=>{active=true;c.setPointerCapture(e.pointerId);const p=point(e);ctx.beginPath();ctx.moveTo(p.x,p.y)};const move=(e:PointerEvent)=>{if(!active)return;const p=point(e);ctx.lineTo(p.x,p.y);ctx.stroke()};const up=()=>{active=false};c.addEventListener('pointerdown',down);c.addEventListener('pointermove',move);c.addEventListener('pointerup',up);window.addEventListener('resize',resize);return()=>{c.removeEventListener('pointerdown',down);c.removeEventListener('pointermove',move);c.removeEventListener('pointerup',up);window.removeEventListener('resize',resize)}} ,[]);
  function clear(){const c=canvas.current;const ctx=c?.getContext('2d');if(c&&ctx)ctx.clearRect(0,0,c.width,c.height);setDone(false)}
  function choose(id:string){setSelectedId(id);setMode('trace');clear()}

  return <div className="skill-lab writing-lab">
    <aside className="skill-path-panel">
      <div className="language-switch"><button className={language==='fr'?'active':''} onClick={()=>{setLanguage('fr');setLevel('Fondations')}}>Français</button><button className={language==='ar'?'active':''} onClick={()=>{setLanguage('ar');setLevel('Fondations')}}>العربية</button></div>
      <div><span className="eyebrow">Atelier d’écriture</span><h3>{language==='fr'?'Du geste à une écriture fluide.':'من الخطّ إلى الكتابة الواضحة'}</h3><p>{language==='fr'?'Tracez, copiez, puis restituez sans modèle.':'تدرّج من شكل الحرف إلى الوصل والكلمة ثم الأسلوب.'}</p></div>
      <div className="level-track">{levelOrder.map((l,i)=><button key={l} className={level===l?'active':''} onClick={()=>setLevel(l)}><span>{i+1}</span><div><strong>{l}</strong><small>{writingLessons.filter(x=>x.language===language&&x.level===l).length} leçon(s)</small></div></button>)}</div>
      {language==='ar'?<div className="calligraphy-note"><span className="eyebrow">Calligraphies proposées</span><div><b>Naskh</b><b>Ruqʿah</b><b>Thuluth</b></div><small>Progression pédagogique : formes lisibles d’abord, styles ensuite.</small></div>:null}
    </aside>
    <section className="skill-stage writing-stage">
      <header className="skill-stage-head"><div><span className="eyebrow">{level}{lesson.style?` · ${lesson.style}`:''}</span><h2>{lesson.title}</h2><p>{lesson.focus}</p></div><div className="guide-switch"><button className={mode==='trace'?'active':''} onClick={()=>setMode('trace')}>Tracer</button><button className={mode==='copy'?'active':''} onClick={()=>setMode('copy')}>Copier</button><button className={mode==='memory'?'active':''} onClick={()=>setMode('memory')}>Sans modèle</button></div></header>
      <div className="writing-coach-row"><div><span>1</span><p><strong>Observer</strong><small>{lesson.hint}</small></p></div><div><span>2</span><p><strong>Tracer</strong><small>suivre le modèle sans chercher la vitesse</small></p></div><div><span>3</span><p><strong>Restituer</strong><small>masquer le modèle et refaire de mémoire</small></p></div></div>
      <div className="writing-matter-v17"><article><span className="eyebrow">Cours du geste</span>{lesson.course.map((x,i)=><p key={i}><b>{i+1}</b>{x}</p>)}</article><article><span className="eyebrow">Série à faire</span>{lesson.drills.map((x,i)=><button key={i} onClick={()=>setMode(i===0?'trace':i===1?'copy':'memory')}><b>{String(i+1).padStart(2,'0')}</b><span>{x}</span></button>)}</article></div>
      {mode==='copy'?<div className={`writing-copy-model ${lesson.direction==='rtl'?'rtl':''}`}>{lesson.model}</div>:null}
      <div className={`trace-paper ${lesson.direction==='rtl'?'rtl':''}`}>
        {mode==='trace'?<div className={`trace-ghost ${lesson.direction==='rtl'?'arabic-ghost':''}`}>{lesson.model}</div>:null}
        {mode==='memory'?<div className="memory-prompt">Modèle masqué — restituez le geste de mémoire.</div>:null}
        <canvas ref={canvas}/><div className="baseline-lines" aria-hidden="true"/>
      </div>
      <div className="writing-footer"><div><span className="eyebrow">Leçon</span><p>{lesson.hint}</p></div><div className="stage-actions"><button className="quiet-action" onClick={clear}>Effacer</button><button className="primary-action" onClick={()=>setDone(true)}>J’ai terminé</button></div></div>
      {done?<div className="writing-feedback"><span>✓</span><div><strong>Comparez avant de recommencer.</strong><p>Choisissez un seul point à corriger : proportion, liaison, ligne de base ou régularité. Puis passez en mode « Sans modèle ».</p></div></div>:null}
      <div className="lesson-strip">{lessons.map((x,i)=><button key={x.id} className={x.id===lesson.id?'active':''} onClick={()=>choose(x.id)}><span>{String(i+1).padStart(2,'0')}</span><strong>{x.title}</strong><small>{x.focus}</small></button>)}</div>
    </section>
  </div>
}
