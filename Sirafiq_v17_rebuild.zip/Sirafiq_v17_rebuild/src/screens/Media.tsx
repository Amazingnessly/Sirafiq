import { useMemo, useState } from 'react';
import type { PlaylistRecord } from '../types';

type Parsed={videoId?:string;playlistId?:string};
function parseYouTube(raw:string):Parsed{
  try{
    const u=new URL(raw.trim()); const host=u.hostname.replace('www.','').replace('m.','');
    let videoId:string|undefined; let playlistId=u.searchParams.get('list')||undefined;
    if(host==='youtu.be') videoId=u.pathname.split('/').filter(Boolean)[0];
    else if(host.endsWith('youtube.com')){
      if(u.pathname==='/watch') videoId=u.searchParams.get('v')||undefined;
      else if(u.pathname.startsWith('/shorts/')) videoId=u.pathname.split('/')[2];
      else if(u.pathname.startsWith('/embed/')) videoId=u.pathname.split('/')[2];
      else if(u.pathname.startsWith('/live/')) videoId=u.pathname.split('/')[2];
    }
    return {videoId,playlistId};
  }catch{return {}}
}
function thumb(item:PlaylistRecord){return item.videoId?`https://i.ytimg.com/vi/${item.videoId}/hqdefault.jpg`:''}

export function Media({items,onAdd}:{items:PlaylistRecord[];onAdd:(record:PlaylistRecord)=>Promise<void>}){
  const [url,setUrl]=useState(''); const [title,setTitle]=useState(''); const [category,setCategory]=useState<PlaylistRecord['category']>('Religion');
  const [active,setActive]=useState<PlaylistRecord|undefined>(items[0]); const [error,setError]=useState(''); const [filter,setFilter]=useState<'Tous'|PlaylistRecord['category']>('Tous'); const [note,setNote]=useState('');
  const parsed=useMemo(()=>parseYouTube(url),[url]);
  async function add(){
    if(!url.trim())return; setError('');
    if(!parsed.videoId&&!parsed.playlistId){setError('Ce lien YouTube n’est pas reconnu. Copiez le lien d’une vidéo, d’un Short, d’un live ou d’une playlist.');return}
    const rec:PlaylistRecord={title:title.trim()||'Vidéo à étudier',category,url:url.trim(),videoId:parsed.videoId,playlistId:parsed.playlistId,createdAt:new Date().toISOString(),progress:0};
    await onAdd(rec); setActive(rec); setUrl(''); setTitle('');
  }
  const visible=items.filter(x=>filter==='Tous'||x.category===filter);
  const embed=active?.videoId?`https://www.youtube.com/embed/${active.videoId}?rel=0&modestbranding=1`:active?.playlistId?`https://www.youtube.com/embed/videoseries?list=${active.playlistId}&rel=0`:'';
  return <div className="screen media-v17">
    <section className="media-v17-hero"><div><span className="eyebrow light">Médiathèque · studio d’étude</span><h1>Regarder moins. Étudier mieux.</h1><p>Vos vidéos de religion, d’arabe et de Qour’ān deviennent des séances : regarder, noter, reprendre, translittérer.</p></div><div className="media-glow"><span>▶</span><i>study</i></div></section>
    <div className="media-v17-workspace">
      <aside className="media-v17-sidebar">
        <div className="media-add-v17"><span className="eyebrow">Ajouter</span><input value={url} onChange={e=>setUrl(e.target.value)} placeholder="Coller un lien YouTube…"/><input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Titre personnel (facultatif)"/><div className="media-add-row"><select value={category} onChange={e=>setCategory(e.target.value as PlaylistRecord['category'])}><option>Religion</option><option>Arabe</option><option>Qour’ān</option><option>Autre</option></select><button onClick={add}>Ajouter</button></div>{error?<p className="media-error">{error}</p>:parsed.videoId||parsed.playlistId?<p className="media-valid">✓ lien reconnu</p>:null}</div>
        <div className="media-filters">{(['Tous','Religion','Arabe','Qour’ān'] as const).map(x=><button key={x} className={filter===x?'active':''} onClick={()=>setFilter(x)}>{x}</button>)}</div>
        <div className="media-cards">{visible.length?visible.map((item,i)=><button key={item.id??i} className={active===item?'active':''} onClick={()=>{setActive(item);setNote(item.note||'')}}>{thumb(item)?<img src={thumb(item)} alt=""/>:<span className="playlist-cover">▶</span>}<div><small>{item.category}</small><strong>{item.title}</strong><em>{item.playlistId&&!item.videoId?'Playlist':'Vidéo'}</em></div></button>):<div className="media-list-empty">Vos vidéos apparaîtront ici avec leur vignette.</div>}</div>
      </aside>
      <section className="media-v17-stage">{active&&embed?<><div className="media-player-v17"><iframe src={embed} title={active.title} allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerPolicy="strict-origin-when-cross-origin" allowFullScreen/></div><div className="media-study-bar"><div><span className="eyebrow">{active.category}</span><h2>{active.title}</h2><p>Reprenez votre étude puis transformez un passage en note ou en séance.</p></div><a href={active.url} target="_blank" rel="noreferrer">Ouvrir sur YouTube ↗</a></div><div className="media-study-tools"><article><span>01</span><strong>Regarder</strong><p>Concentrez-vous sur un seul passage.</p></article><article><span>02</span><strong>Noter</strong><textarea value={note} onChange={e=>setNote(e.target.value)} placeholder="Une idée, un timecode, une question…"/></article><article><span>03</span><strong>Transformer</strong><div><button>Créer une révision</button><button>Translittérer ce passage</button></div></article></div></>:<div className="media-v17-empty"><div className="media-empty-orbit"><span>▶</span><i></i><b></b></div><span className="eyebrow">Votre scène</span><h2>Ajoutez une première vidéo ou playlist.</h2><p>Elle restera disponible ici comme matière d’étude, pas comme un simple lien sauvegardé.</p></div>}</section>
    </div>
  </div>
}
