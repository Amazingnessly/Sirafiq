import { useRef, useState } from 'react';
import type { SupportRecord } from '../types';
import { detectKind, extractText } from '../lib/support';

export function Library({ supports, activeSupportId, onImported, onActivate, onDelete }: {
  supports: SupportRecord[]; activeSupportId?: number; onImported: (support: SupportRecord) => Promise<void>;
  onActivate: (id: number) => void; onDelete: (id: number) => Promise<void>;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy,setBusy]=useState(false); const [query,setQuery]=useState(''); const [error,setError]=useState('');
  const [pasteOpen,setPasteOpen]=useState(false); const [pasteTitle,setPasteTitle]=useState(''); const [pasteText,setPasteText]=useState('');

  async function saveFile(file:File){
    const kind=detectKind(file); const now=new Date().toISOString();
    let text='';
    try{text=await extractText(file,kind)}catch(e){console.warn(e);text=''}
    await onImported({title:file.name.replace(/\.[^.]+$/,''),category:'Cours',kind,mimeType:file.type||'application/octet-stream',size:file.size,blob:file,text,createdAt:now,updatedAt:now});
  }
  async function importFiles(files:FileList|null){
    if(!files?.length)return; setBusy(true); setError('');
    try{for(const file of Array.from(files))await saveFile(file)}catch(e){setError(e instanceof Error?e.message:'Import impossible. Réessayez avec un autre fichier.')}finally{setBusy(false);if(inputRef.current)inputRef.current.value=''}
  }
  async function importPaste(){
    if(!pasteText.trim())return; setBusy(true); setError('');
    try{const now=new Date().toISOString();const blob=new Blob([pasteText],{type:'text/plain'});await onImported({title:pasteTitle.trim()||'Notes importées',category:'Cours',kind:'text',mimeType:'text/plain',size:blob.size,blob,text:pasteText.trim(),createdAt:now,updatedAt:now});setPasteText('');setPasteTitle('');setPasteOpen(false)}catch(e){setError(e instanceof Error?e.message:'Impossible d’enregistrer ce texte.')}finally{setBusy(false)}
  }

  const filtered=supports.filter(s=>s.title.toLocaleLowerCase('fr').includes(query.toLocaleLowerCase('fr')));
  return <div className="screen library-screen library-v17">
    <header className="screen-head compact-head library-v17-head"><div><span className="eyebrow">Bibliothèque active</span><h1>Faire entrer votre matière dans Sirāfiq.</h1><p>PDF, texte, image ou audio : l’original reste local. Le texte extrait alimente ensuite Réviser, Cartes et la Boussole.</p></div><div className="library-head-actions"><label className={`primary-action file-direct ${busy?'disabled':''}`}><input ref={inputRef} type="file" multiple accept=".pdf,.txt,.md,.csv,.json,image/*,audio/*" onChange={e=>importFiles(e.target.files)}/><span>{busy?'Import en cours…':'Choisir des fichiers'}</span><b>＋</b></label><button className="quiet-action" onClick={()=>setPasteOpen(v=>!v)}>Coller un texte</button></div></header>
    {error?<div className="import-error"><strong>Import interrompu</strong><span>{error}</span></div>:null}
    {pasteOpen?<section className="paste-studio"><div><span className="eyebrow">Import direct</span><h2>Coller un cours, une note ou un extrait.</h2><p>Pratique sur iPad quand un document n’est pas disponible comme fichier.</p></div><div><input value={pasteTitle} onChange={e=>setPasteTitle(e.target.value)} placeholder="Titre du support"/><textarea value={pasteText} onChange={e=>setPasteText(e.target.value)} placeholder="Collez votre texte ici…"/><button className="primary-small" onClick={importPaste} disabled={!pasteText.trim()||busy}>Ajouter à la bibliothèque</button></div></section>:null}
    <div className="library-toolbar-v15"><input type="search" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Rechercher un support…"/><span>{supports.length} support{supports.length!==1?'s':''}</span></div>
    {filtered.length?<div className="support-grid-v17">{filtered.map(s=><article key={s.id} className={activeSupportId===s.id?'active':''}><div className="support-cover"><span>{s.kind==='pdf'?'PDF':s.kind==='text'?'TXT':s.kind==='audio'?'AUDIO':s.kind.toUpperCase()}</span><i>{s.category}</i></div><div className="support-copy"><h3>{s.title}</h3><p>{s.text?`${s.text.slice(0,175)}${s.text.length>175?'…':''}`:'Original conservé localement. Vous pouvez l’utiliser comme support de séance.'}</p><small>{Math.max(1,Math.round(s.size/1024))} Ko · {activeSupportId===s.id?'actif dans les ateliers':'prêt à travailler'}</small></div><div className="support-actions"><button className="primary-small" onClick={()=>s.id&&onActivate(s.id)}>{activeSupportId===s.id?'Continuer':'Travailler'}</button><button className="danger-link" onClick={()=>s.id&&onDelete(s.id)}>Supprimer</button></div></article>)}</div>:<section className="library-empty-v17"><div className="empty-visual"><span>PDF</span><span>TXT</span><span>♫</span></div><div><span className="eyebrow">Premier support</span><h2>Importez-le directement ici.</h2><p>Le sélecteur ci-dessus ouvre l’app Fichiers de l’iPad. Vous pouvez aussi coller un texte.</p><label className="primary-action file-direct"><input type="file" multiple accept=".pdf,.txt,.md,.csv,.json,image/*,audio/*" onChange={e=>importFiles(e.target.files)}/><span>Ouvrir Fichiers</span><b>→</b></label></div></section>}
  </div>;
}
