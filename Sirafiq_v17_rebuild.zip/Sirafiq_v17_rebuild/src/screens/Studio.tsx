import { useRef, useState } from 'react';
interface Segment{id:string;time:string;source:string;translit:string;note:string}
const makeId=()=>Math.random().toString(36).slice(2,9);
const fmt=(t:number)=>`${Math.floor(t/60).toString().padStart(2,'0')}:${Math.floor(t%60).toString().padStart(2,'0')}`;

export function Studio(){
  const [media,setMedia]=useState(''); const [isVideo,setIsVideo]=useState(false); const [speed,setSpeed]=useState(.75); const [segments,setSegments]=useState<Segment[]>([{id:makeId(),time:'00:00',source:'',translit:'',note:''}]);
  const mediaRef=useRef<HTMLMediaElement|null>(null); const [loopA,setLoopA]=useState<number|undefined>(); const [loopB,setLoopB]=useState<number|undefined>();
  function update(id:string,key:keyof Segment,value:string){setSegments(s=>s.map(x=>x.id===id?{...x,[key]:value}:x))}
  function current(){return mediaRef.current?.currentTime??0} function seek(delta:number){if(mediaRef.current)mediaRef.current.currentTime=Math.max(0,current()+delta)}
  function add(){const t=current();setSegments(s=>[...s,{id:makeId(),time:fmt(t),source:'',translit:'',note:''}])}
  function load(file?:File){if(!file)return;setIsVideo(file.type.startsWith('video/'));setMedia(URL.createObjectURL(file));setTimeout(()=>{if(mediaRef.current)mediaRef.current.playbackRate=speed},0)}
  function applySpeed(v:number){setSpeed(v);if(mediaRef.current)mediaRef.current.playbackRate=v}
  function onTime(){const m=mediaRef.current;if(m&&loopA!=null&&loopB!=null&&m.currentTime>=loopB)m.currentTime=loopA}
  return <div className="screen studio-v17">
    <section className="studio-v17-head"><div><span className="eyebrow light">Studio de translittération</span><h1>Écouter. Boucler. Écrire. Reprendre.</h1><p>Un espace construit autour du média : vous restez au même endroit pendant toute la translittération.</p></div><div className="studio-head-wave"><i/><i/><i/><i/><i/><i/><i/></div></section>
    <div className="studio-v17-grid">
      <section className="studio-player-column">
        {!media?<label className="studio-drop-v17"><input type="file" accept="audio/*,video/*" onChange={e=>load(e.target.files?.[0])}/><span>＋</span><strong>Choisir un audio ou une vidéo</strong><small>Depuis Fichiers sur l’iPad</small></label>:<div className="studio-player-v17">{isVideo?<video ref={node=>{mediaRef.current=node}} src={media} controls onTimeUpdate={onTime}/>:<audio ref={node=>{mediaRef.current=node}} src={media} controls onTimeUpdate={onTime}/>}<div className="studio-transport"><button onClick={()=>seek(-5)}>−5 s</button><div className="speed-control">{[.5,.75,1,1.25].map(v=><button key={v} className={speed===v?'active':''} onClick={()=>applySpeed(v)}>{v}×</button>)}</div><button onClick={()=>seek(5)}>+5 s</button></div><div className="loop-control"><button onClick={()=>setLoopA(current())}>A {loopA!=null?fmt(loopA):'—'}</button><button onClick={()=>setLoopB(current())}>B {loopB!=null?fmt(loopB):'—'}</button><button onClick={()=>{setLoopA(undefined);setLoopB(undefined)}}>Effacer boucle</button></div></div>}
        <div className="studio-guide"><span className="eyebrow">Flux conseillé</span><ol><li><b>1</b>Écoutez une courte séquence.</li><li><b>2</b>Posez A et B pour la boucler.</li><li><b>3</b>Écrivez ce que vous entendez.</li><li><b>4</b>Ajoutez votre translittération puis comparez.</li></ol></div>
      </section>
      <section className="studio-segments-v17"><header><div><span className="eyebrow">Segments</span><h2>Votre travail, passage par passage.</h2></div><button onClick={add}>＋ Segment à {fmt(current())}</button></header><div className="segment-stack-v17">{segments.map((seg,i)=><article key={seg.id}><div className="segment-time-v17"><b>{String(i+1).padStart(2,'0')}</b><input value={seg.time} onChange={e=>update(seg.id,'time',e.target.value)}/><button onClick={()=>{const [m,s]=seg.time.split(':').map(Number);if(mediaRef.current)mediaRef.current.currentTime=(m||0)*60+(s||0)}}>Aller</button></div><div className="segment-fields-v17"><label><span>Texte source / transcription</span><textarea value={seg.source} onChange={e=>update(seg.id,'source',e.target.value)} placeholder="Ce que vous entendez ou le texte arabe…"/></label><label><span>Translittération</span><textarea value={seg.translit} onChange={e=>update(seg.id,'translit',e.target.value)} placeholder="Votre translittération…"/></label><label className="segment-note"><span>Note personnelle</span><textarea value={seg.note} onChange={e=>update(seg.id,'note',e.target.value)} placeholder="Règle, hésitation, vocabulaire…"/></label></div></article>)}</div></section>
    </div>
  </div>
}
