import { useMemo, useState } from 'react';
import type { ReviewRecord, SupportRecord } from '../types';

export function Home({ supports, reviews, onStart, onLibrary, onCompass, onLearn }: {
  supports: SupportRecord[];
  reviews: ReviewRecord[];
  onStart: () => void;
  onLibrary: () => void;
  onCompass: () => void;
  onLearn: () => void;
}) {
  const [intent,setIntent]=useState('Je veux avancer sans me disperser');
  const stats=useMemo(()=>{const now=Date.now();const due=reviews.filter(r=>new Date(r.nextReview).getTime()<=now);const fragile=reviews.filter(r=>r.mastery==='again'||r.mastery==='fragile');return{due,fragile}},[reviews]);
  const focus=stats.due[0]??stats.fragile[0];
  return <div className="screen v16-home">
    <section className="v16-ai-hero">
      <div className="ai-hero-main">
        <span className="eyebrow light">Boussole IA · votre point de départ</span>
        <h1>{focus ? 'On reprend là où votre mémoire en a besoin.' : 'Qu’allons-nous maîtriser aujourd’hui ?'}</h1>
        <p>{focus ? `« ${focus.title} » mérite votre attention. Sirāfiq peut organiser la séance autour de cette priorité.` : 'Dites votre objectif. Sirāfiq choisit le bon atelier, le bon niveau et une première action concrète.'}</p>
        <div className="ai-intent-box"><span>✦</span><input value={intent} onChange={e=>setIntent(e.target.value)} aria-label="Objectif du jour"/><button onClick={onCompass}>Préparer ma séance <span>→</span></button></div>
        <div className="quick-intents"><button onClick={onStart}>Réviser 15 min</button><button onClick={onLearn}>Travailler mon français</button><button onClick={onLearn}>Écriture arabe</button><button onClick={onCompass}>Laisser l’IA décider</button></div>
      </div>
      <aside className="ai-hero-plan">
        <span className="plan-label">Votre séance proposée</span>
        <div className="plan-time"><strong>{focus ? '12' : '18'}</strong><span>min</span></div>
        <ol><li><b>1</b><span><strong>{focus ? 'Rappel ciblé' : 'Échauffement'}</strong><small>{focus ? focus.title : '1 exercice court pour situer votre niveau'}</small></span></li><li><b>2</b><span><strong>Compétence</strong><small>Prononcer ou écrire avec guidage</small></span></li><li><b>3</b><span><strong>Vérification</strong><small>Une tentative sans aide</small></span></li></ol>
        <button onClick={onStart}>Commencer <span>→</span></button>
      </aside>
    </section>

    <section className="v16-dashboard-row">
      <article className="continue-card"><div><span className="eyebrow">Continuer</span><h2>{focus?.title ?? supports[0]?.title ?? 'Créez votre première matière'}</h2><p>{supports.length ? 'Votre support est prêt à devenir une séance.' : 'Importez un cours, un PDF, un texte ou un audio.'}</p></div><button onClick={supports.length?onStart:onLibrary}>{supports.length?'Reprendre':'Ajouter un support'} <span>→</span></button></article>
      <article className="memory-pulse"><span className="eyebrow">Mémoire</span><div className="pulse-ring"><strong>{reviews.length ? Math.max(18,100-stats.fragile.length*11) : 0}%</strong><small>{reviews.length?'en mouvement':'à découvrir'}</small></div><div className="pulse-stats"><span><b>{stats.due.length}</b> à revoir</span><span><b>{stats.fragile.length}</b> fragiles</span><span><b>{supports.length}</b> supports</span></div></article>
    </section>

    <section className="journeys-section"><header><div><span className="eyebrow">Parcours guidés</span><h2>De débuter à maîtriser.</h2></div><button className="quiet-action" onClick={onLearn}>Voir tous les parcours</button></header><div className="journey-grid">
      <button className="journey-card french" onClick={onLearn}><span className="journey-symbol">FR</span><div><small>Français</small><strong>Écrire & prononcer avec assurance</strong><p>Sons → lecture → tracé → dictée → expression.</p></div><span className="journey-arrow">↗</span></button>
      <button className="journey-card arabic" onClick={onLearn}><span className="journey-symbol ar">ع</span><div><small>Arabe</small><strong>Tracer, lire, articuler</strong><p>Formes → liaisons → mots → styles calligraphiques.</p></div><span className="journey-arrow">↗</span></button>
      <button className="journey-card support" onClick={onLibrary}><span className="journey-symbol">+</span><div><small>Vos matières</small><strong>Transformer vos supports</strong><p>PDF, cours, audio et vidéo deviennent des exercices.</p></div><span className="journey-arrow">↗</span></button>
    </div></section>
  </div>;
}
