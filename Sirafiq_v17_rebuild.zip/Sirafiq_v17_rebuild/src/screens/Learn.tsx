import type { LearnMode, Mastery, MindMapRecord, SupportRecord } from '../types';
import { LearnTabs } from '../components/LearnTabs';
import { Academy } from './Academy';
import { Memory } from './Memory';
import { Maps } from './Maps';
import { Pronunciation } from './Pronunciation';
import { Writing } from './Writing';

export function Learn({ mode, setMode, support, onPickSupport, onRate, onSaveMap }: {
  mode: LearnMode; setMode: (m: LearnMode) => void; support?: SupportRecord; onPickSupport: () => void;
  onRate: (mastery: Mastery, technique: string) => Promise<void>; onSaveMap: (map: MindMapRecord) => Promise<void>;
}) {
  const title=mode==='academy'?'Choisir un parcours, puis progresser.':mode==='memory'?'Réviser avec variété.':mode==='pronunciation'?'Former l’oreille et la voix.':mode==='writing'?'Former le geste, puis l’autonomie.':'Voir les relations, pas une liste.';
  return <div className="screen learn-screen v17-learn">
    <header className="learn-head v17-learn-head"><div><span className="eyebrow">Apprendre</span><h1>{title}</h1><p>{mode==='academy'?'Du contenu intégré pour travailler immédiatement, même sans support personnel.':mode==='memory'?'Sirāfiq varie les exercices pour forcer une vraie récupération.':mode==='pronunciation'?'Français et arabe, du son isolé à la parole ou lecture liée.':mode==='writing'?'Français et arabe : cours, tracé guidé, copie, restitution et calligraphie.':'Créez une carte librement ou structurez un support.'}</p></div><LearnTabs mode={mode} setMode={setMode}/></header>
    <div className="learn-workspace">
      {mode === 'academy' && <Academy onOpen={setMode}/>} 
      {mode === 'memory' && <Memory support={support} onPickSupport={onPickSupport} onRate={onRate} onOpenMap={() => setMode('maps')} />}
      {mode === 'pronunciation' && <Pronunciation/>}
      {mode === 'writing' && <Writing/>}
      {mode === 'maps' && <Maps support={support} onSave={onSaveMap}/>} 
    </div>
  </div>;
}
