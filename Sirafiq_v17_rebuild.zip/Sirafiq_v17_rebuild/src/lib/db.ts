import type { CourseRecord, MindMapRecord, PlaylistRecord, ReviewRecord, SupportRecord } from '../types';

const DB_NAME = 'sirafiq-v15';
const DB_VERSION = 1;
const STORES = {
  supports: 'supports',
  reviews: 'reviews',
  maps: 'maps',
  playlists: 'playlists',
  courses: 'courses'
} as const;

type StoreName = typeof STORES[keyof typeof STORES];

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORES.supports)) db.createObjectStore(STORES.supports, { keyPath: 'id', autoIncrement: true });
      if (!db.objectStoreNames.contains(STORES.reviews)) db.createObjectStore(STORES.reviews, { keyPath: 'key' });
      if (!db.objectStoreNames.contains(STORES.maps)) db.createObjectStore(STORES.maps, { keyPath: 'id', autoIncrement: true });
      if (!db.objectStoreNames.contains(STORES.playlists)) db.createObjectStore(STORES.playlists, { keyPath: 'id', autoIncrement: true });
      if (!db.objectStoreNames.contains(STORES.courses)) db.createObjectStore(STORES.courses, { keyPath: 'id', autoIncrement: true });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error('IndexedDB indisponible'));
  });
}

async function request<T>(storeName: StoreName, mode: IDBTransactionMode, action: (store: IDBObjectStore) => IDBRequest): Promise<T> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, mode);
    const store = tx.objectStore(storeName);
    const req = action(store);
    let result: T;
    req.onsuccess = () => { result = req.result as T; };
    req.onerror = () => reject(req.error ?? new Error('Erreur IndexedDB'));
    tx.oncomplete = () => { db.close(); resolve(result); };
    tx.onerror = () => { db.close(); reject(tx.error ?? new Error('Transaction IndexedDB échouée')); };
  });
}

export const db = {
  addSupport: (record: SupportRecord) => request<number>(STORES.supports, 'readwrite', s => s.add(record)),
  putSupport: (record: SupportRecord) => request<number>(STORES.supports, 'readwrite', s => s.put(record)),
  listSupports: () => request<SupportRecord[]>(STORES.supports, 'readonly', s => s.getAll()),
  getSupport: (id: number) => request<SupportRecord | undefined>(STORES.supports, 'readonly', s => s.get(id)),
  deleteSupport: (id: number) => request<void>(STORES.supports, 'readwrite', s => s.delete(id)),
  putReview: (record: ReviewRecord) => request<string>(STORES.reviews, 'readwrite', s => s.put(record)),
  listReviews: () => request<ReviewRecord[]>(STORES.reviews, 'readonly', s => s.getAll()),
  addMap: (record: MindMapRecord) => request<number>(STORES.maps, 'readwrite', s => s.add(record)),
  putMap: (record: MindMapRecord) => request<number>(STORES.maps, 'readwrite', s => s.put(record)),
  listMaps: () => request<MindMapRecord[]>(STORES.maps, 'readonly', s => s.getAll()),
  addPlaylist: (record: PlaylistRecord) => request<number>(STORES.playlists, 'readwrite', s => s.add(record)),
  listPlaylists: () => request<PlaylistRecord[]>(STORES.playlists, 'readonly', s => s.getAll()),
  putCourse: (record: CourseRecord) => request<number>(STORES.courses, 'readwrite', s => s.put(record)),
  listCourses: () => request<CourseRecord[]>(STORES.courses, 'readonly', s => s.getAll())
};
