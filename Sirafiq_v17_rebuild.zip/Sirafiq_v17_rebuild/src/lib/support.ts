import * as pdfjsLib from 'pdfjs-dist';
import type { SupportRecord } from '../types';

pdfjsLib.GlobalWorkerOptions.workerSrc = new URL('pdfjs-dist/build/pdf.worker.min.mjs', import.meta.url).toString();

export function detectKind(file: File): SupportRecord['kind'] {
  if (file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')) return 'pdf';
  if (file.type.startsWith('text/') || /\.(txt|md|csv|json)$/i.test(file.name)) return 'text';
  if (file.type.startsWith('image/')) return 'image';
  if (file.type.startsWith('audio/')) return 'audio';
  return 'file';
}

export async function extractText(file: Blob, kind: SupportRecord['kind']): Promise<string> {
  if (kind === 'text') return (await file.text()).replace(/\u0000/g, '').trim();
  if (kind === 'pdf') {
    const buffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: buffer }).promise;
    let text = '';
    for (let p = 1; p <= pdf.numPages; p++) {
      const page = await pdf.getPage(p);
      const content = await page.getTextContent();
      text += content.items.map(item => 'str' in item ? item.str : '').join(' ') + '\n';
      if (text.length > 120000) break;
    }
    return text.replace(/\s+\n/g, '\n').replace(/[ \t]+/g, ' ').trim();
  }
  return '';
}

export function supportSummary(text: string): string[] {
  return text.split(/(?<=[.!?])\s+/).map(s => s.trim()).filter(s => s.length > 35).slice(0, 8);
}

export function makeQuestions(text: string): string[] {
  const sentences = supportSummary(text).slice(0, 5);
  return sentences.map((sentence, i) => i === 0
    ? `Quelle est l'idée principale de : « ${sentence.slice(0, 110)}${sentence.length > 110 ? '…' : ''} » ?`
    : `Restituez sans regarder le point ${i + 1} de ce support.`);
}
