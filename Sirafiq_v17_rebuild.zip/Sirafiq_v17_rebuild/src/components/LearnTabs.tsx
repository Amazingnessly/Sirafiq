import type { LearnMode } from '../types';
import { Icon } from './Icon';

const modes: { id: LearnMode; label: string; hint: string }[] = [
  { id: 'academy', label: 'Parcours', hint: 'Français & arabe' },
  { id: 'memory', label: 'Mémoriser', hint: 'Rappel actif' },
  { id: 'pronunciation', label: 'Prononcer', hint: 'Écouter & comparer' },
  { id: 'writing', label: 'Écrire', hint: 'Progression guidée' },
  { id: 'maps', label: 'Cartes', hint: 'Créer ou structurer' }
];

export function LearnTabs({ mode, setMode }: { mode: LearnMode; setMode: (m: LearnMode) => void }) {
  return <div className="learn-tabs">{modes.map(item => (
    <button key={item.id} className={mode === item.id ? 'active' : ''} onClick={() => setMode(item.id)}>
      <Icon name={item.id}/><span><strong>{item.label}</strong><small>{item.hint}</small></span>
    </button>
  ))}</div>;
}
