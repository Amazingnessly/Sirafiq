export type TrackLanguage = 'fr' | 'ar';
export type TrackLevel = 'Fondations' | 'Débutant' | 'Intermédiaire' | 'Maîtrise';

export interface PronunciationLesson {
  id: string; language: TrackLanguage; level: TrackLevel; title: string; text: string; hint: string; focus: string;
  course: string[]; drills: string[];
}
export interface WritingLesson {
  id: string; language: TrackLanguage; level: TrackLevel; title: string; model: string; hint: string; focus: string;
  direction?: 'ltr' | 'rtl'; style?: string; course: string[]; drills: string[];
}

const P=(id:string,language:TrackLanguage,level:TrackLevel,title:string,text:string,focus:string,hint:string,course:string[],drills:string[]):PronunciationLesson=>({id,language,level,title,text,focus,hint,course,drills});
const W=(id:string,language:TrackLanguage,level:TrackLevel,title:string,model:string,focus:string,hint:string,course:string[],drills:string[],direction?:'ltr'|'rtl',style?:string):WritingLesson=>({id,language,level,title,model,focus,hint,course,drills,direction,style});

export const pronunciationLessons: PronunciationLesson[] = [
  P('fr-vowels','fr','Fondations','Carte des voyelles','i — é — è — a — o — ou — u','placement et contraste','Cherchez un son stable avant d’accélérer.',[
    'Le français oppose des voyelles très proches : travaillez-les par paires.','Gardez la mâchoire calme et modifiez surtout la langue et l’arrondissement des lèvres.'],['i / u : lit — lu','ou / u : roue — rue','é / è : fée — fait']),
  P('fr-consonants','fr','Fondations','Consonnes nettes','pa — ba · ta — da · ka — ga','attaque et voisement','Faites entendre la différence sans forcer.',[
    'Les paires sourde/sonore se distinguent notamment par la vibration des cordes vocales.','Commencez par des syllabes, puis passez aux mots.'],['pa / ba','tout / doux','cou / goût']),
  P('fr-r','fr','Fondations','Le R français','rue — rire — partir — regarder','/ʁ/ français','Cherchez un frottement léger, pas une tension de gorge.',[
    'Le R standard français est généralement produit vers l’arrière de la bouche.','L’objectif est la régularité dans le mot, pas un R exagéré.'],['ra — ri — rou','rue / roue','partir / parler']),
  P('fr-nasal','fr','Débutant','Voyelles nasales','un bon pain blanc — un parfum brun','on · an · in · un','N’ajoutez pas de consonne finale.',[
    'L’air passe en partie par le nez : la voyelle change de résonance.','Travaillez une opposition à la fois.'],['beau / bon','bas / banc','paix / pain','brin / brun']),
  P('fr-schwa','fr','Débutant','Le e instable','Je te le redirai demain.','e caduc','Écoutez quand le e disparaît et quand il aide la fluidité.',[
    'Dans la parole naturelle, certains e peuvent s’effacer.','Ne supprimez pas mécaniquement : écoutez le groupe de mots.'],['je te le dis','samedi matin','petite fenêtre']),
  P('fr-liaison','fr','Intermédiaire','Liaisons et enchaînements','Vous avez un exemple important. Nous allons en parler.','enchaînement et liaison','Faites entendre uniquement les liaisons naturelles.',[
    'L’enchaînement relie une consonne déjà prononcée à la voyelle suivante.','La liaison fait apparaître une consonne dans certains contextes.'],['vous avez','un grand ami','avec elle']),
  P('fr-rhythm','fr','Intermédiaire','Groupes de sens','Aujourd’hui / je vais vous présenter / une idée importante.','rythme et respiration','Les pauses suivent le sens, pas chaque mot.',[
    'Le français organise la phrase en groupes rythmiques.','La syllabe finale du groupe porte souvent davantage d’énergie.'],['marquez les groupes','lisez sans couper chaque mot','refaites avec une respiration']),
  P('fr-dictation','fr','Intermédiaire','Dictée phonétique','Les étudiants ont enfin compris cette explication.','écouter puis transcrire','Écoutez deux fois maximum avant d’écrire.',[
    'La dictée entraîne la discrimination, la segmentation et l’orthographe.','Après correction, relisez à voix haute la phrase correcte.'],['écouter sans écrire','écrire de mémoire','comparer puis relire']),
  P('fr-express','fr','Maîtrise','Parole pédagogique','Retenez d’abord le principe. Ensuite, nous verrons un exemple. Enfin, reformulez avec vos propres mots.','clarté et expression','Hiérarchisez annonce, exemple et conclusion.',[
    'Une parole claire met en relief les mots porteurs de sens.','Variez débit, pauses et intensité sans théâtraliser.'],['annoncer une idée','donner un exemple','conclure en une phrase']),
  P('fr-reading','fr','Maîtrise','Lecture expressive','Comprendre un texte, c’est aussi entendre sa structure et ses intentions.','lecture expressive','Faites sentir la ponctuation et la logique du texte.',[
    'Préparez le texte en repérant groupes de sens et mots-clés.','Enregistrez une première lecture puis une seconde plus intentionnelle.'],['lecture neutre','lecture préparée','comparaison des deux prises']),

  P('ar-makhraj','ar','Fondations','Carte des points d’articulation','ء ه ع ح غ خ — ق ك — ج ش ي','makhārij de base','Travaillez très lentement et comparez les zones d’articulation.',[
    'L’arabe distingue des consonnes par leur point d’articulation.','Une articulation claire est plus importante que la vitesse.'],['ء / ع','ه / ح','ك / ق']),
  P('ar-short','ar','Fondations','Voyelles courtes','بَ — بِ — بُ · تَ — تِ — تُ','fatḥa · kasra · ḍamma','Gardez les voyelles courtes réellement brèves.',[
    'Les voyelles courtes modifient la syllabe sans allonger sa durée.','Travaillez sur une même consonne avant de changer de lettre.'],['بَ بِ بُ','تَ تِ تُ','سَ سِ سُ']),
  P('ar-emphatic','ar','Débutant','Lettres emphatiques','ص ض ط ظ — س د ت ذ','tafkhīm et contraste','Comparez directement la paire emphatique/non emphatique.',[
    'L’emphase affecte la consonne et la qualité des voyelles voisines.','Ne transformez pas la tension en crispation.'],['س / ص','د / ض','ت / ط','ذ / ظ']),
  P('ar-length','ar','Débutant','Voyelles longues','قَالَ — قِيلَ — يَقُولُ','madd et durée','Gardez une durée régulière et nette.',[
    'Une voyelle longue doit être perceptiblement plus longue que la voyelle courte.','Travaillez avec un battement régulier.'],['قَلَ / قَالَ','قِلْ / قِيلَ','قُلْ / يَقُولُ']),
  P('ar-sukun','ar','Intermédiaire','Sukūn et groupes consonantiques','يَكْتُبُ — نَفْهَمُ — أَكْبَرُ','fermeture syllabique','Fermez la consonne sans ajouter une voyelle parasite.',[
    'Le sukūn indique l’absence de voyelle après la consonne.','Évitez d’insérer un petit son entre deux consonnes.'],['يَكْتُبُ','نَفْهَمُ','أَكْبَرُ']),
  P('ar-shadda','ar','Intermédiaire','Shadda et gémination','مُعَلِّم — رَبِّ — إِنَّ','consonne doublée','Tenez la consonne avant de libérer la syllabe suivante.',[
    'La shadda représente une consonne géminée, articulée plus longtemps.','Travaillez d’abord très lentement avec une pulsation.'],['رَبِّ','إِنَّ','مُعَلِّم']),
  P('ar-phrase','ar','Maîtrise','Lecture liée','العِلْمُ نُورٌ وَالفَهْمُ طَرِيقٌ إِلَى العَمَلِ','fluidité et articulation','Préservez articulation et longueurs sans précipiter la phrase.',[
    'Une lecture fluide ne doit pas effacer les contrastes phonétiques.','Préparez les groupes de sens avant d’augmenter le débit.'],['lecture lente','lecture liée','relecture enregistrée']),
  P('ar-expression','ar','Maîtrise','Lecture expliquée','أَقْرَأُ الفِكْرَةَ ثُمَّ أَشْرَحُهَا بِكَلِمَاتِي','lecture puis reformulation','Lisez, puis reformulez sans regarder.',[
    'Associer lecture et reformulation transforme la prononciation en compétence active.','Visez une phrase courte et claire avant d’allonger.'],['lire','masquer','reformuler'])
];

export const writingLessons: WritingLesson[] = [
  W('fr-gestures','fr','Fondations','Gestes fondateurs','llll   eeee   mmmm','boucles · étrécies · ponts','Régularité avant vitesse.',[
    'Les lettres cursives sont construites à partir d’un petit nombre de gestes.','Travaillez lentement la taille et l’inclinaison avant les mots.'],['4 lignes de boucles','4 séries de ponts','alterner l / e / m']),
  W('fr-ovals','fr','Fondations','Ovales et rotations','oooo   aaaa   dddd','ovales et fermeture','Fermez l’ovale sans casser le mouvement.',[
    'L’ovale sert de base à plusieurs lettres.','Le point de départ et le sens du mouvement doivent rester constants.'],['ovales seuls','o puis a','a puis d']),
  W('fr-lowercase','fr','Débutant','Familles de minuscules','a c d g   i u t   n m p','proportions et liaisons','Travaillez par familles de gestes.',[
    'Les lettres partagent des structures : ovale, boucle, pont, étrécie.','Regrouper les lettres réduit la charge motrice.'],['a c d g','i u t','n m p']),
  W('fr-capitals','fr','Débutant','Majuscules utiles','A M S L R   Bonjour','majuscules et départs','Cherchez d’abord la lisibilité, pas l’ornement.',[
    'Les majuscules peuvent être travaillées comme formes indépendantes.','Gardez leur hauteur cohérente avec les minuscules.'],['A M S','L R','Bonjour']),
  W('fr-words','fr','Intermédiaire','Mots liés','mémoire   chemin   savoir','liaisons et régularité','Conservez hauteurs, espaces et rythme du mot.',[
    'Le mot doit garder une continuité sans écraser les espaces internes.','Comparez hauteur des petites lettres et hampes.'],['mémoire','chemin','savoir']),
  W('fr-accents','fr','Intermédiaire','Accents et ponctuation','é è ê ç — ? ! ; :','signes et placement','Ajoutez les signes après avoir stabilisé le mot.',[
    'Les accents doivent être lisibles mais légers.','La ponctuation structure la ligne et la lecture.'],['é è ê','garçon','phrase ponctuée']),
  W('fr-dictation','fr','Maîtrise','Dictée manuscrite','Je prends le temps d’écrire clairement.','écoute → écriture','Écoutez, écrivez sans modèle puis comparez.',[
    'La dictée manuscrite associe mémoire orthographique et automatisation du geste.','Corrigez un seul type d’erreur par reprise.'],['dictée de mots','dictée de phrase','copie corrective']),
  W('fr-sentence','fr','Maîtrise','Phrase autonome','Je restitue avant de vérifier.','fluidité et lisibilité','Copiez une fois, puis écrivez sans modèle.',[
    'L’objectif final est une écriture suffisamment automatique pour servir la pensée.','Préservez lisibilité, rythme et espacement.'],['copie','sans modèle','phrase personnelle']),

  W('ar-baseline','ar','Fondations','Ligne et direction','ا  ل  د  ر  و','direction · ligne de base','Posez la ligne de base et le sens droite → gauche.',[
    'L’écriture arabe progresse de droite à gauche et s’organise autour d’une ligne de base.','Commencez par des formes simples qui ne se lient pas toujours des deux côtés.'],['ا ل','د ر و','ligne de formes'], 'rtl','Naskh'),
  W('ar-dots','ar','Fondations','Points et familles','ب ت ث   ج ح خ','squelette et points','Écrivez d’abord le squelette commun, puis placez les points.',[
    'Plusieurs lettres partagent la même structure et se distinguent par les points.','Cette logique permet de mémoriser les familles plutôt que des lettres isolées.'],['ب ت ث','ج ح خ','identifier sans points'], 'rtl','Naskh'),
  W('ar-families','ar','Débutant','Familles de formes','س ش   ص ض   ط ظ   ع غ','formes et proportions','Comparez les lettres d’une même famille.',[
    'Travaillez les proportions relatives et la position sur la ligne.','Gardez les points et signes secondaires pour la fin.'],['س ش','ص ض','ع غ'], 'rtl','Naskh'),
  W('ar-connections','ar','Débutant','Connexions','كتب   علم   مدرسة','formes initiale · médiane · finale','Repérez comment la lettre change selon sa position.',[
    'Certaines lettres se lient des deux côtés, d’autres interrompent la liaison suivante.','Travaillez le même mot lentement en observant chaque transition.'],['كتب','علم','مدرسة'], 'rtl','Naskh'),
  W('ar-words','ar','Intermédiaire','Mots équilibrés','كتاب   قلم   معرفة','mot et espacement','Gardez la cohérence des hauteurs et de la ligne.',[
    'L’espacement appartient au rythme graphique du mot.','Ne compressez pas les connexions pour écrire plus vite.'],['كتاب','قلم','معرفة'], 'rtl','Naskh'),
  W('ar-ruqah','ar','Intermédiaire','Ruqʿah — geste compact','العلم نور','initiation Ruqʿah','Cherchez un geste compact et direct.',[
    'La Ruqʿah est ici abordée comme initiation gestuelle, non comme certification calligraphique.','Comparez la compacité avec votre écriture Naskh.'],['العلم','نور','phrase courte'], 'rtl','Ruqʿah'),
  W('ar-thuluth','ar','Maîtrise','Thuluth — composition','بسم الله','initiation aux proportions','Travaillez lentement la composition générale.',[
    'Le Thuluth exige un travail calligraphique expert : ce module sert seulement d’initiation visuelle.','Observez équilibre, courbes et espace avant de tracer.'],['observation','tracé lent','composition simple'], 'rtl','Thuluth'),
  W('ar-free','ar','Maîtrise','Phrase autonome','أكتب بوضوح ثم أراجع عملي','écriture autonome','Écrivez une première fois avec modèle, puis sans modèle.',[
    'L’objectif est de conserver la lisibilité et les connexions sans dépendre du modèle.','Terminez par une auto-comparaison ciblée.'],['copie','sans modèle','phrase personnelle'], 'rtl','Naskh')
];

export const levelOrder: TrackLevel[] = ['Fondations','Débutant','Intermédiaire','Maîtrise'];
