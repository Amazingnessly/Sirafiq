import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './styles.css';
import './v16.css';
import './v17.css';

createRoot(document.getElementById('root')!).render(<StrictMode><App/></StrictMode>);
