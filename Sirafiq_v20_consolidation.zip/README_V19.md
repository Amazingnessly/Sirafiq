# Sirāfiq V19 — consolidation ciblée

Cette version consolide les points qui ne doivent plus régresser :

- import de supports avec états explicites, temporisation et conservation de l'original même si l'extraction textuelle échoue ;
- cursus français et arabe visuellement et pédagogiquement séparés ;
- écriture arabe mise au premier plan avec ligne de base, direction, formes, connexions puis calligraphies ;
- écriture française structurée autour du geste, des lignes, des familles de lettres, des syllabes/mots, de la copie et de la dictée ;
- modèles d'écriture avec guides de ligne plus explicites (français : zones de hauteur ; arabe : ligne de base renforcée) ;
- prononciation française : tentative de modèle vocal Sirāfiq via `/api/voice`, puis repli explicite sur une voix locale ;
- révision organisée en séquence courte ordonnée plutôt qu'en simple catalogue d'exercices ;
- Transmission : ajout direct d'un support depuis l'écran en plus du choix dans la Bibliothèque ;
- interface moins chargée : deux cursus distincts, plans de séance plus lisibles, panneaux translucides conservés.

## Important
Les modèles calligraphiques experts (Naskh/Ruqʿah/Thuluth) nécessiteront des tracés vectoriels validés pour prétendre enseigner fidèlement chaque style. V19 améliore les guides et la progression sans prétendre remplacer un modèle calligraphique expert.
