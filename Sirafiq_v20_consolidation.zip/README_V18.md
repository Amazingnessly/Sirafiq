# Sirāfiq V18 — workspace vivant

Cette passe conserve le socle React/TypeScript de V17 et traite les demandes prioritaires :

- direction visuelle plus vivante avec surfaces translucides et profondeur, tout en gardant les surfaces d'écriture opaques ;
- interface moins chargée et espaces de travail plus compacts ;
- nouveau Tableau blanc multipage : ajout/suppression de pages, couleurs, épaisseur, gomme locale, annuler/rétablir et effacement de la page courante ;
- Transmission peut désormais associer un support déjà importé et reprendre son texte extrait ;
- les parcours français/arabe et les imports V17 sont conservés pour la passe pédagogique suivante.

## Validation attendue
1. Build TypeScript/Vite.
2. iPad portrait/paysage : aucune commande inaccessible.
3. Tableau blanc : dessiner, changer couleur, gommer une zone, annuler, ajouter une page, revenir à la première page.
4. Transmission : choisir un support et vérifier qu'il reste associé.
