# Sirāfiq V20 — consolidation

Priorités : suppression totale de la translittération, Studio de transcription avec lien YouTube, mémorisation progressive avec flashcards et carte mentale visible, correction de « Refaire une prise », voix avec état d’erreur explicite, maintien de Mes cours / supports et des cursus français-arabe séparés.

## Test iPad prioritaire
1. Prononcer : écouter lentement/naturel puis enregistrer et « Refaire une prise ».
2. Mémoriser : séance progressive + flashcard ; onglet Carte mentale.
3. Studio de transcription : fichier local puis lien YouTube.
4. Cours & supports : créer, enregistrer, rouvrir et utiliser un support.
5. Bibliothèque : importer PDF/TXT/image/audio et vérifier les états.
