import type { ReactNode } from 'react';
import type { Section } from '../types';
import { Icon } from './Icon';

const nav: { id: Section; label: string }[] = [
  { id: 'home', label: 'Aujourd’hui' },
  { id: 'learn', label: 'Apprendre' },
  { id: 'library', label: 'Bibliothèque' },
  { id: 'media', label: 'Médiathèque' },
  { id: 'studio', label: 'Translittération' },
  { id: 'courses', label: 'Cours' },
  { id: 'compass', label: 'Boussole' }
];

export function AppShell({ section, setSection, children, activeSupportTitle }: {
  section: Section;
  setSection: (value: Section) => void;
  children: ReactNode;
  activeSupportTitle?: string;
}) {
  return (
    <div className="app-frame">
      <aside className="app-rail">
        <button className="brand-mark" onClick={() => setSection('home')} aria-label="Sirāfiq — accueil">
          <img src="/assets/logo-sirafiq-verrouille.png" alt="Sirāfiq" />
        </button>
        <nav className="rail-nav" aria-label="Navigation principale">
          {nav.map(item => (
            <button key={item.id} className={section === item.id ? 'active' : ''} onClick={() => setSection(item.id)}>
              <Icon name={item.id} />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>
        <div className="rail-foot">
          <span className="privacy-dot" />
          <small>Local d’abord</small>
        </div>
      </aside>
      <div className="app-stage">
        <header className="stage-topbar">
          <div>
            <span className="stage-kicker">Sirāfiq</span>
            {activeSupportTitle ? <strong className="active-support-pill">Support actif · {activeSupportTitle}</strong> : null}
          </div>
          <div className="stage-status"><span />Prêt</div>
        </header>
        <main className="stage-content">{children}</main>
      </div>
      <nav className="mobile-nav" aria-label="Navigation mobile">
        {nav.slice(0,5).map(item => (
          <button key={item.id} className={section === item.id ? 'active' : ''} onClick={() => setSection(item.id)}>
            <Icon name={item.id} /><small>{item.label}</small>
          </button>
        ))}
      </nav>
    </div>
  );
}
