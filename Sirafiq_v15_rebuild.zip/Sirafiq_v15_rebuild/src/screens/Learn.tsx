import type { LearnMode, Mastery, MindMapRecord, SupportRecord } from '../types';
import { LearnTabs } from '../components/LearnTabs';
import { Memory } from './Memory';
import { Maps } from './Maps';
import { Pronunciation } from './Pronunciation';
import { Writing } from './Writing';

export function Learn({ mode, setMode, support, onPickSupport, onRate, onSaveMap }: {
  mode: LearnMode;
  setMode: (m: LearnMode) => void;
  support?: SupportRecord;
  onPickSupport: () => void;
  onRate: (mastery: Mastery, technique: string) => Promise<void>;
  onSaveMap: (map: MindMapRecord) => Promise<void>;
}) {
  return <div className="screen learn-screen">
    <header className="learn-head"><div><span className="eyebrow">Apprendre</span><h1>Un atelier à la fois.</h1></div><LearnTabs mode={mode} setMode={setMode}/></header>
    <div className="learn-workspace">
      {mode === 'memory' && <Memory support={support} onPickSupport={onPickSupport} onRate={onRate} onOpenMap={() => setMode('maps')} />}
      {mode === 'pronunciation' && <Pronunciation/>}
      {mode === 'writing' && <Writing/>}
      {mode === 'maps' && <Maps support={support} onSave={onSaveMap}/>} 
    </div>
  </div>;
}
