import type { ReviewRecord, SupportRecord } from '../types';

export function Home({ supports, reviews, onStart, onLibrary, onCompass }: {
  supports: SupportRecord[];
  reviews: ReviewRecord[];
  onStart: () => void;
  onLibrary: () => void;
  onCompass: () => void;
}) {
  const now = Date.now();
  const due = reviews.filter(r => new Date(r.nextReview).getTime() <= now);
  const fragile = reviews.filter(r => r.mastery === 'again' || r.mastery === 'fragile');
  const primary = due[0] ?? fragile[0];
  return (
    <div className="screen home-screen">
      <section className="hero-card">
        <div className="hero-copy">
          <span className="eyebrow">Aujourd’hui</span>
          <h1>{primary ? 'Une seule priorité, puis la suite.' : 'Votre espace pour apprendre vraiment.'}</h1>
          <p>{primary
            ? `Commencez par « ${primary.title} ». Sirāfiq garde le reste hors de votre chemin.`
            : supports.length ? 'Choisissez un support et transformez-le en séance concrète, sans vous perdre dans les outils.' : 'Importez votre premier support. Il deviendra immédiatement exploitable dans vos séances.'}</p>
          <div className="hero-actions">
            <button className="primary-action" onClick={onStart}>{primary ? 'Commencer la priorité' : supports.length ? 'Commencer une séance' : 'Ajouter un support'} <span>→</span></button>
            <button className="quiet-action" onClick={onCompass}>Voir la Boussole</button>
          </div>
        </div>
        <div className="hero-orbit" aria-hidden="true"><i/><i/><i/><span>س</span></div>
      </section>

      <section className="home-grid">
        <article className="focus-panel">
          <header><div><span className="eyebrow">Prochaine action</span><h2>{primary?.title ?? (supports[0]?.title || 'Créer votre matière d’apprentissage')}</h2></div><span className="time-chip">{primary ? '8 min' : 'Départ'}</span></header>
          <p>{primary ? 'Rappel actif d’abord. Vérification seulement après votre tentative.' : supports.length ? 'Le support est prêt : choisissez une technique et commencez.' : 'PDF, texte, audio ou image — l’original reste conservé localement.'}</p>
          <button className="inline-action" onClick={primary || supports.length ? onStart : onLibrary}>Ouvrir <span>↗</span></button>
        </article>
        <article className="metric-panel">
          <div><strong>{due.length}</strong><span>à revoir</span></div>
          <div><strong>{fragile.length}</strong><span>fragiles</span></div>
          <div><strong>{supports.length}</strong><span>supports</span></div>
        </article>
      </section>

      <section className="spaces-row">
        <div className="section-title"><span className="eyebrow">Vos espaces</span><h2>Choisir une intention, pas un menu.</h2></div>
        <div className="space-cards">
          <article><span className="space-index">01</span><strong>Mémoriser</strong><p>Retrouver, vérifier, revenir au bon moment.</p></article>
          <article><span className="space-index">02</span><strong>Prononcer</strong><p>Écouter, s’enregistrer, comparer, refaire.</p></article>
          <article><span className="space-index">03</span><strong>Écrire</strong><p>Du geste guidé à la restitution libre.</p></article>
          <article><span className="space-index">04</span><strong>Cartes</strong><p>Créer librement ou structurer un support.</p></article>
        </div>
      </section>
    </div>
  );
}
