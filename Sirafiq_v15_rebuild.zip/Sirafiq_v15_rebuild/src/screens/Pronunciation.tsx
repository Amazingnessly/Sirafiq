import { useEffect, useRef, useState } from 'react';

const exercises = [
  { title:'Contraste /y/ – /u/', text:'Tu as vu une rue tranquille.', hint:'Gardez /y/ antérieur, lèvres arrondies, sans glisser vers /u/.' },
  { title:'Groupes de sens', text:'Aujourd’hui / je vais vous présenter / une idée importante.', hint:'Les pauses suivent le sens, pas chaque mot.' },
  { title:'Parole pédagogique', text:'Retenez d’abord le principe. Ensuite, nous verrons un exemple.', hint:'Annoncez l’idée, laissez une respiration, puis illustrez.' }
];

export function Pronunciation() {
  const [index,setIndex]=useState(0); const ex=exercises[index];
  const [recording,setRecording]=useState(false); const [audioUrl,setAudioUrl]=useState('');
  const recorder=useRef<MediaRecorder|null>(null); const chunks=useRef<Blob[]>([]);
  useEffect(()=>()=>{if(audioUrl)URL.revokeObjectURL(audioUrl)},[audioUrl]);
  function speak(){ speechSynthesis.cancel(); const u=new SpeechSynthesisUtterance(ex.text.replaceAll('/',''));u.lang='fr-FR';u.rate=.86;speechSynthesis.speak(u); }
  async function start(){const stream=await navigator.mediaDevices.getUserMedia({audio:true});chunks.current=[];const r=new MediaRecorder(stream);recorder.current=r;r.ondataavailable=e=>chunks.current.push(e.data);r.onstop=()=>{const blob=new Blob(chunks.current,{type:r.mimeType});if(audioUrl)URL.revokeObjectURL(audioUrl);setAudioUrl(URL.createObjectURL(blob));stream.getTracks().forEach(t=>t.stop())};r.start();setRecording(true)}
  function stop(){recorder.current?.stop();setRecording(false)}
  return <div className="practice-two-pane"><aside className="workspace-sidebar"><div><span className="eyebrow">Prononcer</span><h3>Écouter. Imiter. Comparer.</h3><p>Pas de faux score : vous réécoutez le modèle et votre prise avec des repères précis.</p></div><div className="exercise-list">{exercises.map((e,i)=><button className={i===index?'active':''} key={e.title} onClick={()=>setIndex(i)}><span>{i+1}</span><div><strong>{e.title}</strong><small>{e.text}</small></div></button>)}</div></aside><section className="practice-stage"><div className="practice-intro"><span className="eyebrow">Exercice {index+1}</span><h2>{ex.title}</h2><div className="model-phrase">{ex.text}</div><p>{ex.hint}</p><div className="stage-actions"><button className="primary-action" onClick={speak}>▶ Écouter le modèle</button>{!recording?<button className="quiet-action" onClick={start}>● M’enregistrer</button>:<button className="quiet-action danger" onClick={stop}>■ Terminer</button>}</div>{audioUrl?<div className="take-panel"><span className="eyebrow">Votre prise</span><audio controls src={audioUrl}/><p>Alternez modèle ↔ prise. Recommencez jusqu’à entendre une différence plus nette.</p></div>:null}</div></section></div>;
}
