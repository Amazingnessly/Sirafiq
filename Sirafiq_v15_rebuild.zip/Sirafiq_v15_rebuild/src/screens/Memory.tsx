import { useMemo, useState } from 'react';
import type { Mastery, SupportRecord } from '../types';
import { makeQuestions, supportSummary } from '../lib/support';

const techniques = [
  { id: 'recall', label: 'Rappel libre', hint: 'Restituer avant de regarder' },
  { id: 'questions', label: 'Questions', hint: 'Forcer la récupération' },
  { id: 'written', label: 'Écrit', hint: 'Réécrire de mémoire' },
  { id: 'map', label: 'Carte', hint: 'Reconstruire les relations' }
] as const;

type Technique = typeof techniques[number]['id'];

export function Memory({ support, onPickSupport, onRate, onOpenMap }: {
  support?: SupportRecord;
  onPickSupport: () => void;
  onRate: (mastery: Mastery, technique: string) => Promise<void>;
  onOpenMap: () => void;
}) {
  const [technique, setTechnique] = useState<Technique>('recall');
  const [phase, setPhase] = useState<'ready' | 'attempt' | 'verify' | 'done'>('ready');
  const [answer, setAnswer] = useState('');
  const prompts = useMemo(() => support?.text ? makeQuestions(support.text) : [], [support]);
  const summary = useMemo(() => support?.text ? supportSummary(support.text) : [], [support]);

  if (!support) return <div className="workspace-empty"><span className="eyebrow">Mémoriser</span><h2>Choisissez d’abord votre matière.</h2><p>Sirāfiq ne vous demandera pas de réviser dans le vide.</p><button className="primary-action" onClick={onPickSupport}>Choisir un support</button></div>;

  return <div className="memory-workspace">
    <aside className="workspace-sidebar">
      <div><span className="eyebrow">Support actif</span><h3>{support.title}</h3><p>{support.text ? 'Texte extrait et prêt à être exploité.' : 'Support conservé. L’extraction textuelle n’est pas disponible pour ce format.'}</p></div>
      <div className="technique-stack">{techniques.map(t => <button key={t.id} className={technique === t.id ? 'active' : ''} onClick={() => { setTechnique(t.id); setPhase('ready'); setAnswer(''); }}><strong>{t.label}</strong><small>{t.hint}</small></button>)}</div>
      <button className="quiet-action full" onClick={onPickSupport}>Changer de support</button>
    </aside>
    <section className="practice-stage">
      {phase === 'ready' && <div className="practice-intro"><span className="eyebrow">Prêt à commencer</span><h2>{techniques.find(t => t.id === technique)?.label}</h2><p>{technique === 'map' ? 'Reconstruisez la structure de mémoire, puis comparez avec le support.' : 'Le support restera caché pendant votre tentative. Vous ne le verrez qu’au moment de vérifier.'}</p>{technique === 'map' ? <button className="primary-action" onClick={onOpenMap}>Ouvrir l’atelier Cartes <span>→</span></button> : <button className="primary-action" onClick={() => setPhase('attempt')}>Commencer <span>→</span></button>}</div>}
      {phase === 'attempt' && <div className="attempt-panel"><div className="step-line"><span className="active">1 Restituer</span><span>2 Vérifier</span><span>3 Programmer</span></div><span className="eyebrow">Sans regarder</span><h2>{technique === 'questions' ? (prompts[0] || 'Que retenez-vous de ce support ?') : 'Qu’avez-vous réellement en mémoire ?'}</h2><textarea autoFocus value={answer} onChange={e => setAnswer(e.target.value)} placeholder="Écrivez ici votre restitution. Aucun indice ne sera affiché avant la vérification."/><div className="stage-actions"><button className="primary-action" onClick={() => answer.trim() && setPhase('verify')} disabled={!answer.trim()}>Vérifier avec le support <span>→</span></button><button className="quiet-action" onClick={() => setPhase('ready')}>Annuler</button></div></div>}
      {phase === 'verify' && <div className="verify-panel"><div className="step-line"><span className="done">✓ Restituer</span><span className="active">2 Vérifier</span><span>3 Programmer</span></div><div className="compare-columns"><article><span className="eyebrow">Votre tentative</span><div className="answer-paper">{answer}</div></article><article><span className="eyebrow">Support original</span><div className="source-paper">{summary.length ? summary.map((s,i) => <p key={i}>{s}</p>) : <p>Ouvrez le support original pour comparer précisément.</p>}</div></article></div><div className="mastery-bar"><div><span className="eyebrow">Après comparaison</span><h3>Quelle quantité de travail reste-t-il ?</h3></div><div className="mastery-buttons"><button onClick={async()=>{await onRate('again', technique);setPhase('done')}}>À revoir</button><button onClick={async()=>{await onRate('fragile', technique);setPhase('done')}}>Fragile</button><button onClick={async()=>{await onRate('acquired', technique);setPhase('done')}}>Acquis</button><button onClick={async()=>{await onRate('mastered', technique);setPhase('done')}}>Maîtrisé</button></div></div></div>}
      {phase === 'done' && <div className="complete-panel"><div className="complete-mark">✓</div><span className="eyebrow">Séance enregistrée</span><h2>La prochaine révision est programmée.</h2><p>Boussole peut maintenant utiliser cette tentative pour décider de la suite.</p><button className="primary-action" onClick={()=>{setAnswer('');setPhase('ready')}}>Nouvelle tentative</button></div>}
    </section>
  </div>;
}
